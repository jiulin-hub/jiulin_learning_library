@echo off
:: 设置代码页为UTF-8以支持中文显示
chcp 65001 >nul
:: 设置控制台字体为支持中文的字体
reg add "HKCU\Console" /v "FaceName" /t REG_SZ /d "SimSun" /f >nul 2>&1
reg add "HKCU\Console" /v "CodePage" /t REG_DWORD /d 65001 /f >nul 2>&1

:: 自动以管理员身份运行
setlocal enabledelayedexpansion
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo 请求管理员权限...
    set "batchArgs=*"
    set "batchArgs=%batchArgs:"=\"%"
    set "batchPath=%~0"
    set "batchPath=%batchPath:"=\"%"
    set "vbsGetAdmin=%temp%\getadmin.vbs"
    
    echo Set UAC = CreateObject^("Shell.Application"^) > "%vbsGetAdmin%"
    echo UAC.ShellExecute "%batchPath%", "%batchArgs%", "", "runas", 1 >> "%vbsGetAdmin%"
    
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs" >nul 2>&1
    exit /b
)

title Windows系统全面清理
color 0a
echo.
echo Author Help: jiulin.luckyliuliu@qq.com
echo 正在执行全面的系统清理，请稍候...
echo 注意：此过程可能需要几分钟时间...
echo.

:: 检查管理员权限
NET FILE 1>NUL 2>NUL
if '%errorlevel%' == '0' (
    goto :ADMIN_PRIVILEGES_OK
) else (
    echo 请使用管理员权限运行此脚本!
    pause
    exit /b
)
:ADMIN_PRIVILEGES_OK

:: 1. 系统临时文件清理
echo [1/8] 清理系统临时文件...
del /f /s /q %systemdrive%\*.tmp 2>nul
del /f /s /q %systemdrive%\*._mp 2>nul
del /f /s /q %systemdrive%\*.log 2>nul
del /f /s /q %systemdrive%\*.gid 2>nul
del /f /s /q %systemdrive%\*.chk 2>nul
del /f /s /q %systemdrive%\*.old 2>nul
del /f /s /q %systemdrive%\*.dmp 2>nul
del /f /s /q %systemdrive%\recycled\*.* 2>nul
del /f /s /q %windir%\*.bak 2>nul
del /f /s /q %windir%\prefetch\*.* 2>nul
del /f /s /q %windir%\temp\*.* 2>nul
rd /s /q %windir%\temp 2>nul & md %windir%\temp 2>nul

:: 2. 用户临时文件清理
echo [2/8] 清理用户临时文件...
del /f /q %userprofile%\cookies\*.* 2>nul
del /f /q %userprofile%\recent\*.* 2>nul
del /f /s /q "%userprofile%\AppData\Local\Temp\*.*" 2>nul
del /f /s /q "%userprofile%\Local Settings\Temporary Internet Files\*.*" 2>nul
del /f /s /q "%userprofile%\Local Settings\Temp\*.*" 2>nul
del /f /s /q "%userprofile%\recent\*.*" 2>nul
del /f /s /q "%userprofile%\AppData\Local\Bridge_BlenderMaya\*.*" 2>nul

:: 3. 浏览器缓存清理
echo [3/8] 清理浏览器缓存...
set BROWSERS="Google Chrome" "Microsoft Edge" "Mozilla Firefox" "Opera" "Brave"
for %%B in (%BROWSERS%) do (
    if exist "%userprofile%\AppData\Local\%%B\User Data\" (
        del /f /s /q "%userprofile%\AppData\Local\%%B\User Data\Default\Cache\*.*" 2>nul
        del /f /s /q "%userprofile%\AppData\Local\%%B\User Data\Default\Media Cache\*.*" 2>nul
    )
)

:: 4. 自定义目录清理
echo [4/8] 清理自定义目录...
set CUSTOM_DIRS="C:\temp" "C:\tempA" "C:\Info_Temp" "C:\soft" "C:\Autodesk" "C:\Downloads\Temp"
for %%D in (%CUSTOM_DIRS%) do (
    if exist %%D (
        del /f /s /q "%%D\*.*" 2>nul
        rd /s /q "%%D" 2>nul & md "%%D" 2>nul
    )
)

:: 5. 应用程序特定清理
echo [5/8] 清理应用程序临时文件...
:: Maya
if exist "C:\Users\%username%\Documents\maya\projects\default\yeti\tmp" (
    del /f /s /q "C:\Users\%username%\Documents\maya\projects\default\yeti\tmp\*.*" 2>nul
    rd /s /q "C:\Users\%username%\Documents\maya\projects\default\yeti\tmp" 2>nul 
    md "C:\Users\%username%\Documents\maya\projects\default\yeti\tmp" 2>nul
)

:: Adobe
del /f /s /q "%userprofile%\AppData\Local\Adobe\*.*" 2>nul

:: 6. Windows更新清理
echo [6/8] 清理Windows更新缓存...
net stop wuauserv 2>nul
net stop bits 2>nul
rd /s /q %windir%\SoftwareDistribution 2>nul
md %windir%\SoftwareDistribution 2>nul
net start wuauserv 2>nul
net start bits 2>nul
DISM /Online /Cleanup-Image /StartComponentCleanup 2>nul

:: 7. 系统维护
echo [7/8] 执行系统维护任务...
sfc /purgecache 2>nul
defrag %systemdrive% -b 2>nul
cleanmgr /sagerun:1 2>nul

:: 8. 磁盘空间回收
echo [8/8] 回收磁盘空间...
vssadmin delete shadows /all /quiet 2>nul
for /f "tokens=3" %%a in ('dir %systemdrive%\$Recycle.Bin /ad /s ^|findstr "\\$RECYCLE.BIN"') do (
    if exist %%a (
        rd /s /q %%a 2>nul
    )
)

echo.
echo 系统清理完成! 建议重新启动计算机以使所有更改生效。
echo.
