#!usr/bin/env python
# -*- coding:utf-8 -*-
# Python       : 3.9
# -------------------------------------------------------------------------------
# NAME         : lucky team
# Describe     : tools
# Version      : v0.09
# Author       : liujiulin
# Email        : jiulin.luckyliuliu@qq.com
# DateTime     :  2021.11.17 - - 2025/2/1__14:09
# -------------------------------------------------------------------------------
# -------------------------------------------------------------------------------
# example:
# 
# -------------------------------------------------------------------------------
_version_ = "__66000221.176__    20250228 - -c2021"
import bpy
import os
__path_l__ = os.path.dirname(os.path.abspath(__file__))
__path_c__ = os.path.join(__path_l__, "core")
__path_ico__ = os.path.join(__path_l__, "icons")

__path_temp_log__ = os.path.join(__path_l__, "temp_log")
__path_cpp_libs__ = os.path.join(__path_l__, "cpp_libs")
__path_scripts__ = os.path.join(__path_l__, "scripts")
__path_lucky__ = os.path.join(__path_l__, "..")
__path_lucky__ = os.path.normpath(__path_lucky__ )
__path_zip_addons__ = os.path.join(__path_l__, "zip_addons")