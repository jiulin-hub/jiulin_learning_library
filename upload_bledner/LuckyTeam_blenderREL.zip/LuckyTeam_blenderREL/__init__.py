#!usr/bin/env python
# -*- coding:utf-8 -*-
# Python       : 3.9
# -------------------------------------------------------------------------------
# NAME         : lucky team
# Describe     : tools
# Version      : v0.89
# Author       : liujiulin
# Email        : jiulin.luckyliuliu@qq.com
# DateTime     : 2025/2/1__14:09
# -------------------------------------------------------------------------------
# 说明：本文件是插件入口，保持 .py 不编译（Blender 包必须有 __init__.py）。
#       里面只有 bl_info 和注册引导，不含任何业务逻辑。
#       业务代码全在 core/ 里，发布版一律编译成 pyd。
# -------------------------------------------------------------------------------

import bpy
import importlib.machinery
import importlib.util
import os
import sys

__author__ = 'liujiulin'

__path_lr__ = os.path.dirname(os.path.abspath(__file__))
if __path_lr__ not in sys.path:
    sys.path.append(__path_lr__)

bl_info = {
    "name": "Scripting",
    "version": (5, 172),
    "author": "JIULIN.LIU",
    "blender": (2, 80, 0),
    "description": "A panel to browse and execute scripts.",
    "location": "View3D > UI > CodeBrowser",
    "doc_url": "{BLENDER_MANUAL_URL}/addons/development/index.html",
    "tracker_url": "https://d0vh5nau4xu.feishu.cn/wiki/XyrIwIF7Biq5gNkcgSEcoQYanHf?from=from_copylink",
    "category": "System",
}

_core_dir = os.path.join(__path_lr__, "core")


def _is_from(module, filename):
    path = getattr(module, "__file__", "") or ""
    return os.path.normcase(os.path.abspath(path)) == os.path.normcase(os.path.abspath(filename))


def _module_files(name):
    # Match Python's own extension suffixes, not arbitrary builds for another ABI.
    return [os.path.join(_core_dir, name + suffix)
            for suffix in (*importlib.machinery.EXTENSION_SUFFIXES, ".py")]


# These legacy modules use top-level imports. Never silently reuse another package's copy.
for _name, _filenames in (("__JLPATH__", [os.path.join(__path_lr__, "__JLPATH__.py")]),
                          ("bpylibs", _module_files("bpylibs"))):
    _existing = sys.modules.get(_name)
    if _existing is not None and not any(_is_from(_existing, path) for path in _filenames):
        raise ImportError(f"[LuckyTeam] {_name} is already loaded from "
                          f"{getattr(_existing, '__file__', None)!r}; "
                          "disable the other LuckyTeam version and restart Blender")

for _p in (__path_lr__, _core_dir):
    if _p in sys.path:
        sys.path.remove(_p)
    sys.path.insert(0, _p)

import __JLPATH__

for _p in (__JLPATH__.__path_l__, __JLPATH__.__path_c__):
    if _p not in sys.path:
        sys.path.append(_p)

# 幂等：模块级 register() 之后 Blender 启用插件还会再调一次 register()
_STATE = {"registered": False, "module": None}


def _load_agrin():
    name = "agrin_v2" if bpy.app.version >= (5, 0, 0) else "agrin"
    filename = next((path for path in _module_files(name) if os.path.isfile(path)), None)
    if filename is None:
        raise ImportError(f"[LuckyTeam] Blender {bpy.app.version_string} requires "
                          f"{name}.py or a compatible {name} extension in {_core_dir}")
    module_name = f"{__name__}.{name}"
    module = sys.modules.get(module_name)
    if module is not None:
        if not _is_from(module, filename):
            raise ImportError(f"[LuckyTeam] unexpected module path for {module_name}")
        return module
    spec = importlib.util.spec_from_file_location(module_name, filename)
    if spec is None or spec.loader is None:
        raise ImportError(f"[LuckyTeam] cannot load {filename}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    return module


def register():
    if _STATE["registered"]:
        return

    agrin = _load_agrin()
    agrin.register()
    _STATE["module"] = agrin

    # 清理上一次运行残留（顶层菜单项注册）
    try:
        import bpylibs
        bpylibs.scj_rr_clean_up_scene()
    except Exception as e:
        print(f"[LuckyTeam] bpylibs cleanup skipped: {e}")

    _STATE["registered"] = True


def unregister():
    if not _STATE["registered"]:
        return

    try:
        _STATE["module"].unregister()
    except Exception as e:
        print(f"[LuckyTeam] unregister failed: {e}")

    _STATE["registered"] = False
    _STATE["module"] = None


# 兼容“直接 import 本包”的加载方式；Blender 正常启用时还会再调一次，
# agrin.register() 和上面的 _STATE 都做了幂等保护，重复调用无副作用。
register()
