# -*- coding: utf-8 -*-
"""
LuckyTeam —— 单文件动态加载器（loader shim）

本文件只做一件事：把 cp/ 下的真正插件包导入进来，并把 register / unregister
转调过去。本身不含任何业务逻辑。

兼容性：Blender 3.3(py3.10) ~ 5.3(py3.13) 及以后版本。

目标包二选一（分别通过各自的 __init__.py 加载）：
  * LuckyTeam_blenderREL —— core 是编译好的 .pyd，源码受保护。
      只有当存在与当前解释器匹配的 pyd（如 cp313-win_amd64.pyd）时才可用。
      所以 3.3(py3.10) 以及未来的新 Python 版本无法用它。
  * LuckyTeam_blenderDEV —— 纯 .py，Blender 5.0 及以上使用 agrin_v2。

默认策略：Blender 5.0 及以上使用 DEV；低版本 REL 优先（有匹配 pyd 时），
不可用则尝试 DEV。5.0 及以上 DEV 加载失败时报告错误，不回退到旧 REL。
可用环境变量覆盖（无需改本文件）：
  LUCKYTEAM_TARGET       = DEV | REL        强制指定目标包
  LUCKYTEAM_SOURCE_ROOT  = <目录>            覆盖源码根目录

★ 不要在模块顶层 import 真插件：Blender 刷新插件列表时会 import 所有 addon
  去读 bl_info，那样会导致插件被提前 / 重复注册。真正的加载只发生在 register()。
"""
import os
import sys
import importlib
import importlib.machinery
import sysconfig

__author__ = 'liujiulin'

bl_info = {
    "name": "Scripting",
    "version": (5, 172),
    "author": "JIULIN.LIU",
    "blender": (2, 80, 0),
    "description": "A panel to browse and execute scripts.",
    "location": "View3D > UI > CodeBrowser",
    "doc_url": "{BLENDER_MANUAL_URL}/addons/development/index.html",
    "tracker_url": "https://d0vh5nau4xu.feishu.cn/wiki/XyrIwIF7Biq5gNkcgSEcoQYanHf?from=from_copylink",
    "category": "System",
}

# 源码根目录（cp 目录，里面有 LuckyTeam_blenderDEV / LuckyTeam_blenderREL）
_DEFAULT_ROOT = r"E:\software\Programs\WorkBuddy_Project\CP_py_to_pyd\cp"
_PKG_REL = "LuckyTeam_blenderREL"
_PKG_DEV = "LuckyTeam_blenderDEV"

# 当前已加载的目标包，用于 unregister 与幂等保护
_loaded_name = None
_loaded_dir = None


def _log(msg):
    print("[LuckyTeam] " + str(msg))


def _source_roots():
    """候选源码根目录：环境变量优先，其次默认路径。"""
    roots = []
    env = os.environ.get("LUCKYTEAM_SOURCE_ROOT", "").strip().strip('"')
    if env:
        roots.append(os.path.normpath(env))
    roots.append(_DEFAULT_ROOT)
    seen = set()
    out = []
    for root in roots:
        key = os.path.normcase(root)
        if key not in seen:
            seen.add(key)
            out.append(root)
    return out


def _ext_suffix():
    """当前解释器的扩展模块后缀，例如 .cp313-win_amd64.pyd。"""
    try:
        suffix = sysconfig.get_config_var("EXT_SUFFIX")
        if suffix:
            return suffix
    except Exception:
        pass
    return ".cp%d%d-win_amd64.pyd" % (sys.version_info[0], sys.version_info[1])


def _has_native_core(package_dir):
    """REL 包是否带当前 Python 版本可用的 agrin / bpylibs pyd。"""
    core = os.path.join(package_dir, "core")
    if not os.path.isdir(core):
        return False
    suffix = _ext_suffix()
    if (os.path.isfile(os.path.join(core, "agrin" + suffix)) and
            os.path.isfile(os.path.join(core, "bpylibs" + suffix))):
        return True
    # sysconfig 没给出后缀时的兜底：按当前 cpXXX 前缀匹配
    tag = "cp%d%d-" % (sys.version_info[0], sys.version_info[1])
    try:
        names = os.listdir(core)
    except OSError:
        return False
    hit_agrin = any(n.startswith("agrin" + tag) and n.endswith(".pyd") for n in names)
    hit_bpylibs = any(n.startswith("bpylibs" + tag) and n.endswith(".pyd") for n in names)
    return hit_agrin and hit_bpylibs


def _candidate_packages(root):
    """按优先级返回 (包名, 包目录) 列表。"""
    rel_dir = os.path.join(root, _PKG_REL)
    dev_dir = os.path.join(root, _PKG_DEV)
    forced = os.environ.get("LUCKYTEAM_TARGET", "").strip().upper()

    rel_ok = os.path.isdir(rel_dir) and _has_native_core(rel_dir)
    dev_ok = os.path.isdir(dev_dir)

    if forced == "DEV":
        return [(_PKG_DEV, dev_dir)] if dev_ok else []
    if forced == "REL":
        return [(_PKG_REL, rel_dir)] if os.path.isdir(rel_dir) else []

    # Blender 5.0 及以上默认使用包含 agrin_v2 的 DEV，避免静默加载旧 REL。
    import bpy
    if bpy.app.version >= (5, 0, 0):
        return [(_PKG_DEV, dev_dir)] if dev_ok else []

    # 低版本保留原策略：REL（有匹配 pyd）优先，再尝试 DEV。
    order = []
    if rel_ok:
        order.append((_PKG_REL, rel_dir))
    if dev_ok:
        order.append((_PKG_DEV, dev_dir))
    if not order and os.path.isdir(rel_dir):
        order.append((_PKG_REL, rel_dir))
    return order


def _drop_modules_under(directory):
    """卸载后清掉该包目录下的模块，保证再次启用时是干净的一次 import。"""
    if not directory:
        return
    key = os.path.normcase(os.path.abspath(directory)) + os.sep
    for name in list(sys.modules):
        mod = sys.modules.get(name)
        filename = getattr(mod, "__file__", None)
        if not filename:
            continue
        try:
            if os.path.normcase(os.path.abspath(filename)).startswith(key):
                del sys.modules[name]
        except Exception:
            pass


def _import_and_register(name, directory):
    root = os.path.dirname(directory)
    expected = os.path.join(directory, "__init__.py")

    def matches(path):
        return bool(path) and os.path.normcase(os.path.realpath(path)) == os.path.normcase(os.path.realpath(expected))

    existing = sys.modules.get(name)
    if existing is not None and not matches(getattr(existing, "__file__", None)):
        raise ImportError("%s already loaded from %r; expected %s" %
                          (name, getattr(existing, "__file__", None), expected))

    spec = importlib.machinery.PathFinder.find_spec(name, [root])
    if spec is None or not matches(spec.origin):
        raise ImportError("%s does not resolve to expected package %s" % (name, expected))

    # Put the selected root first so a same-named package elsewhere cannot win.
    for path in (directory, root):
        while path in sys.path:
            sys.path.remove(path)
        sys.path.insert(0, path)
    importlib.invalidate_caches()
    module = importlib.import_module(name)
    if not matches(getattr(module, "__file__", None)):
        raise ImportError("%s loaded from %r; expected %s" %
                          (name, getattr(module, "__file__", None), expected))
    # 真插件的 __init__ 在 import 阶段已调过 register()；这里再调一次是幂等的。
    register_fn = getattr(module, "register", None)
    if callable(register_fn):
        register_fn()
    return module


def register():
    global _loaded_name, _loaded_dir
    if _loaded_name is not None:
        return

    for root in _source_roots():
        if not os.path.isdir(root):
            continue
        if root not in sys.path:
            sys.path.insert(0, root)
        for name, directory in _candidate_packages(root):
            try:
                _import_and_register(name, directory)
            except Exception as exc:
                _drop_modules_under(directory)
                _log("load %s failed: %r" % (name, exc))
                continue
            _loaded_name, _loaded_dir = name, directory
            _log("loaded %s <- %s" % (name, directory))
            return

    import bpy
    forced = os.environ.get("LUCKYTEAM_TARGET", "").strip().upper()
    if bpy.app.version >= (5, 0, 0) and forced not in ("DEV", "REL"):
        raise RuntimeError("Blender 5.0+ requires DEV with agrin_v2; DEV was not found or failed to load. Check the errors above and LUCKYTEAM_SOURCE_ROOT (%s)" % _DEFAULT_ROOT)
    raise RuntimeError("source not found or failed to load; check the errors above and LUCKYTEAM_SOURCE_ROOT (%s)" % _DEFAULT_ROOT)


def unregister():
    global _loaded_name, _loaded_dir
    if not _loaded_name:
        return
    try:
        module = sys.modules.get(_loaded_name)
        unregister_fn = getattr(module, "unregister", None)
        if callable(unregister_fn):
            unregister_fn()
    except Exception as exc:
        _log("unregister failed: %r" % (exc,))
    finally:
        _drop_modules_under(_loaded_dir)
        _loaded_name = None
        _loaded_dir = None
