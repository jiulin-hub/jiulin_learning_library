(

    local scriptsPath = getDir #scripts
    

    if (doesFileExist scriptsPath) then (

        shellLaunch "explorer.exe" scriptsPath
    ) else (
        messageBox ("无法找到目录：\n" + scriptsPath) title:"错误"
    )
)
