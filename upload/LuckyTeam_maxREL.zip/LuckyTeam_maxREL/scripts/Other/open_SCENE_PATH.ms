(
    local scenePath = maxFilePath  -- 获取当前场景文件的目录路径（不含文件名）
    
    if scenePath != "" then
    (
        -- 确保路径存在（通常 maxFilePath 返回的目录一定存在，但以防万一）
        if doesFileExist scenePath then
            shellLaunch "explorer.exe" scenePath
        else
            messageBox ("场景目录不存在：\n" + scenePath) title:"错误"
    )
    else
        messageBox "当前场景尚未保存，无法定位目录。" title:"提示-@jiulin"
)