macrosPath = getDir #usermacros
if macrosPath != undefined then
(
    if not doesDirectoryExist macrosPath do makeDir macrosPath
    ShellLaunch "explorer.exe" macrosPath
)
else
    messageBox "无法获取 usermacros 路径！" title:"错误"