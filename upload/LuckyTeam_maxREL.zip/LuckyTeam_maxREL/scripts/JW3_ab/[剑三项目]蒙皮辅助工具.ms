/*
FileName：		蒙皮辅助工具.ms
Creator：		何文雅
Date：			2017-7-4 15:07
Comment：		蒙皮检查工具
KnownBugs：		
FixLogs：		2017-7-4 15:07
				一、	一键添加skin修改器，并将需要的骨骼加入skin列表
				二、	一键检查/修复不同部件接缝处的标准蒙皮权重
				三、	将插槽骨骼的权重设置为0（找不到对应骨骼命名）
				四、	按照现有的命名规则，自动命名动力学骨骼
				五、	将导出后的资源按照类型自动放置到游戏资源目录中（Linh会做批量导出工具，先不做这个）
				六、	Skin编辑状态中，一键选择当前骨骼影响的所有点
				七、	一键让同一位置的多个点权重一致
				2017-7-20 13:39
				增加一功能 m_skin.bone_Limit = 4
				2017-7-20 15:24
				增加一功能 设置邻近距离
				2017-7-24 20：34
				修改重命名骨骼的规则
				2026-7-27
				骨骼重命名规则迭代

*/

try(destroyDialog rol_checkSkinInfo) catch()
clearListener()

rollout rol_checkSkinInfo "蒙皮辅助工具" width:240 height:330
(	
	button btn_1_addSkinModifiers "选择部件添加Skin修改器" pos:[16,16] width:208 height:30
	--progressBar pb_1 "ProgressBar" pos:[16,40] width:208 height:6 value:100 color:(color 80 80 80)
	
	--button btn_2_checkLink "检查接缝处的标准蒙皮权重" pos:[16,56] width:208 height:24
	--progressBar pb_2 "" pos:[16,80] width:208 height:6 value:100 color:(color 80 80 80)
	
	button btn_3_checkBWeight "检查插槽骨骼的权重是否为0" pos:[16,56] width:208 height:30
	--progressBar pb_3 "" pos:[16,120] width:208 height:6 value:100 color:(color 80 80 80)
	button btn_6_selectSkinVerts "选择Skin列表选中骨骼影响的顶点" pos:[16,96] width:208 height:30
	--progressBar pb_6 "" pos:[16,80] width:208 height:6 value:100 color:(color 80 80 80)
	button btn_7_setNearWeight "同步选中顶点附近点的权重" pos:[16,136] width:156 height:30
	spinner spn_distance "" pos:[176,140] width:48 height:30 range:[0,10,0.1] type:#float scale:0.05
	--progressBar pb_7 "" pos:[16,120] width:208 height:6 value:100 color:(color 80 80 80)
	--label lbl_4_renameBones "重命名骨骼：" pos:[16,180] width:208 height:24
	GroupBox grpRenameBones "重命名骨骼" pos:[16,180] width:208 height:130
	
	button btn_4_renameBones_1_1_head "头发不贴近身体" pos:[24,206] width:100 height:24
	button btn_4_renameBones_1_2_head "头发贴近身体" pos:[136,206] width:80 height:24
	--button btn_4_renameBones_1_3_head "头上的耳坠 / 金属挂饰" pos:[24,236] width:192 height:24
	button btn_4_renameBones_2_body "身体 / 腰带 / 裤子" pos:[24,236] width:100 height:24
	button btn_4_renameBones_3_hand "袖子" pos:[136,236] width:80 height:24
	button btn_4_renameBones_4_weapon "剑穗 / 道具挂件" pos:[24,266] width:100 height:24
	button btn_4_renameBones_5_cloak "披风" pos:[136,266] width:80 height:24
	--button btn_4_renameBones5 "leg" pos:[194,136] width:30 height:24
	--progressBar pb_4 "" pos:[16,160] width:208 height:6 value:100 color:(color 80 80 80)

	local originObj = undefined
	local targetObj = undefined
	local aryOriginVerts = #()
	local aryTargetVerts = #()
	local aryVertPairs = #()
	local aryErrorGroupIDVerts = #{}
	local aryErrorPositionVerts = #{}
	
	fn fn_getBoneType_ary i_type i_num =
	(
		-- 规则表：按 [部位][链长] 取该链长的后缀数组。1-4节为现有真实值；5-10节留空数组#()占位，
		-- 填入形如 #("01","02","03","04","05")（元素数须等于链长）后即自动生效。
		local r_tbl = #()
		case i_type of
		(
			"head1": (
				r_tbl = #(
					#("01"), #("01","02"), #("01","02","06"), #("01","02","03","08"),
					#("01","02","03","08","08"), #("01","02","03","08","08","08"), #("01","02","03","08","08","08","08"),
					#("01","02","03","08","08","08","08","08"), #("01","02","03","08","08","08","08","08","08"), 
					#("01","02","03","08","08","08","08","08","08","08")
				)
			)
			"head2": (
				r_tbl = #(
					#("09"), #("09","04"), #("09","04","05"), #("09","10","11","12"),
					#("09","10","11","12","12"), #("09","10","11","12","12","12"), #("09","10","11","12","12","12","12"), 
					#("09","10","11","12","12","12","12","12"), #("09","10","11","12","12","12","12","12","12"), 
					#("09","10","11","12","12","12","12","12","12","12")
				)
			)
			"body": (
				r_tbl = #(
					#("01"), #("01","02"), #("01","02","03"), #("01","02","03","08"),
					#("01","02","03","08","08"), #("01","02","03","08","08","08"), #("01","02","03","08","08","08","08"),
					#("01","02","03","08","08","08","08","08"), #("01","02","03","08","08","08","08","08","08"), 
					#("01","02","03","08","08","08","08","08","08","08")
				)
			)
			"hand": (
				r_tbl = #(
					#("01"), #("01","02"), #("01","02","03"), #("01","02","03","08"),
					#("01","02","03","08","08"), #("01","02","03","08","08","08"), #("01","02","03","08","08","08","08"),
					#("01","02","03","08","08","08","08","08"), #("01","02","03","08","08","08","08","08","08"), 
					#("01","02","03","08","08","08","08","08","08","08")
				)
			)
			"weapon": (
				r_tbl = #(
					#("18"), #("18","18"), #("18","18","18"), #("18","18","18","18"),
					#("18","18","18","18","18"), #("18","18","18","18","18","18"), #("18","18","18","18","18","18","18"), 
					#("18","18","18","18","18","18","18","18"), #("18","18","18","18","18","18","18","18","18"), 
					#("18","18","18","18","18","18","18","18","18","18")
				)
			)
			"cloak": (
				r_tbl = #(
					#("22"), #("22","22"), #("22","22","22"), #("22","22","22","22"),
					#("22","22","22","22","22"), #("22","22","22","22","22","22"), #("22","22","22","22","22","22","22"), 
					#("22","22","22","22","22","22","22","22"), #("22","22","22","22","22","22","22","22","22"), 
					#("22","22","22","22","22","22","22","22","22","22")
				)
			)
			default: r_tbl = #()
		)
		if(i_num >= 1 and i_num <= r_tbl.count and r_tbl[i_num].count == i_num) then
			(return r_tbl[i_num])
		else
			(return #())
	)
	fn fn_checkType_int i_name =
	(
		local i_type = 0
		local i_typename = try((filterString i_name "_")[1]+"_"+(filterString i_name "_")[3]) catch("")
		case i_typename of
		(
			"M2_body": i_type = 1
			"M2_hand": i_type = 2
			"M2_leg": i_type = 3
			"M2_belt": i_type = 4
			"F2_body": i_type = 5
			"F2_hand": i_type = 6
			"F2_leg": i_type = 7
			"F2_belt": i_type = 8
			"M1_body": i_type = 9
			"M1_hand": i_type = 10
			"M1_leg": i_type = 11
			"M1_belt": i_type = 12
			"F1_body": i_type = 13
			"F1_hand": i_type = 14
			"F1_leg": i_type = 15
			"F1_belt": i_type = 16
			default: i_type = 0
		)
		return i_type
	)
	fn fn_checkTypeBones_ary i_type =
	(
		local i_ary = #()
		case i_type of
		(
			1: i_ary = #($ADD_L101, $ADD_L102, $ADD_L103, $ADD_R101, $ADD_R102, $ADD_R103, $ADD_R401, $ADD_R402, $ADD_R403, $ADD_L401, $ADD_L402, $ADD_L403, $'Bip01 Pelvis', $'Bip01 Spine', $'Bip01 Spine1', $'Bip01 Spine2', $B_Long, $B_Spine2, $B_RC, $B_LC, $'Bip01 Neck', $'Bip01 Neck1', $'Bip01 Head', $'Bip01 L Clavicle', $'Bip01 L UpperArm', $Bone_L_ArmTwist, $'Bip01 L ForeTwist', $'Bip01 L ForeTwist1', $'Bip01 R Clavicle', $'Bip01 R UpperArm', $Bone_R_ArmTwist, $'Bip01 R ForeTwist', $'Bip01 R ForeTwist1', $B_Spine, $'Bip01 R Thigh', $Bone_R_ThighTwist, $'Bip01 L Thigh', $Bone_L_ThighTwist, $B_RP, $B_LP)
			2: i_ary = #($'Bip01 L Hand', $'Bip01 L Finger0', $'Bip01 L Finger01', $'Bip01 L Finger02', $'Bip01 L Finger1', $'Bip01 L Finger11', $'Bip01 L Finger12', $'Bip01 L Finger2', $'Bip01 L Finger21', $'Bip01 L Finger22', $'Bip01 L Finger3', $'Bip01 L Finger31', $'Bip01 L Finger32', $'Bip01 L Finger4', $'Bip01 L Finger41', $'Bip01 L Finger42', $B_LH, $'Bip01 L ForeTwist', $'Bip01 L ForeTwist1', $'Bip01 R Hand', $'Bip01 R Finger0', $'Bip01 R Finger01', $'Bip01 R Finger02', $'Bip01 R Finger1', $'Bip01 R Finger11', $'Bip01 R Finger12', $'Bip01 R Finger2', $'Bip01 R Finger21', $'Bip01 R Finger22', $'Bip01 R Finger3', $'Bip01 R Finger31', $'Bip01 R Finger32', $'Bip01 R Finger4', $'Bip01 R Finger41', $'Bip01 R Finger42', $B_RH, $'Bip01 R ForeTwist', $'Bip01 R ForeTwist1')
			3: i_ary = #($'Bip01 Pelvis', $'Bip01 Spine', $B_Spine, $'Bip01 R Thigh', $'Bip01 R Calf', $'Bip01 R Foot', $'Bip01 R Toe0', $Bone_R_ThighTwist, $'Bip01 L Thigh', $'Bip01 L Calf', $'Bip01 L Foot', $'Bip01 L Toe0', $Bone_L_ThighTwist)
			4: i_ary = #($ADD_L101, $ADD_L102, $ADD_L103, $ADD_R101, $ADD_R102, $ADD_R103, $ADD_R401, $ADD_R402, $ADD_R403, $ADD_L401, $ADD_L402, $ADD_L403, $'Bip01 Pelvis', $'Bip01 Spine', $'Bip01 L Thigh', $Bone_R_ThighTwist, $Bone_L_ThighTwist, $'Bip01 Spine1', $'Bip01 R Thigh')
			5: i_ary = #($ADD_R101, $ADD_R102, $ADD_R103, $ADD_L101, $ADD_L102, $ADD_L103, $ADD_L401, $ADD_L402, $ADD_L403, $ADD_R401, $ADD_R402, $ADD_R403, $'Bip01 Pelvis', $'Bip01 Spine', $'Bip01 L Thigh', $Bone_L_ThighTwist, $'Bip01 L Calf', $'Bip01 Spine1', $'Bip01 Spine2', $'Bip01 Neck', $'Bip01 L Clavicle', $'Bip01 L UpperArm', $Bone_L_ArmTwist, $'Bip01 R Clavicle', $'Bip01 R UpperArm', $Bone_R_ArmTwist, $'Bip01 Neck1', $'Bip01 Head', $Bone_chest_R, $Bone_chest_L, $B_Long, $B_Spine2, $B_RC, $B_LC, $'Bip01 R Thigh', $'Bip01 R Calf', $Bone_R_ThighTwist, $B_Spine, $B_LP, $B_RP)
			6: i_ary = #($'Bip01 L Hand', $'Bip01 L Finger0', $'Bip01 L Finger01', $'Bip01 L Finger02', $'Bip01 L Finger1', $'Bip01 L Finger11', $'Bip01 L Finger12', $'Bip01 L Finger2', $'Bip01 L Finger21', $'Bip01 L Finger22', $'Bip01 L Finger3', $'Bip01 L Finger31', $'Bip01 L Finger32', $'Bip01 L Finger4', $'Bip01 L Finger41', $'Bip01 L Finger42', $'Bip01 L ForeTwist', $'Bip01 L ForeTwist1', $'Bip01 R Hand', $'Bip01 R Finger0', $'Bip01 R Finger01', $'Bip01 R Finger02', $'Bip01 R Finger1', $'Bip01 R Finger11', $'Bip01 R Finger12', $'Bip01 R Finger2', $'Bip01 R Finger21', $'Bip01 R Finger22', $'Bip01 R Finger3', $'Bip01 R Finger31', $'Bip01 R Finger32', $'Bip01 R Finger4', $'Bip01 R Finger41', $'Bip01 R Finger42', $'Bip01 R ForeTwist', $'Bip01 R ForeTwist1')
			7: i_ary = #($'Bip01 Pelvis', $'Bip01 R Toe0', $'Bip01 L Thigh', $Bone_L_ThighTwist, $'Bip01 L Calf', $'Bip01 L Foot', $'Bip01 L Toe0', $'Bip01 R Thigh', $'Bip01 R Calf', $'Bip01 R Foot', $Bone_R_ThighTwist, $'Bip01 Spine', $B_LH’,  $B_RH)
			8: i_ary = #($ADD_R101, $ADD_R102, $'Bip01 Spine1', $ADD_L101, $ADD_L102, $ADD_L103, $ADD_L401, $ADD_L402, $ADD_L403, $ADD_R401, $ADD_R402, $Bone_L_ThighTwist, $'Bip01 Pelvis', $'Bip01 Spine', $'Bip01 L Thigh', $Bone_R_ThighTwist, $'Bip01 Spine2', $'Bip01 R Thigh', $ADD_R103, $ADD_R403)
			9: i_ary = #($'Bip01 Pelvis', $'Bip01 Spine', $'Bip01 L Calf', $'Bip01 R Calf', $'Bip01 Spine1', $'Bip01 Spine2', $'Bip01 Neck', $'Bip01 Head', $'Bip01 L Clavicle', $'Bip01 L ForeTwist', $'Bip01 L ForeTwist1', $'Bip01 LUpArmTwist', $'Bip01 LUpArmTwist1', $'Bip01 R Clavicle', $'Bip01 R ForeTwist', $'Bip01 R ForeTwist1', $'Bip01 RUpArmTwist', $'Bip01 RUpArmTwist1', $B_LC, $B_RC, $B_Spine2, $B_Long, $B_Spine, $ADD_L101, $ADD_L102, $ADD_R101, $ADD_R102, $ADD_R401, $ADD_R402, $ADD_L401, $ADD_L402, $'Bip01 LThighTwist', $'Bip01 LThighTwist1', $'Bip01 RThighTwist', $'Bip01 RThighTwist1', $B_LP, $B_RP)
			10: i_ary = #($'Bip01 L Hand', $'Bip01 L Finger0', $'Bip01 L Finger01', $'Bip01 L Finger02', $'Bip01 L Finger1', $'Bip01 L Finger11', $'Bip01 L Finger12', $'Bip01 L Finger2', $'Bip01 L Finger21', $'Bip01 L Finger22', $'Bip01 L Finger3', $'Bip01 L Finger31', $'Bip01 L Finger32', $'Bip01 L Finger4', $'Bip01 L Finger41', $'Bip01 L Finger42', $B_LH, $'Bip01 R Finger42', $'Bip01 L ForeTwist1', $'Bip01 R Hand', $'Bip01 R Finger0', $'Bip01 R Finger01', $'Bip01 R Finger02', $'Bip01 R Finger1', $'Bip01 R Finger11', $'Bip01 R Finger12', $'Bip01 R Finger2', $'Bip01 R Finger21', $'Bip01 R Finger22', $'Bip01 R Finger3', $'Bip01 R Finger31', $'Bip01 R Finger32', $'Bip01 R Finger4', $'Bip01 R Finger41', $'Bip01 R ForeTwist1', $'Bip01 R ForeTwist', $B_RH, $'Bip01 L ForeTwist')
			11: i_ary = #($'Bip01 Pelvis', $'Bip01 Spine', $'Bip01 L Calf', $'Bip01 L Foot', $'Bip01 L Toe0', $'Bip01 R Calf', $'Bip01 R Foot', $'Bip01 R Toe0', $'Bip01 RThighTwist', $'Bip01 LThighTwist', $'Bip01 LThighTwist1', $'Bip01 RThighTwist1', $'Bip01 Spine1')
			12: i_ary = #($'Bip01 Pelvis', $'Bip01 Spine', $'Bip01 RThighTwist', $'Bip01 LThighTwist', $ADD_L101, $ADD_L401, $ADD_R101, $ADD_R401, $ADD_R402, $ADD_L102, $ADD_L402, $'Bip01 Spine2', $'Bip01 LThighTwist1', $'Bip01 Spine1', $'Bip01 RThighTwist1', $ADD_R102)
			13: i_ary = #($'Bip01 Pelvis', $'Bip01 Spine', $'Bip01 L Thigh', $'Bip01 L Calf', $'Bip01 R Thigh', $'Bip01 R Calf', $'Bip01 Spine1', $'Bip01 Spine2', $'Bip01 Neck', $'Bip01 Neck1', $'Bip01 Head', $'Bip01 L Clavicle', $'Bip01 L UpperArm', $Bone_L_ArmTwist, $'Bip01 R Clavicle', $'Bip01 R UpperArm', $Bone_R_ArmTwist, $B_LC, $B_RC, $B_Spine2, $B_Long, $B_Spine, $'Bip01 LThighTwist', $'Bip01 RThighTwist', $ADD_L501, $ADD_L502, $ADD_L401, $ADD_L402, $ADD_R401, $ADD_R402, $ADD_R501, $ADD_R502, $ADD_R101, $ADD_R102, $ADD_L101, $ADD_L102, $B_LP, $B_RP)
			14: i_ary = #($'Bip01 L Hand', $'Bip01 L Finger0', $'Bip01 L Finger01', $'Bip01 L Finger02', $'Bip01 L Finger1', $'Bip01 L Finger11', $'Bip01 L Finger12', $'Bip01 L Finger2', $'Bip01 L Finger21', $'Bip01 L Finger22', $'Bip01 L Finger3', $'Bip01 L Finger31', $'Bip01 L Finger32', $'Bip01 L Finger4', $'Bip01 L Finger41', $'Bip01 L Finger42', $B_LH, $'Bip01 R Finger42', $'Bip01 L ForeTwist1', $'Bip01 R Hand', $'Bip01 R Finger0', $'Bip01 R Finger01', $'Bip01 R Finger02', $'Bip01 R Finger1', $'Bip01 R Finger11', $'Bip01 R Finger12', $'Bip01 R Finger2', $'Bip01 R Finger21', $'Bip01 R Finger22', $'Bip01 R Finger3', $'Bip01 R Finger31', $'Bip01 R Finger32', $'Bip01 R Finger4', $'Bip01 R Finger41', $'Bip01 R ForeTwist1', $'Bip01 R ForeTwist', $B_RH, $'Bip01 L ForeTwist')
			15: i_ary = #($'Bip01 R Thigh', $'Bip01 L Thigh', $'Bip01 L Calf', $'Bip01 L Foot', $'Bip01 L Toe0', $'Bip01 RThighTwist', $'Bip01 R Calf', $'Bip01 R Foot', $'Bip01 R Toe0', $'Bip01 LThighTwist', $'Bip01 Pelvis')
			16: i_ary = #($'Bip01 Pelvis', $'Bip01 Spine', $ADD_L101, $ADD_L501, $ADD_R102, $ADD_L401, $ADD_L402, $ADD_R401, $ADD_R402, $ADD_R501, $ADD_R101, $ADD_L102, $'Bip01 Spine1', $ADD_L502, $ADD_R502)
			default: i_ary = #()
		)
		return i_ary
	)
	--所有重命名功能的基础准入判断
	fn fn_checkParentBone i_bone =
	(
		-- 静默谓词：只返回 true/false，不弹框（避免与 handler 的 else 弹框叠加成双框）。
		if(i_bone.parent == undefined) then (return false)
		if(classof i_bone != BoneGeometry) then (return false)
		local b_parent = i_bone.parent
		if(classof b_parent == BoneGeometry or classof b_parent == Biped_Object or MatchPattern b_parent.name pattern:"Bip01*") then (return true)
		return false
	)
	fn fn_isBoundaryPrefix i_name =
	(
		-- 边界骨骼前缀：这类骨骼作为重命名链的挂接点，不纳入链也不被改名。
		-- ADD / B：按“_”拆分后第一段严格匹配；CB 系列：名字以“CB”开头即算边界(CB1/CB2/CB3/CBR4/CBR12…)。
		-- 增删边界类型只改这个函数。
		local p = try((filterString i_name "_")[1]) catch("")
		if(p == "ADD" or p == "B") then (return true)
		-- CB 系列(CB1/CB2/CB3/CBR4/CBR12…)按名字前2字符匹配
		local s = try(i_name as string) catch("")
		if(s != undefined and s != "") then
		(
			local pre = try(subString s 1 2) catch("")
			if(pre == "CB") then (return true)
		)
		return false
	)
	fn fn_isStandardBone i_bone =
	(
		if(classof i_bone == BoneGeometry) and (not fn_isBoundaryPrefix i_bone.name) then
		(return true)
		else
		(return false)
	)


	fn fn_checkBWeight_str i_obj i_skin =
	(
		local aryB = #($B_Hat, $B_LH, $B_RH, $B_LC, $B_RC, $B_Spine2, $B_Long, $B_Spine, $B_LP, $B_RP)
		local aryN = #("B_Hat", "B_LH", "B_RH", "B_LC", "B_RC", "B_Spine2", "B_Long", "B_Spine", "B_LP", "B_RP")
		local aryBoneNames = #()
		local numSkinBones = skinops.GetNumberBones i_skin
		local numObjVerts = i_obj.numverts
		local i_tag = true
		local strBWeight = ""
		for i = 1 to numSkinBones do
		(append aryBoneNames (skinops.GetBoneName i_skin i 1))
		for n = 1 to aryBoneNames.count where(i_tag) do
		(
			if(findItem aryN aryBoneNames[n] != 0) then
			(
				for j = 1 to numObjVerts  do
				(
					if(skinOps.GetVertexWeight i_skin j n != 0) then
					(
						i_tag = false
						strBWeight += aryBoneNames[n]+ "\n"
						exit
					)
				)
			)
		)
		return strBWeight 
	)
	fn fn_getUniqueName_ary i_name i_count =
	(
		local aryBoneNames = (for o in objects where(classof o == BoneGeometry) collect (filterString o.name "_")[2])
		local r_ary = #()
		local temp_ary = #()
		for n in aryBoneNames where (n != undefined) do
		(
			if(findString n i_name != undefined) then
			(
				local temp_obj = dummy()
				temp_obj.name = n
				append temp_ary temp_obj
			)
		)
		for i = 1 to i_count do
		(
			local temp_obj = dummy()
			temp_obj.name = uniqueName i_name
			append temp_ary temp_obj
			append r_ary temp_obj.name
		)
		try(delete temp_ary) catch()
		return r_ary
	)
	fn fn_renameBones_ary m_name m_num m_typename=
	(
		-- 角色前缀规则表：按链长索引，role_tbl[m_num] 为该链长各位置的前缀数组。
		-- 1-4节为现有真实值；5-10节留空数组#()占位，填入形如 #("FBR4","FB3","FB3","FB3","FB3")（元素数=链长）后即生效。
		local r_ary = #()
		local role_tbl = #(
			#("FBR4"), --1
			#("FBR4","FB3"), --2
			#("FBR4","FB3","FB3"), --3
			#("FBR4","FB2","FB3","FB2"), --4
			#("FBR4","FB2","FB3","FB2","FB1"), --5
			#("FBR4","FB2","FB3","FB2","FB1","FB1"), --6
			#("FBR4","FB2","FB3","FB2","FB1","FB2","FB1"), --7
			#("FBR4","FB1","FB2","FB1","FB3","FB1","FB2","FB1"), --8
			#("FBR4","FB1","FB2","FB1","FB3","FB1","FB2","FB1","FB1"), --9
			#("FBR4","FB1","FB2","FB1","FB3","FB1","FB2","FB1","FB1","FB1") --10
		)
		if(m_num < 1 or m_num > role_tbl.count or role_tbl[m_num].count != m_num) then
			(return #())
		local role_ary = role_tbl[m_num]
		local ary_name = fn_getUniqueName_ary (m_name+m_typename) m_num
		if(ary_name.count < m_num) then (return #())
		for i = 1 to m_num do
		(
			append r_ary (role_ary[i]+"_"+ary_name[i])
		)
		return r_ary
	)
	fn fn_getBoneChain b_bone =
	(
		local aryB = #()
		local b_bool = true
		try
		(
			-- 防御：选中骨骼本身是边界前缀则不构成待改名链
			if(fn_isBoundaryPrefix b_bone.name) do (return #())

			-- 1) 向上收集 selected→root：父级为边界前缀骨骼或非BoneGeometry(Biped/Dummy等)即停，不纳入不失败
			local upPath = #(b_bone)
			local b_node = b_bone
			while(classof b_node.parent == BoneGeometry) do
			(
				local parent_node = b_node.parent
				if(fn_isBoundaryPrefix parent_node.name) then (exit)
				b_node = parent_node
				append upPath b_node
			)
			-- 2) 反转得 root→selected（自动沿“朝向选中”分支，上方分叉不再失败）
			for i = upPath.count to 1 by -1 do (append aryB upPath[i])
			-- 3) 从 selected 向下：仅这段强制“单一正常骨骼子级”；分叉则失败
			b_node = b_bone
			while true do
			(
				local normalChildren = for c in b_node.children where (
					(classof c == BoneGeometry) and (not fn_isBoundaryPrefix c.name)
				) collect c
				if(normalChildren.count == 0) then (exit)
				if(normalChildren.count > 1) then (b_bool = false; exit)
				append aryB normalChildren[1]
				b_node = normalChildren[1]
			)
			if(not b_bool) then (aryB = #())
		)
		catch
		(aryB = #())
		return aryB
	)
	fn fn_doRenameBones b_bone m_typeName m_suffixKey =
	(
		-- 重命名共用入口：取链→校验链长(1-10)→校验.max文件名→查前缀/后缀规则表→改名。
		-- 链长>10、文件名段数不足、或该链长规则未补(占位#())时弹窗拒绝，不产生坏名字。
		local aryBoneChain = fn_getBoneChain b_bone
		if(aryBoneChain.count == 0) then
		(
			messagebox "获取骨骼链失败：选中骨骼下方存在分叉（多于一个正常骨骼子级），无法确定唯一重命名路径。\nADD/B/CBR 前缀骨骼作为挂接点已自动截断。" title:"注意"
			return false
		)
		local n = aryBoneChain.count
		if(n > 10) then
		(
			messagebox "骨骼链超过10节，暂不支持！" title:"注意"
			return false
		)
		-- 去掉文件扩展名(任意扩展名/大小写)再按"_"拆分，避免扩展名污染骨骼前缀(如 M2_body.max → M2body.max)
		local fn_name = maxfilename
		local dotPos = 0
		for k = fn_name.count to 1 by -1 do (if subString fn_name k 1 == "." do (dotPos = k; exit))
		if(dotPos > 1) do (fn_name = subString fn_name 1 (dotPos - 1))
		local aryFilterName = filterString fn_name "_"
		if(aryFilterName.count < 2) then
		(
			messagebox "当前.max文件名不规范（需至少含1个下划线段），无法生成骨骼前缀！" title:"注意"
			return false
		)
		local aryBoneName = fn_renameBones_ary (aryFilterName[1]+aryFilterName[2]) n m_typeName
		local aryBoneNameSuffix = fn_getBoneType_ary m_suffixKey n
		if(aryBoneName.count != n or aryBoneNameSuffix.count != n) then
		(
			messagebox ("骨骼链 "+(n as string)+" 节暂无重命名规则，请先在 fn_renameBones_ary / fn_getBoneType_ary 规则表补充"+(n as string)+"节定义！") title:"注意"
			return false
		)
		-- 最终安全闸：逐根校验，边界骨骼(ADD/B/CBR…)与Biped骨骼(Bip01…)绝不被改名；混入即中止并报错
		for i = 1 to n do
		(
			local b = aryBoneChain[i]
			if(classof b != BoneGeometry or fn_isBoundaryPrefix b.name) then
			(
				messagebox "检测到不可重命名的骨骼混入链中（边界骨骼或Biped骨骼），已中止重命名以防误改！" title:"注意"
				return false
			)
		)
		-- 改名这一步包 undo on：多骨骼改名可一步撤销；校验/弹窗已在块外，失败不产生空撤销步
		undo on
		(
			for i = 1 to n do (aryBoneChain[i].name = aryBoneName[i]+"_"+aryBoneNameSuffix[i])
		)
		return true
	)
	fn fn_getBoneWeights_ary i_obj i_skin =
	(
		local numObjVerts = i_obj.numVerts
		local numBones = skinOps.GetNumberBones i_skin
		local r_ary = #()
		for i = 1 to numBones do
		(
			append r_ary #(i,#{},#(),(skinOps.GetBoneName i_skin i 1))--name有问题
		)
		for j = 1 to numObjVerts do
		(
			local numWeightBones = skinOps.GetVertexWeightCount i_skin j
			for k = 1 to numWeightBones do
			(
				local bWeight = skinOps.GetVertexWeight i_skin j k
				local bID = skinOps.GetVertexWeightBoneID i_skin j k
				append r_ary[bID][2] j 
				append r_ary[bID][3] bWeight 
			)
		)
		return r_ary
	)
	on btn_1_addSkinModifiers pressed do
	(
		--pb_1.color = (color 80 80 80)
		if(selection.count == 1) then
		(
			local objType = fn_checkType_int $.name
			if(objType != 0) then
			(
				local aryBones = fn_checkTypeBones_ary objType
				if($.modifiers["Skin"] != undefined) then
				(
					messagebox "该部件已有蒙皮！" title:"注意"
					--pb_1.color = (color 255 255 0)
				)
				else
				(
					addModifier $ (skin())
					m_skin = $.modifiers["Skin"] 
					m_skin.bone_Limit = 4
					for b in aryBones do
					(skinOps.addbone m_skin b 0)
					--pb_1.color = (color 0 255 0)
				)
			)
			else
			(messagebox "找不到符合命名规范的部件！" title:"注意")
		)
		else
		(messagebox "请选择一个部件！" title:"注意")
	)
	on btn_3_checkBWeight pressed do
	(
		if(selection.count == 1) then
		(
			local objType = fn_checkType_int $.name
			local m_skin = $.modifiers["Skin"]
			modPanel.setcurrentobject m_skin
			if((objType != 0) and (m_skin != undefined)) then
			(
				local aryBoneWeights = fn_getBoneWeights_ary $ m_skin 
				local aryN = #("B_Hat", "B_LH", "B_RH", "B_LC", "B_RC", "B_Spine2", "B_Long", "B_Spine", "B_LP", "B_RP")
				local aryB = #()
				local strCheckWeight = ""
				local numB = skinOps.GetNumberBones m_skin
				for j = 1 to aryBoneWeights.count do
				(append aryB aryBoneWeights[j][4])
				for i = 1 to aryBoneWeights.count do
				(
					local i_name = skinOps.GetBoneName m_skin i 1
					local i_id = findItem aryN i_name
					
					if(i_id != 0) then
					(
						local i_boneID = findItem aryB i_name
						--print i_boneID
						--print aryBoneWeights[i_boneID][2]
						if(aryBoneWeights[i_boneID][2].count != 0) then
						(strCheckWeight += (i_name+"\n"))
					)
				)
				if(strCheckWeight.count != 0) then
				(messagebox ("不合格的插槽权重，请手动修改！\n"+strCheckWeight) title:"注意")
				else
				(messagebox "检查通过！" title:"注意")
			)
			
		)
		else(messagebox "请选择一个部件！" title:"注意")
		
	)
	on btn_4_renameBones_1_1_head pressed do
	(
		if(selection.count == 1) and (fn_checkParentBone $) then
		(
			if(fn_isStandardBone $) then
			(
				fn_doRenameBones $ "head" "head1"
			)
			else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
		)
		else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
	)
	on btn_4_renameBones_1_2_head pressed do
	(
		if(selection.count == 1) and (fn_checkParentBone $) then
		(
			if(fn_isStandardBone $) then
			(
				fn_doRenameBones $ "head" "head2"
			)
			else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
		)
		else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
	)
	/* 已注释：耳坠/金属挂饰按钮(btn_4_renameBones_1_3_head)的按钮声明(第49行)已注释，
	   handler 一并注释，以免"未声明控件的事件"在 createDialog 时导致对话框弹不出。
	   如需恢复：取消第49行按钮声明的注释，并删掉本段的块注释包裹即可。
	on btn_4_renameBones_1_3_head pressed do
	(
		if(selection.count == 1) and (fn_checkParentBone $) then
		(
			if(fn_isStandardBone $) then
			(
				local aryBoneChain = fn_getBoneChain $
				local aryFilterName = filterString maxfilename "_"
				local aryBoneName = fn_renameBones_ary (aryFilterName[1]+aryFilterName[2]) aryBoneChain.count "head"
				local aryBoneNameSuffix = fn_getBoneType_ary "head1" aryBoneChain.count
				if(aryBoneChain.count != 0) then
				(
					for i = 1 to aryBoneChain.count do
					(
						aryBoneChain[i].name = aryBoneName[i]+"_"+aryBoneNameSuffix[i]
					)
				)
				else(messagebox "获取骨骼链失败，请检查！" title:"注意")
			)
			else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
		)
		else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
	)
	*/
	on btn_4_renameBones_2_body pressed do
	(
		if(selection.count == 1) and (fn_checkParentBone $) then
		(
			if(fn_isStandardBone $) then
			(
				fn_doRenameBones $ "body" "body"
			)
			else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
		)
		else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
	)
	on btn_4_renameBones_3_hand pressed do
	(
		if(selection.count == 1) and (fn_checkParentBone $) then
		(
			if(fn_isStandardBone $) then
			(
				fn_doRenameBones $ "hand" "hand"
			)
			else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
		)
		else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
	)
	on btn_4_renameBones_4_weapon pressed do
	(
		if(selection.count == 1) and (fn_checkParentBone $) then
		(
			if(fn_isStandardBone $) then
			(
				fn_doRenameBones $ "weapon" "weapon"
			)
			else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
		)
		else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
	)
	on btn_4_renameBones_5_cloak pressed do
	(
		if(selection.count == 1) and (fn_checkParentBone $) then
		(
			if(fn_isStandardBone $) then
			(
				fn_doRenameBones $ "cloak" "cloak"
			)
			else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
		)
		else(messagebox "请选择骨骼链的其中一根Bone！" title:"注意")
	)
	on btn_6_selectSkinVerts pressed do
	(
		if((selection.count == 1) and (classof $ == PolyMeshObject)) then
		(
			local m_skin = $.modifiers["Skin"]
			local v_num = $.numVerts
			if(m_skin != undefined) then
			(
				if(modPanel.getcurrentobject() ==  m_skin) then
				(
					local i_id = skinOps.GetSelectedBone m_skin
					local aryBoneWeights = fn_getBoneWeights_ary $ m_skin 
					local aryVerts = aryBoneWeights[i_id][2]
					--print aryBoneWeights
				)
				modPanel.setCurrentObject $.baseObject
				subobjectLevel = 1
				$.EditablePoly.SetSelection #Vertex aryVerts
			)
		)
		else(messagebox "请选择Skin修改器列表中的骨骼！" title:"注意")
		
	)
	on btn_7_setNearWeight pressed do
	(
		undo on
		(
			if((selection.count == 1) and (classof $ == Editable_Poly) and ($.modifiers[#Skin] != undefined)) then
			(
				local arySelVerts = ($.EditablePoly.getSelection #Vertex) as array
				local aryNearPoint = #()
				for v in arySelVerts do
				(
					local v_pos = $.EditablePoly.GetVertex v
					
					local i_ary = #()
					for i = 1 to $.numVerts where(findItem arySelVerts i == 0) do
					(
						
						local i_pos = $.EditablePoly.GetVertex i
						if((abs(v_pos.x - i_pos.x)< spn_distance.value) and (abs(v_pos.y - i_pos.y)< spn_distance.value) and (abs(v_pos.z - i_pos.z)< spn_distance.value)) then
						(
							append i_ary i
							
						)
					)
					append aryNearPoint i_ary
				)
				modPanel.setCurrentObject $.modifiers[#Skin]
				--print arySelVerts.count
				--print arySelVerts[1]
				for s = 1 to arySelVerts.count do
				(
					--print arySelVerts[s]
					local w_count = skinOps.GetVertexWeightCount $.skin (arySelVerts[s])
					local aryBoneID = #()
					local aryBoneWeights = #()
					for w = 1 to w_count do
					(
						append aryBoneID (skinOps.GetVertexWeightBoneID $.skin (arySelVerts[s]) w)
						append aryBoneWeights (skinOps.GetVertexWeight $.skin (arySelVerts[s]) w)
					)
					--print (aryBoneID as string)
					--print (aryBoneWeights as string)
					--print (aryNearPoint as string)
					for j = 1 to aryNearPoint[s].count do
					(
						skinOps.SetVertexWeights $.skin (aryNearPoint[s][j]) aryBoneID[1] 1.0
						skinOps.SetVertexWeights $.skin (aryNearPoint[s][j]) aryBoneID aryBoneWeights
					)
				)
			)
			else(messagebox "请选择Edit_Poly上的顶点！" title:"注意")
		)
	)
)
	
createdialog rol_checkSkinInfo