-- Scaled Bone Check Tool (骨骼缩放检查工具)
-- 功能：检查指定帧范围内所有骨骼的缩放值
--       v2.0 - 支持多帧扫描

struct FrameScaleInfo
(
    frame,
    scaleX,
    scaleY,
    scaleZ
)

struct ScaledBoneInfo
(
    boneNode,
    boneName,
    scaledFrames = #()
)

-- 全局变量
global scaledBoneCheckRollout
global scaledBoneCheckWindow = undefined
global boneList = #()

-- 主功能 Rollout
rollout scaledBoneCheckRollout "骨骼缩放检测"
(
    -- 帧范围输入
    group "扫描范围"
    (
        spinner startFrameSpn "起始帧:" range:[0,9999,0] type:#integer width:80 across:2
        spinner endFrameSpn   "结束帧:" range:[0,9999,20] type:#integer width:80
    )
    
    -- dotNet CheckedListBox 控件（支持复选框多选）
    label listLbl "异常骨骼列表：" width:280 height:16
    dotNetControl boneCheckList "System.Windows.Forms.CheckedListBox" width:280 height:180
    
    -- 详细信息标签（点击列表项时显示）
    label detailLbl "" width:280 height:16
    
    -- 操作按钮组
    group ""
    (
        button scanBtn "🔍 扫描场景" width:135 height:30 across:2
        button resetBtn "✓ 重置缩放" width:135 height:30
        button selectAllBtn "✓ 全选" width:90 height:25 across:2
        button invertSelBtn "⊗ 反选" width:90 height:25
    )
    
    -- 初始化 dotNet 控件
    on boneCheckList Create do
    (
        local dColor = dotNetClass "System.Drawing.Color"
        local dBrush = dotNetClass "System.Drawing.SolidBrush"
        
        -- 深灰色背景（与3dsMax标准UI一致）
        boneCheckList.BackColor = dColor.FromArgb 65 65 65
        boneCheckList.ForeColor = dColor.FromArgb 210 210 210
        
        -- 增大字体（每行变高 → 复选框点击区域变大，更容易勾选）
        boneCheckList.Font = (dotNetClass "System.Drawing.Font").New "Segoe UI" 11.0
        
        -- 点击任意位置切换复选框（不限于点击复选框方块）
        boneCheckList.CheckOnClick = true
        
        -- 边框样式
        boneCheckList.BorderStyle = boneCheckList.BorderStyle.FixedSingle
        
        -- 禁用 UseTabStops（可能会影响背景）
        boneCheckList.UseTabStops = false
        
        -- 强制刷新
        boneCheckList.Refresh()
    )
    
    -- 在 rollout 打开时再次设置背景颜色
    on scaledBoneCheckRollout open do
    (
        local dColor = dotNetClass "System.Drawing.Color"
        boneCheckList.BackColor = dColor.FromArgb 65 65 65
        boneCheckList.ForeColor = dColor.FromArgb 210 210 210
        boneCheckList.Refresh()
    )
    
    -- 全选所有骨骼
    fn selectAllBones =
    (
        for i = 0 to (boneCheckList.Items.Count - 1) do
        (
            boneCheckList.SetItemChecked i true
        )
    )
    
    -- 反选所有骨骼
    fn invertSelectionBones =
    (
        for i = 0 to (boneCheckList.Items.Count - 1) do
        (
            local isChecked = boneCheckList.GetItemChecked i
            boneCheckList.SetItemChecked i (not isChecked)
        )
    )
    
    -- 格式化骨骼的显示文本
    fn formatBoneDisplay boneInfo frameCount totalFrames =
    (
        -- 统计缩放值的范围
        local minS = 9999, maxS = -9999
        for fi in boneInfo.scaledFrames do
        (
            if fi.scaleX < minS then minS = fi.scaleX
            if fi.scaleX > maxS then maxS = fi.scaleX
            if fi.scaleY < minS then minS = fi.scaleY
            if fi.scaleY > maxS then maxS = fi.scaleY
            if fi.scaleZ < minS then minS = fi.scaleZ
            if fi.scaleZ > maxS then maxS = fi.scaleZ
        )
        
        -- 格式化数字为2位小数（兼容方式）
        fn fmtNum val =
        (
            local whole = val as integer
            local frac = (abs (val - whole) * 100 + 0.5) as integer
            local fracStr = frac as string
            if frac < 10 then fracStr = "0" + fracStr
            whole as string + "." + fracStr
        )
        
        local scaleStr
        if abs(minS - maxS) < 0.01 then
            scaleStr = fmtNum minS
        else
            scaleStr = fmtNum minS + "~" + fmtNum maxS
        
        return boneInfo.boneName + " [" + (frameCount as string) + "/" + (totalFrames as string) + "帧] " + scaleStr
    )
    
    -- 扫描场景，查找指定帧范围内缩放不是100%的骨骼
    fn scanSceneForScaledBones =
    (
        boneList = #()
        boneCheckList.Items.Clear()
        detailLbl.text = ""
        
        local startF = startFrameSpn.value as integer
        local endF = endFrameSpn.value as integer
        
        if endF < startF then
        (
            messageBox "结束帧不能小于起始帧！"
            return()
        )
        
        local totalFrames = endF - startF + 1
        
        -- 遍历场景中的所有节点
        for node in objects do
        (
            -- 检查是否是骨骼
            if classof(node) == BoneGeometry then
            (
                local boneInfo = ScaledBoneInfo boneNode:node boneName:node.name
                
                -- 逐帧检查缩放值（使用 at time 不会移动时间滑块，高效）
                for f = startF to endF do
                (
                    local s = at time f node.scale
                    if abs(s.x - 1) > 0.01 or abs(s.y - 1) > 0.01 or abs(s.z - 1) > 0.01 then
                    (
                        append boneInfo.scaledFrames (FrameScaleInfo frame:f scaleX:s.x scaleY:s.y scaleZ:s.z)
                    )
                )
                
                -- 如果有异常帧，加入列表
                if boneInfo.scaledFrames.count > 0 then
                (
                    append boneList boneInfo
                    boneCheckList.Items.Add (formatBoneDisplay boneInfo boneInfo.scaledFrames.count totalFrames)
                )
            )
        )
        
        -- 更新标题显示统计信息
        if boneList.count > 0 then
        (
            scaledBoneCheckRollout.title = "骨骼缩放检测 (" + (boneList.count as string) + "个骨骼异常, " + (totalFrames as string) + "帧)"
        )
        else
        (
            scaledBoneCheckRollout.title = "骨骼缩放检测 (无异常)"
            messageBox ("帧范围 " + (startF as string) + "~" + (endF as string) + "F 内没有找到缩放不正常的骨骼")
        )
    )
    
    -- 重置勾选的骨骼缩放为100%（删除缩放关键帧）
    fn resetCheckedBoneScale =
    (
        local resetCount = 0
        
        undo on
        (
            for i = 0 to (boneCheckList.Items.Count - 1) do
            (
                if boneCheckList.GetItemChecked i then
                (
                    local boneInfo = boneList[i + 1]
                    local node = boneInfo.boneNode
                    
                    try
                    (
                        -- 尝试删除缩放关键帧（方法1：通过控制器）
                        local ctrl = node.controller
                        if ctrl != undefined then
                        (
                            local scaleCtrl = ctrl[#Scale]
                            if scaleCtrl != undefined then
                            (
                                deleteKeys scaleCtrl
                            )
                        )
                        
                        -- 设置静态缩放为100%
                        node.scale = [1, 1, 1]
                        resetCount += 1
                    )
                    catch
                    (
                        -- 如果删除失败，至少设置一下缩放值
                        try ( node.scale = [1, 1, 1] ) catch()
                        resetCount += 1
                    )
                )
            )
        )
        
        if resetCount > 0 then
        (
            messageBox ("已删除 " + (resetCount as string) + " 个骨骼的缩放关键帧，并设置缩放为 100%")
            scanSceneForScaledBones()
        )
        else
        (
            messageBox "请先勾选要重置的骨骼（点击复选框 ✓）"
        )
    )
    
    -- 当点击列表项时，在场景中选中对应的骨骼并显示详情
    on boneCheckList SelectedIndexChanged sender args do
    (
        local idx = boneCheckList.SelectedIndex  -- 0-based
        if idx >= 0 and idx < boneList.count then
        (
            local boneInfo = boneList[idx + 1]
            select boneInfo.boneNode
            actionMan.executeAction 0 "310"
            
            -- 在详情标签中显示异常帧信息
            local frameStr = ""
            local shownFrames = 0
            for fi in boneInfo.scaledFrames do
            (
                frameStr = frameStr + " F" + (fi.frame as string)
                shownFrames += 1
                if shownFrames >= 5 then exit
            )
            
            if boneInfo.scaledFrames.count > 5 then
                frameStr = frameStr + " ...共" + (boneInfo.scaledFrames.count as string) + "帧"
            
            detailLbl.text = "▸ " + boneInfo.boneName + " |" + frameStr
        )
    )
    
    -- 全选按钮点击事件
    on selectAllBtn pressed do
    (
        selectAllBones()
    )
    
    -- 反选按钮点击事件
    on invertSelBtn pressed do
    (
        invertSelectionBones()
    )
    
    -- 扫描按钮点击事件
    on scanBtn pressed do
    (
        scanSceneForScaledBones()
    )
    
    -- 重置按钮点击事件
    on resetBtn pressed do
    (
        resetCheckedBoneScale()
    )
)

-- 创建 MacroScript（可在 CUI 中使用）
macroScript ScaledBoneCheckTool
    category:"检查工具"
    tooltip:"骨骼缩放检测"
    buttonText:"骨骼缩放检测"
(
    if scaledBoneCheckWindow == undefined or scaledBoneCheckWindow.isdisplayed == false then
    (
        scaledBoneCheckWindow = CreateDialog scaledBoneCheckRollout 320 480 200 200 style:#(#style_titlebar, #style_sysmenu, #style_resizing)
    )
    else
    (
        -- 如果窗口已打开，将其设为活跃窗口
        SetDialogPos scaledBoneCheckWindow 200 200
    )
)
