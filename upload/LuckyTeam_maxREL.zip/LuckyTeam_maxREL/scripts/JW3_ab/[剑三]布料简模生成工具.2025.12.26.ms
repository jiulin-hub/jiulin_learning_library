





try( destroyDialog rol_KG3DClothingAgentMesh )
catch()

rollout rol_KG3DClothingAgentMesh "KG3D Clothing Agent Mesh" width:256 height:624
(
	local rol = rol_KG3DClothingAgentMesh
	
	/*��Ȩ���汾 ��Ϣ��
	Copy following controls to your rollout......
	HyperLink 'Hyp_copyright' "\xa9"
	HyperLink 'Hyp_copyrightYear' "2019"
	HyperLink 'Hyp_copyrightOwner' "SeasunGame"
	HyperLink 'Hyp_textVer' "Ver:"
	HyperLink 'Hyp_version' "2000.00.00"
	HyperLink 'Hyp_textBy' "by"
	HyperLink 'Hyp_editor' "Ou Jion"
	*/
	fn fn_setCopyrightInfo rol =
 	(
		local str_version = "2025.12.26"
		local int_posY = rol.height-21
		
		--	HyperLink 'Hyp_copyright' "C"
		rol.Hyp_copyright.pos = [8,int_posY]
		rol.Hyp_copyright.enabled = false
		rol.Hyp_copyright.color = black
		--	HyperLink 'Hyp_copyrightYear' "1998"
		rol.Hyp_copyrightYear.pos = [21,int_posY]
		rol.Hyp_copyrightYear.enabled = false
		rol.Hyp_copyrightYear.color = black
		--	HyperLink 'Hyp_copyrightOwner' "SeasunGame"
		rol.Hyp_copyrightOwner.pos = [48,int_posY]
		rol.Hyp_copyrightOwner.color = rol.Hyp_copyrightOwner.visitedcolor = red
		rol.Hyp_copyrightOwner.address = "http://www.xishanju.com/"
		--	"HyperLink 'Hyp_textVer' "Ver:"
		rol.Hyp_textVer.pos = [(rol.width-140),int_posY]
		rol.Hyp_textVer.enabled = false
		rol.Hyp_textVer.color = black
		--	HyperLink 'Hyp_version' "2008.01.08.a"
		rol.Hyp_version.text = str_version
		rol.Hyp_version.pos = [(rol.width-120),int_posY]
		rol.Hyp_version.enabled = false
		rol.Hyp_version.color = black
		--	HyperLink 'Hyp_textBy' "by"
		rol.Hyp_textBy.pos = [(rol.width-60),int_posY]
		rol.Hyp_textBy.enabled = false
		rol.Hyp_textBy.color = black
		--	HyperLink 'Hyp_editor' "Oj Jian"
		rol.Hyp_editor.pos = [(rol.width-45),int_posY]
		rol.Hyp_editor.color = rol.Hyp_editor.visitedcolor = black
		rol.Hyp_editor.address = "mailto:oujian@kingsoft.com"
	)
	
	--	ȥ��Skin����Ȩ�صĹ�����
	fn fn_removeZeroWeightBone obj =
	(
		local iSkin,ary_iBoneID
		
		iSkin = obj.modifiers[#Skin]
		modPanel.setCurrentObject iSkin
		skinOps.RemoveZeroWeights iSkin
		
		ary_iBoneID = for n in 1 to (skinOps.GetNumberBones iSkin) collect (skinOps.GetBoneIDByListID iSkin n)
		for v = 1 to (skinOps.GetNumberVertices iSkin) where (ary_iBoneID.count > 0) do
		(
			for n = 1 to (skinOps.GetVertexWeightCount iSkin v) do
			(
				local i = findItem ary_iBoneID (skinOps.GetVertexWeightBoneID iSkin v n)
				
				if (i != 0) do 
				(
					deleteItem ary_iBoneID i
					exit
				)
			)
		)
		sort ary_iBoneID
		
		for n = ary_iBoneID.count to 1 by -1 do
		(
			modPanel.setCurrentObject iSkin
			skinOps.removeBone iSkin ary_iBoneID[n]
		)
		
		skinOps.RemoveZeroWeights iSkin
	)
	
	--	���Skin��
	fn fn_splitObjMesh obj =
	(
		local objNew
		
		--	�Ƚ�ռ�ڴ�,����԰�ȫ��
		objNew = copy obj
		
		select obj
		modPanel.setCurrentObject $.baseObject
		polyop.deleteFaces $.baseObject ( polyop.getFaceSelection $.baseObject )
		subobjectLevel = 0
		if ( undefined != $.modifiers[#Skin] ) do ( skinOps.RemoveZeroWeights $.modifiers[#Skin] )
		
		select objNew
		modPanel.setCurrentObject $.baseObject
		polyop.deleteFaces $.baseObject ( #{1..$.faces.count}-( polyop.getFaceSelection $.baseObject ) )
		subobjectLevel = 0
		if ( undefined != $.modifiers[#Skin] ) do ( skinOps.RemoveZeroWeights $.modifiers[#Skin] )
		
		return (#(obj,objNew))
	)
	
	--	�ϲ�Skin��
	fn fn_mergeSkin aryObj weldThreshold =
	(
		local newSkinObj = aryObj[1]
		local arySkinBoneList = #()
		local aryVertWeightBone = #()
		local aryVertWeight = #()
		
		sliderTime = animationRange.start
		--	�ռ�������
		for n = 1 to aryObj.count do
		(
			local obj = aryObj[n]
			
			max modify mode
			modPanel.setCurrentObject obj.modifiers[#Skin]
			--	����Ȩ�ء�
			modPanel.setCurrentObject obj.modifiers[#Skin]
			obj.modifiers[#Skin].weightAllVertices = true
			skinOps.RemoveZeroWeights obj.modifiers[#Skin]
			--	��ȡ�����б���
			for i = 1 to (skinOps.GetNumberBones obj.modifiers[#Skin]) do
			(
				local iName = skinOps.GetBoneName obj.modifiers[#Skin] i 1
				
				if (findItem arySkinBoneList iName == 0) do
				(
					append arySkinBoneList iName
				)
			)
		)
		sort arySkinBoneList
		
		--	�ռ�Ȩ�ء�
		for n = 1 to aryObj.count do
		(
			local obj = aryObj[n]
			
			--	����ϲ��modifier��skin������modifier���㣬���򶥵�������ֲ��졣
			while (obj.modifiers[1] != undefined and classof obj.modifiers[1] != skin) do
			(
				deleteModifier obj 1
			)
			
			modPanel.setCurrentObject obj.modifiers[1]
			for v = 1 to (skinOps.GetNumberVertices obj.modifiers[#Skin]) do
			(
				local aryBoneID = for y in 1 to arySkinBoneList.count collect y
				local aryWeight = for y in 1 to arySkinBoneList.count collect 0.0
				
				for x = 1 to (skinOps.GetVertexWeightCount obj.modifiers[#skin] v) do
				(
					local iBoneID = skinOps.GetVertexWeightBoneID obj.modifiers[#Skin] v x
					local iName = skinOps.GetBoneName obj.modifiers[#Skin] iBoneID 1
					local new = findItem arySkinBoneList iName
					
					aryWeight[new] = skinOps.GetVertexWeight obj.modifiers[#Skin] v x
				)
				
				append aryVertWeightBone aryBoneID
				append aryVertWeight aryWeight
			)
			convertTo obj Editable_Poly
		)
		
		--	�ϲ����塣
		for n = 2 to aryObj.count do
		(
			newSkinObj.EditablePoly.attach aryObj[n] newSkinObj
		)
		--	���Ӷ���
		if (0 < weldThreshold) do
		(
			newSkinObj.EditablePoly.SetSelection #Vertex #{1..newSkinObj.verts.count}
			newSkinObj.weldThreshold = weldThreshold
			polyop.weldVertsByThreshold newSkinObj #{1..newSkinObj.verts.count}
		)
		
		--	����Skin������Ȩ�ء�
		addmodifier newSkinObj (skin() )
		modPanel.setCurrentObject newSkinObj.modifiers[#Skin]
		for n = 1 to arySkinBoneList.count do
		(
			local iBone = getNodeByName arySkinBoneList[n]
			
			if (undefined == iBone) then
			(messagebox "miss Bone:" title:rol.title)
			else
			(skinOps.addbone newSkinObj.modifiers[#Skin] iBone 1)
		)
		
		clearSelection()
		modPanel.setCurrentObject newSkinObj.modifiers[#Skin]
		for n = 1 to newSkinObj.verts.count do
		(
			skinOps.ReplaceVertexWeights newSkinObj.modifiers[#Skin] n aryVertWeightBone[n] aryVertWeight[n]
		)
		newSkinObj.modifiers[#Skin].bone_Limit = 4
		skinOps.RemoveZeroWeights newSkinObj.modifiers[#Skin]
		
		return (#(aryVertWeightBone,aryVertWeight))
	)
	
	--	�ƶ�FFD�޸����ĵ� int_vertN �����Ƶ㵽�������� pt3_newPos
	fn fn_setLatticePos obj int_vertN pt3_newPos =
	(
		local modifier_FFD,matrix_obj,matrix_FFD,pt3_modBBMin,pt3_modBBMax,pt3_localPos,pt3_newLocalPos
		
		modifier_FFD = obj.modifiers[#sliceEllipse]
		if ( undefined == modifier_FFD ) do return()
		
		animateAll modifier_FFD
		pt3_localPos = execute ( "$'"+obj.name+"'.modifiers[#sliceEllipse].control_point_"+int_vertN as string )
		matrix_obj = obj.objectTransform
		matrix_FFD = ( getModContextTM obj modifier_FFD )*modifier_FFD.lattice_transform.value
		pt3_modBBMin = getModContextBBoxMin obj modifier_FFD
		pt3_modBBMax = getModContextBBoxMax obj modifier_FFD
		
		pt3_newLocalPos = ( pt3_newPos*( inverse matrix_obj )*matrix_FFD-pt3_modBBMin )/( ( pt3_modBBMax-pt3_modBBMin )+0.001*[1,1,1] )
		
		execute ( "$'"+obj.name+"'.modifiers[#sliceEllipse].control_point_"+int_vertN as string+" = "+pt3_newLocalPos as string )
		
		return pt3_newLocalPos
	)
	
	fn fn_sliceByPath mesh_obj int_slice matrix_axis =
	(
		local flt_sliceHeight = 1
		local ary_vertsLocalPos = #()
		local pt2_zMinMax = [65535,-65535]
		
		--	����ת����ָ���ռ䡣
		for n = 1 to mesh_obj.verts.count do
		(
			ary_vertsLocalPos[n] = mesh_obj.verts[n].pos*( inverse matrix_axis )
		)
		--	�ҳ���ͺ���ߵ㡣
		for v = 1 to ary_vertsLocalPos.count do
		(
			if ( pt2_zMinMax.x>ary_vertsLocalPos[v].z ) do ( pt2_zMinMax.x = ary_vertsLocalPos[v].z )
			if ( pt2_zMinMax.y<ary_vertsLocalPos[v].z ) do ( pt2_zMinMax.y = ary_vertsLocalPos[v].z )
		)
		--	������ֲ㡣
		for v = 1 to ary_vertsLocalPos.count do
		(
			local int_floor = 1
			
			int_floor = ceil ( ( ary_vertsLocalPos[v].z-pt2_zMinMax.x )/flt_sliceHeight )
			if ( 0 == int_floor ) do ( int_floor += 1 )
			ary_sliceVerts[int_floor][v] = true
		)
	)
	
	fn fn_loftByHeight mesh_obj int_slice matrix_axis =
	(
		local ary_sliceEllipse = #()
		local ary_stepVertsIndex = #()
		local int_baseVerts = mesh_obj.verts.count
		local modifier_editPoly = edit_poly name:"splitVerts"
		local modifier_slice = sliceModifier name:"splitLoft"  Slice_Type:1
		local ary_localBBox = nodeGetBoundingBox mesh_obj matrix_axis
		local flt_sliceStep = ( ary_localBBox[2].z-ary_localBBox[1].z )/int_slice
		
		polyop.setVertSelection mesh_obj.baseobject #{}
		addmodifier mesh_obj modifier_slice
		addmodifier mesh_obj modifier_editPoly
		
		matrix_axis.pos = ary_localBBox[1]*[0,0,1]*matrix_axis
		mesh_obj.modifiers[#splitLoft].Slice_Plane.rotation = (quat 0 0 0 1)-matrix_axis.rotation-mesh_obj.rotation
		for step = 1 to (int_slice+1) do
		(
			local pt3_localStep = [0,0,0]
			
			case step of
			(
				( 1 ):( pt3_localStep += [0,0,flt_sliceStep*0.15] )
				( int_slice+1 ):( pt3_localStep += [0,0,flt_sliceStep*(int_slice-0.15)] )
				default:( pt3_localStep += [0,0,flt_sliceStep*(step-1)] )
			)
			
			mesh_obj.modifiers[#splitLoft].Slice_Plane.position = pt3_localStep*matrix_axis*( inverse mesh_obj.transform )
			
			if ( mesh_obj.verts.count>int_baseVerts ) then
			(
				local pt2_sliceMin = [65535,65535]
				local pt2_sliceMax = -[65535,65535]
				local flt_sliceWidth,flt_sliceLength,pt3_sliceCenter
				
				for v in #{( int_baseVerts+1 )..mesh_obj.verts.count} do
				(
					local pt3_localPos = mesh_obj.verts[v].pos*( inverse matrix_axis )
					
					if ( pt2_sliceMin.x>pt3_localPos.x ) do ( pt2_sliceMin.x = pt3_localPos.x )
					if ( pt2_sliceMin.y>pt3_localPos.y ) do ( pt2_sliceMin.y = pt3_localPos.y )
					
					if ( pt2_sliceMax.x<pt3_localPos.x ) do ( pt2_sliceMax.x = pt3_localPos.x )
					if ( pt2_sliceMax.y<pt3_localPos.y ) do ( pt2_sliceMax.y = pt3_localPos.y )
				)
				flt_sliceWidth = ( pt2_sliceMax-pt2_sliceMin ).x 
				flt_sliceLength = ( pt2_sliceMax-pt2_sliceMin ).y
				
				pt3_sliceCenter = [0,0,pt3_localStep.z]
				case step of
				(
					( 1 ):( pt3_sliceCenter.z += -flt_sliceStep*0.15 )
					( int_slice+1 ):( pt3_sliceCenter.z += flt_sliceStep*0.15 )
					default:()
				)
				pt3_sliceCenter.x = ( pt2_sliceMax.x+pt2_sliceMin.x )*0.5
				pt3_sliceCenter.y = ( pt2_sliceMax.y+pt2_sliceMin.y )*0.5
				pt3_sliceCenter *= matrix_axis
				
				append ary_sliceEllipse #(flt_sliceWidth,flt_sliceLength,pt3_sliceCenter)
			)
			else
			(
				format "fn_loftByHeight:>  No split ?@ step = %; pt3_localStep = %\n" step pt3_localStep
			)
			
		)
		
		deleteModifier mesh_obj modifier_editPoly
		deleteModifier mesh_obj modifier_slice
		
		if ( 11 == i_debug ) do
		(
			delete $sliceEllipse*
			for n = 1 to ary_sliceEllipse.count do
			(
				local i_ellipse = Ellipse name:( "sliceEllipse"+ n as string ) transform:matrix_axis width:ary_sliceEllipse[n][1] length:ary_sliceEllipse[n][2] wirecolor:green
				
				i_ellipse.pos = ary_sliceEllipse[n][3]
			)
		)
		
		return ary_sliceEllipse
	)
	
	fn fn_createPlaneAgentLOD mesh_obj pt2_segment ary_sliceEllipse matrix_axis int_agentStyle int_surfaceMappingType bol_skin bol_color =
	(
		local int_agent,mesh_agent,matrix_local,ary_agentRayEx,bary_intersect,bary_agentFaces
		local mesh_intersect = snapshot mesh_obj
		local mesh_flipIntersect = copy mesh_intersect
		local pt3_size = (nodeLocalBoundingBox mesh_obj)[2]*(inverse mesh_obj.transform)-(nodeLocalBoundingBox mesh_obj)[1]*(inverse mesh_obj.transform)
		
		delete $agentIntersectMesh*
		mesh_intersect.name = "agentIntersectMesh"
		mesh_flipIntersect.name = "agentIntersectMesh"
		
		int_agent = 1+execute ( "$"+mesh_obj.name+"_agent*.count" )
		if ( 1 == int_agentStyle ) do
		(
			mesh_agent = plane name:( mesh_obj.name+"_agent"+int_agent as string ) xray:true transform:( ( matrix3 [1,0,0] [0,0,1] [0,1,0] [0,0,0] )*matrix_axis ) \
							   width:pt3_size.x length:pt3_size.z widthsegs:pt2_segment[1] lengthsegs:pt2_segment[2]
		)
		if ( 2 == int_agentStyle ) do
		(
			mesh_agent = Cylinder name:( mesh_obj.name+"_agent"+int_agent as string ) xray:true transform:matrix_axis \
								  radius:pt3_size.x height:pt3_size.z sides:pt2_segment[1] heightsegs:pt2_segment[2]
		)
		
		select mesh_agent
		addmodifier mesh_agent ( FFDBox name:"sliceEllipse" tension:25 continuity:25 inPoints:false outPoints:true )
		animateAll mesh_agent.modifiers[#sliceEllipse]
		if ( 1 == int_agentStyle ) do ( setDimensions mesh_agent.modifiers[#sliceEllipse] [2,ary_sliceEllipse.count,2] )
		if ( 2 == int_agentStyle ) do ( setDimensions mesh_agent.modifiers[#sliceEllipse] [2,2,ary_sliceEllipse.count] )
		
		for n = 1 to ary_sliceEllipse.count do
		(
			local matrix_lattice,pt3_latticePos
			
			if ( 1 == int_agentStyle ) do
			(
				local int_side= ary_sliceEllipse.count*2
				
				matrix_lattice = matrix_axis
				matrix_lattice.pos = ary_sliceEllipse[n][3]
				pt3_latticePos = [-ary_sliceEllipse[n][1]*0.5,0,0]*matrix_lattice
				fn_setLatticePos mesh_agent ( 2*n-1 ) pt3_latticePos
				fn_setLatticePos mesh_agent ( 2*n-1+int_side ) pt3_latticePos
				matrix_lattice = matrix_axis
				matrix_lattice.pos = ary_sliceEllipse[n][3]
				pt3_latticePos = [ary_sliceEllipse[n][1]*0.5,0,0]*matrix_lattice
				fn_setLatticePos mesh_agent ( 2*n ) pt3_latticePos
				fn_setLatticePos mesh_agent ( 2*n+int_side ) pt3_latticePos
			)
			
			if ( 2 == int_agentStyle ) do
			(
				matrix_lattice = matrix_axis
				matrix_lattice.pos = ary_sliceEllipse[n][3]
				pt3_latticePos = [-ary_sliceEllipse[n][1]*0.5,-ary_sliceEllipse[n][2]*0.5,0]*matrix_lattice
				fn_setLatticePos mesh_agent ( ( n-1 )*4+1 ) pt3_latticePos
				
				matrix_lattice = matrix_axis
				matrix_lattice.pos = ary_sliceEllipse[n][3]
				pt3_latticePos = [ary_sliceEllipse[n][1]*0.5,-ary_sliceEllipse[n][2]*0.5,0]*matrix_lattice
				fn_setLatticePos mesh_agent ( ( n-1 )*4+2 ) pt3_latticePos
				
				matrix_lattice = matrix_axis
				matrix_lattice.pos = ary_sliceEllipse[n][3]
				pt3_latticePos = [-ary_sliceEllipse[n][1]*0.5,ary_sliceEllipse[n][2]*0.5,0]*matrix_lattice
				fn_setLatticePos mesh_agent ( ( n-1 )*4+3 ) pt3_latticePos
				
				matrix_lattice = matrix_axis
				matrix_lattice.pos = ary_sliceEllipse[n][3]
				pt3_latticePos = [ary_sliceEllipse[n][1]*0.5,ary_sliceEllipse[n][2]*0.5,0]*matrix_lattice
				fn_setLatticePos mesh_agent ( ( n-1 )*4+4 ) pt3_latticePos
			)
		)
		convertTo mesh_agent Editable_poly
		if ( 2 == int_agentStyle ) do ( polyop.deleteverts mesh_agent #{1,mesh_agent.verts.count} )
		
		--	���棬 mesh_intersect Ϊ˫�档
		meshop.flipNormals mesh_flipIntersect mesh_flipIntersect.faces
		attach mesh_intersect mesh_flipIntersect
		mesh_intersect.name = "rayExIntersect"
		--	����յ㡣���� mesh_agent �Ķ���λ�ã�Ȼ�������� mesh_intersect
		bary_intersect = #{}
		ary_agentRayEx = #()
		for v = 1 to mesh_agent.verts.count do
		(
			local ray_intersect,pt3_normal,ary_vertFaces
			local pt3_pos = mesh_agent.verts[v].pos
			local ray_extVert = ray [0,0,0] [1,1,1]
			
			--	polyû�ж���normal�������ö��㹲���normal������һ��ƽ��ֵ��
			pt3_normal = [0,0,0]
			ary_vertFaces = ( polyOp.getfacesUsingvert mesh_agent v ) as array
			for f in ary_vertFaces do
			(
				pt3_normal += polyop.getFaceNormal mesh_agent f
			)
			pt3_normal = pt3_normal/ary_vertFaces.count
			--	��Ͷ�䷽ʽ��ƽ���ߣ����ߣ�
			if ( 2 == int_surfaceMappingType ) do ( pt3_normal = normalize ( pt3_pos-pt3_pos*[0,0,1] ) )
			ray_extVert.dir = -1*pt3_normal
			ray_extVert.pos = pt3_pos+11*pt3_normal
			--	intersectRayEx node ray = #((ray [pt3_pos] [pt3_normal]), int_faceIndex, [pt3_faceCenter])
			append ary_agentRayEx ( intersectRayEx mesh_intersect ray_extVert )
			if ( undefined != ary_agentRayEx[v] ) then
			(
				--	�ж��Ƿ���ͬһ�� ���� �ٽ���
				bary_intersect[v] = 0<( pt3_pos.x*ary_agentRayEx[v][1].pos.x )*( pt3_pos.y*ary_agentRayEx[v][1].pos.y ) and 5>length ( ary_agentRayEx[v][1].pos-pt3_pos )
			)
		)
		--	���� mesh_agent �������ڵ�3�������Ƿ�������1������ mesh_intersect����ȫû�о���Ҫȥ������~
		bary_agentFaces = #{}
		for f = 1 to mesh_agent.faces.count do
		(
			local bary_faceVerts = polyOp.getVertsUsingface mesh_agent f
			
			--	�����ڵĶ����Ƿ�������1������ mesh_intersect����ȫû�о���Ҫȥ������~
			for v in bary_faceVerts do
			(
				bary_agentFaces[f] = bary_agentFaces[f] or bary_intersect[f]
				--	����ֱ����������һ�¡�
				if ( 1 == int_surfaceMappingType ) do
				(
					local ray_vert = ray mesh_agent.verts[v].pos ( [0,0,-1]*mesh_obj.transform )
					
					bary_agentFaces[f] = bary_agentFaces[f] or ( undefined != intersectRay mesh_intersect ray_vert )
				)
			)
		)
		
		polyop.setFaceSelection mesh_agent ( #{1..mesh_agent.faces.count}-bary_agentFaces )
		
		--	������ɫ��
		if ( true == bol_color ) do
		(
			local ary_channel = #(-2,-1,0)
			local ary_closeVert = #()
			
			for int_channel in ary_channel do
			(
				polyop.setMapSupport mesh_obj int_channel true
				polyop.setMapSupport mesh_agent int_channel true
			)
			
			for v = 1 to mesh_agent.verts.count where ( undefined != ary_agentRayEx[v]) do
			(
				local bary_faceVerts = #{}
				local flt_minDistance = 65535
				local int_rayExFace = ary_agentRayEx[v][2]
				
				bary_faceVerts = meshOp.getVertsUsingFace mesh_intersect int_rayExFace
				for x in bary_faceVerts do
				(
					local pt3_pos = mesh_intersect.verts[x].pos
					
					if ( flt_minDistance>length ( pt3_pos-ary_agentRayEx[v][1].pos ) ) do
					(
						flt_minDistance = length ( pt3_pos-ary_agentRayEx[v][1].pos )
						ary_closeVert[v] = x
					)
				)
			)
			convertTo mesh_intersect Editable_poly
			for int_channel in #(-2,-1,0) do
			(
				polyop.setMapSupport mesh_intersect int_channel true
				for v = 1 to mesh_agent.verts.count where ( undefined != ary_closeVert[v] ) do
				(
					local color_v = polyop.getMapVert mesh_intersect int_channel ary_closeVert[v]
					
					polyop.setVertColor mesh_agent int_channel v ( color_v*255 )
				)
			)	
			
			mesh_agent.showVertexColors = mesh_obj.showVertexColors
			mesh_agent.vertexColorType = mesh_obj.vertexColorType
			mesh_agent.vertexColorsShaded = mesh_obj.vertexColorsShaded
		)
		
		--	skinȨ��
		if ( true == bol_skin ) do
		(
			local modifier_warp
			
			mesh_obj.modifiers[#skin].enabled = false
			modifier_warp = Skin_Wrap name:"mappingSkinWeights" engine:0 meshList:#(mesh_obj) weightAllVerts:true
			addmodifier mesh_agent modifier_warp
			mesh_agent.modifiers[#mappingSkinWeights].ConvertToSkin true
			deleteModifier mesh_agent modifier_warp
			mesh_agent.modifiers[#Skin].bone_Limit = 4
			mesh_obj.modifiers[#skin].enabled = true
		)
		
		
		update mesh_agent
		delete mesh_intersect
		return ok
	)
	
	--------------------------------
	button 'btn_splitSkin' "Split Selected Faces From Object" pos:[8,8] width:240 height:32 align:#left
	label 'lbl_line1' "------------------------------------------------------------" pos:[8,40] width:240 height:16 enabled:false align:#left
	
	GroupBox 'grp_agentLODMesh' "Agent LOD Mesh Sets:" pos:[8,56] width:240 height:336 align:#left enabled:false
	label 'lbl_Detail' "Loft Detail:" pos:[144,56] width:56 height:16 align:#left
	spinner 'spn_detail' "" pos:[202,56] width:36 height:16 range:[2,11,5] type:#integer scale:1 align:#left
	spinner 'spn_ellipseSides' "Ellipse Sides:" pos:[24,80] range:[2,100,6] type:#integer width:64 height:16 align:#left
	slider 'sld_ellipseSides' "" pos:[24,96] width:224 height:25 range:[2,100,6] type:#integer orient:#horizontal ticks:0 align:#left
	spinner 'spn_heightSegments' "Height Segments:" pos:[24,128] range:[4,100,30] type:#integer width:72 height:16 align:#left
	slider 'sld_heightSegment' "" pos:[22,144] width:224 height:25 range:[4,100,30] type:#integer orient:#horizontal ticks:0 align:#left
	checkbutton 'ckb_manuallyDelete' "Select Unwanted Faces, Manually Delete." pos:[16,176] width:224 height:24 highlightColor:(color 64 128 32) checked:true align:#left
	label 'lbl_agentStyle' "LOD Mesh Agent Style:" pos:[18,210] width:112 height:16 align:#left
	radiobuttons 'rdo_agentStyle' "" pos:[135,208] width:115 height:16 labels:#("Plane", "Tube") columns:2 align:#left
	
	button 'btn_createAgent' ">> Create Selected Agent LOD Mesh <<" pos:[16,232] width:224 height:48 align:#left
	
	checkbox 'chk_mappingSkin' " Mapping Skin" pos:[16,288] width:80 height:16 align:#left
	checkbutton 'ckb_skin' "On" pos:[98,289] width:24 height:16 checked:true align:#left
	checkbox 'chk_mappingVertsColor' " Mapping Verts Color" pos:[128,288] width:112 height:16 align:#left
	label 'lb_centralAxis' "Default Central Axis:" pos:[21,322] width:99 height:16 align:#left
	radiobuttons 'rdo_centralAxis' "" pos:[128,321] width:120 height:16 labels:#("Local", "World") columns:2 align:#left
	pickbutton 'btn_centralAxis' "Select A Custom Obj As Central Axis" pos:[16,336] width:224 height:24 autoDisplay:true align:#left
	label 'lbl_surfaceMappingType' "Surface Mapping Type:" pos:[20,370] width:112 height:16 align:#left
	radiobuttons 'rdo_surfaceMappingType' "" pos:[136,369] width:143 height:16 labels:#("Normal", "Parallel") columns:2 align:#left
	
	label 'lbl_line2' "------------------------------------------------------------" pos:[8,392] width:240 height:16 enabled:false align:#left
	button 'btn_mergeSkin' "Merge Selected Objects" pos:[8,408] width:240 height:32 align:#left
	button 'btn_relax' "Relax" pos:[8,448] width:88 height:36 align:#left
	spinner 'spn_amount' "Amount:" pos:[104,448] width:56 height:16 range:[-1,1,0.5] scale:0.01 align:#left
	spinner 'spn_iterations' "Iterations:" pos:[104,472] width:64 height:16 range:[1,1024,1] type:#integer align:#left
	checkbox 'chk_holdOuterPoints' "Hold Outer Points" pos:[8,488] width:112 height:16 align:#left
	checkbox 'chk_holdBoundaryPoints' "Hold Boundary Points" pos:[128,488] width:120 height:16 align:#left
	button 'btn_conform' "Conform" pos:[8,512] width:88 height:72 align:#left
	checkbutton 'btn_conformSurface' "Pick Conform Surface" pos:[104,512] width:144 height:32 align:#left
	label 'lbl67' "Change Conform Options settings if necessary..." pos:[104,552] width:144 height:32 align:#left
	--------------------------------
	HyperLink 'Hyp_copyright' "\xa9"
	HyperLink 'Hyp_copyrightYear' "2019"
	HyperLink 'Hyp_copyrightOwner' "SeasunGame"
	HyperLink 'Hyp_textVer' "Ver:"
	HyperLink 'Hyp_version' "2000.00.00"
	HyperLink 'Hyp_textBy' "by"
	HyperLink 'Hyp_editor' "Ou Jion"
	------------------------------------

	on rol_KG3DClothingAgentMesh open do
	(
		fn_setCopyrightInfo rol
		ckb_manuallyDelete.toolTip = "��ɫ�������ֶ�ɾ������Ҫ�����Ա��ֶ��޳�����������ص���Ƭ��"
	)
	on rol_KG3DClothingAgentMesh close do
	(
		rol_KG3DClothingAgentMesh = undefined
	)
	on btn_splitSkin pressed do
	(
		for obj in selection where ( PolyMeshObject == classof obj or Editable_mesh == classof obj or Editable_Poly == classof obj ) do
		(
			fn_splitObjMesh obj
		)
	)
	on rdo_agentStyle changed state do
	(
		if ( 1 == state ) do ( sld_ellipseSides.range = [2,100,sld_ellipseSides.value] )
		if ( 2 == state ) do
		(
			if ( 4>sld_ellipseSides.value ) do ( sld_ellipseSides.value = 4)
			sld_ellipseSides.range = [4,100,sld_ellipseSides.value]
		)
		sld_ellipseSides.text = "Ellipse Sides: ["+sld_ellipseSides.value as string+"]"
	)
	on btn_createAgent pressed do
	(
		max modify mode
		for obj in selection where ( undefined != obj.modifiers[#skin]) do
		(
			local mesh_obj,ary_sliceEllipse,matrix_axis
			
			if ( true == isvalidObj btn_centralAxis.object ) then
			(
				matrix_axis = btn_centralAxis.object.transform
			)
			else
			(
				if ( 1 == rdo_centralAxis.state ) then ( matrix_axis = obj.transform )
				else ( matrix_axis = matrix3 1 )
			)
			
			mesh_obj = obj
			mesh_obj.modifiers[#skin].enabled = ckb_skin.checked
			select mesh_obj
			ary_sliceEllipse = fn_loftByHeight mesh_obj spn_detail.value matrix_axis
			fn_createPlaneAgentLOD mesh_obj [sld_ellipseSides.value,sld_heightSegment.value] ary_sliceEllipse matrix_axis rdo_agentStyle.state rdo_surfaceMappingType.state chk_mappingSkin.checked chk_mappingVertsColor.checked
			
			if ( false == ckb_manuallyDelete.checked ) do
			(
				local bary_unWanted = #{1..$.faces.count}-( getFaceSelection $ )
				
				meshop.deletefaces $.baseobject bary_unWanted
			)
			mesh_obj.modifiers[#skin].enabled = ckb_skin.checked
		)
	)
	on spn_ellipseSides changed val do
	(
		sld_ellipseSides.value = val
	)
	on sld_ellipseSides changed val do
	(
		spn_ellipseSides.value = val
	)
	on spn_heightSegments changed val do
	(
		sld_heightSegment.value = val
	)
	on sld_heightSegment changed val do
	(
		spn_heightSegments.value = val
	)
	on rdo_centralAxis changed stat do
	(
		btn_centralAxis.object = undefined
		btn_centralAxis.text = "Select A Custom Obj As Central Axis"
	)
	on btn_centralAxis picked obj do
	(
		rdo_centralAxis.state = 0
	)
	on btn_mergeSkin pressed do
	(
		local bol_skin = true
		local aryMergeObjs = #()
		
		for obj in selection where ( PolyMeshObject == classof obj or Editable_mesh == classof obj or Editable_Poly == classof obj ) do
		(
			bol_skin = bol_skin and ( undefined != obj.modifiers[#skin] )
			append aryMergeObjs obj
		)
		if ( aryMergeObjs.count > 1 ) do
		(
			if ( true == bol_skin ) then
			(
				fn_mergeSkin aryMergeObjs 0.0
			)
			else
			(
				local newSkinObj = convertTo aryMergeObjs[1] Editable_Poly
				
				for n = 2 to aryMergeObjs.count do ( newSkinObj.EditablePoly.attach aryMergeObjs[n] newSkinObj )
			)
			
		)
	)
	on btn_relax pressed do with undo "Relax" on
	(
		for obj in selection where ( PolyMeshObject == classof obj or Editable_Poly == classof obj ) do
		(
			$.relaxAmount = spn_amount.value
			$.relaxIterations = spn_iterations.value
			$.relaxHoldOuterPoints = chk_holdOuterPoints.state
			$.relaxHoldBoundaryPoints = chk_holdBoundaryPoints.state
			
			$.EditablePoly.Relax()
		)
	)
	on spn_amount changed val do
	(
		for obj in selection where ( PolyMeshObject == classof obj or Editable_Poly == classof obj ) do ( $.relaxAmount = val )
	)
	on spn_iterations changed val do
	(
		for obj in selection where ( PolyMeshObject == classof obj or Editable_Poly == classof obj ) do ( $.relaxIterations = val )
	)
	on chk_holdOuterPoints changed state do
	(
		for obj in selection where ( PolyMeshObject == classof obj or Editable_Poly == classof obj ) do ( $.relaxHoldOuterPoints = state )
	)
	on chk_holdBoundaryPoints changed state do
	(
		for obj in selection where ( PolyMeshObject == classof obj or Editable_Poly == classof obj ) do ( $.relaxHoldBoundaryPoints = state )
	)
	on btn_conform pressed do
	(
		if ( 1 == selection.count ) do ( macros.run "PolyTools" "PolyDrawConform" )
	)
	on btn_conformSurface changed state do
	(
		if ( 1 == selection.count ) do 
		(
			macros.run "Ribbon - Modeling" "PolyDrawPickButton"
			macros.run "PolyTools" "PolyDrawTypeSurface"
			btn_conformSurface.text = "Surface:"+PBo_Pickobject.name
		)
		btn_conformSurface.state = false
	)
)

if ( true == createDialog rol_KG3DClothingAgentMesh ) do format ( "Create KG3D Clothing Agent Mesh," ) ( clearlistener() )


/*



		(
			newSkinObj.EditablePoly.attach aryObj[n] newSkinObj
		)


2025.09.25















