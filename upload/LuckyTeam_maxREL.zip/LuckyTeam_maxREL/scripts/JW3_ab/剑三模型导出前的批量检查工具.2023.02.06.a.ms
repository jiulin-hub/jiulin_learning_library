--    Start AnimOutputCheck_V1.00    --

/*	Readme
	---------------------------------------------------------------------
>>	AnimOutputCheck
	Version:		1.00
	Author:		Oujian [ Coo!Doggie | ţ���̹� ]
	E_Mail:		CoolDoggie@vip.sina.com
	Build on:		3dsMax 8. 2008-4-14, at Kingsoft Corp.
	Release Type:	In-Company ware
	---------------------------------------------------------------------
>>	Run script
		Pull this script file into your 3dsMax window.
	---------------------------------------------------------------------
>>	Function&Effect
		???
	---------------------------------------------------------------------
>>	Know bugs
	<None>
	---------------------------------------------------------------------
>>	Version history
	--	Ver 1.00
	2008-4-14 10:43:15 Created without DEMO.
	---------------------------------------------------------------------
>>	Modify
	delete:
	1.material check
	2.SKIN VertexWeight mutiple check
	add:
	1.SKIN link(bone_Limit) check
	---------------------------------------------------------------------
	COPYRIGHT(C) Kingsoft Corp, ALL RIGHTS RESERVED.
*/


/*  �ű�����ǰ��׼������  */
try(cui.UnRegisterDialogBar rol_nameCheck) catch()
try(destroyDialog rol_nameCheck) catch()
try(closeRolloutFloater rol_nameCheck) catch()

try(cui.UnRegisterDialogBar rol_linkCheck) catch()
try(destroyDialog rol_linkCheck) catch()
try(closeRolloutFloater rol_linkCheck) catch()

try(cui.UnRegisterDialogBar rol_objWeightCheck) catch()
try(destroyDialog rol_objWeightCheck) catch()
try(closeRolloutFloater rol_objWeightCheck) catch()

try(cui.UnRegisterDialogBar rol_insideBoneCheck) catch()
try(destroyDialog rol_insideBoneCheck) catch()
try(closeRolloutFloater rol_insideBoneCheck) catch()

try(cui.UnRegisterDialogBar rol_FBBoneCheck) catch()
try(destroyDialog rol_FBBoneCheck) catch()
try(closeRolloutFloater rol_FBBoneCheck) catch()

try(cui.UnRegisterDialogBar rol_AnimOutputCheck) catch()
try(destroyDialog rol_AnimOutputCheck) catch()
try(closeRolloutFloater rol_AnimOutputCheck) catch()

try(cui.UnRegisterDialogBar rol_transCheck) catch()
try(destroyDialog rol_transCheck) catch()
try(closeRolloutFloater rol_transCheck) catch()

-- try(cui.UnRegisterDialogBar rol_materialIDCheck) catch()
-- try(destroyDialog rol_materialIDCheck) catch()
-- try(closeRolloutFloater rol_materialIDCheck) catch()

rol_nameCheck = undefined
rol_linkCheck = undefined
rol_objWeightCheck = undefined
rol_insideBoneCheck = undefined
rol_FBBoneCheck = undefined
rol_AnimOutputCheck  = undefined
rol_transCheck = undefined
--rol_materialIDCheck = undefined


/*  ִ�нű�����������ⲿ�ļ�  */

/*  ȫ�ֱ�������  */

--	< ȫ�ֽ���������� >
--		�û������档
-- Global 	rol_nameCheck,rol_materialCheck,rol_objWeightCheck,rol_AnimOutputCheck
Global 	rol_nameCheck,rol_linkCheck,rol_objWeightCheck,rol_transCheck,rol_AnimOutputCheck

--	< ȫ�ֺ����������� >
Global 	nameEro = #()
--Global 	materialEro = #()
Global	linkEro = #()
Global 	weightEro = #()
Global 	insideBoneEro = #()
Global 	FBBoneEro = #(#(),#())
Global	transEro = #()
Global  faceLimitEro = undefined
	
Global 	defaultWeight = 0.05
--Global 	matIDEro = #()
Global	my_files = #()
Global	fStream
Global	file_index = 1
Global	logPath = "D:/maxCheckResult.log"
	
struct 	checkInfo (isSelect,name,stat)
struct 	errorLinkInfo (objc,ero)
struct 	errorWeightObjInfo (objc,ero,eroVertex_ary)
struct 	errorLoseBoneInfo (objc,loseBone,weightBone)
struct 	errorFBBoneInfo (eroFB,noWeightFBR)
struct	errorBoneTransInfo (objc,ero)
--struct 	errorMatIDInfo (objc,eroFace_ary)
struct	errorFaceLimitInfo (objc,ero)
--	< ȫ�ֹ��߱������� >

--	< ����ȫ�ֱ������� >

/*  ȫ�ֺ���  */
	--	��������log�ļ�
	Function fn_create_log = 
	(
		if (doesFileExist logPath) == false then
		(
			print("��־�ļ������ڣ�����log�ļ�")
			fs = CreateFile logPath
			if fs == undefined then
				print("�޷�����log�ļ�" + "maxCheckResult.log")
			else
				close fs
		)
	)
	
	--	��ȱ���·���µ�����max�ļ�
	Function fn_getMaxFile	maxPath	=
	(
		if maxPath[1] != "\\" then(
			for i=2 to maxPath.count do(
				if maxPath[i] == "\\" then
					maxPath[i] = "/"
			)
		)
		if my_files.count == 0 then(
			join my_files (getFiles (maxPath+"/*.max"))
			dir_array = GetDirectories(maxPath+"/*")
			for d in dir_array do
				join dir_array (GetDirectories (d+"/*"))
			for f in dir_array do
				join my_files (getFiles (f + "*.max"))
		)
	)
	
	--���ؼ���max�ļ�
	Function fn_load_maxFile strfile strMaxPath =
	(
		loadMaxFile strfile useFileUnits:true quiet:true --����max�ļ�
		file_name = maxFilePath + maxFileName
		maxPath_name = substring file_name (strMaxPath.count+1) -1
		format "\n\n[ģ����]%\n" maxPath_name to: fStream
	)
		
	--���û�������	
	Function fn_reset =
	(
		nameEro = #()
		linkEro = #()
		weightEro = #()
		insideBoneEro = #()
		FBBoneEro = #(#(),#())
		transEro = #()
		faceLimitEro = #()
	)
	
	
	--	SKIN�������Ƽ�顣
	Function fn_skinObjNameCheck obj_ary =
	(
		local Ero_ary = #()
		local skinObj_ary = #()
		local nameStr_ary = #("body","belt","hand","head","face","leg")
		
		--	��ȡ���������д�SKIN�޸��������嵽���飺skinObj_ary �С�
		for obj in obj_ary where obj.modifiers.count != 0 do
		(
			for n in 1 to obj.modifiers.count where classOf obj.modifiers[n] == Skin do
			(
				append skinObj_ary obj
				exit
			)
		)
		--	������ơ�
		for obj in skinObj_ary do
		(
			local ero = true
			obj_name = obj.name as string
			arr_on = filterString obj_name "_"
			if arr_on.count > 0 then(
				if(findItem nameStr_ary arr_on[arr_on.count]) == 0 do
				(
					ero = false
				)
			)
			if not ero do append Ero_ary obj
		)
		return Ero_ary
	)

	--	SKIN����linkֵ��顣
	Function fn_skinObjLinkCheck obj_ary = 
	(
		local skinObj_ary = #()
		local linkEro_ary = #()
		--	��ȡ���������д�SKIN�޸��������嵽���飺skinObj_ary �С�
		for obj in obj_ary where obj.modifiers.count != 0 do
		(
			for n in 1 to obj.modifiers.count where classOf obj.modifiers[n] == Skin do
			(
				append skinObj_ary obj
				exit
			)
		)
		for obj in skinObj_ary do
		(
			local obj_info = errorLinkInfo objc:obj
			if obj.modifiers[#skin].bone_Limit != 4 then(
				obj_info.ero = "Skin��linkֵ��Ϊ4"
				append linkEro_ary obj_info
			)
		)
		return linkEro_ary
	)	
	
	--	SKIN����Ȩ��ֵ��顣
	Function fn_skinObjVertWeightCheck obj_ary = 
	(
		local eroObj_ary = #()
		local skinObj_ary = #()
		local sel_obj = selection as array
		
		--	��ȡ���������д�SKIN�޸��������嵽���飺skinObj_ary �С�
		for obj in obj_ary where obj.modifiers.count != 0 do
		(
			for n in 1 to obj.modifiers.count where classOf obj.modifiers[n] == Skin do
			(
				append skinObj_ary obj
				exit
			)
		)
		--	
		for obj in skinObj_ary do
		(
			local index
			--	struct 	errorWeightObjInfo (objc,eroTpye,eroVertex_ary)
			local obj_info = errorWeightObjInfo objc:obj
			
			--	��ȡSKIN�޸����ڶ�ջ�е�����λ�õ�index�С�
			for n in 1 to obj.modifiers.count where classOf obj.modifiers[n] == Skin do
			(
				index = n
				exit
			)
			--	ѡ�����岢ת�Ƶ��޸���塣
			select obj
			max modify mode
			--	�Ƴ�Ȩ��Ϊ 0 ����Ϣ��
			obj.modifiers[index].clearZeroLimit = 0
			skinOps.RemoveZeroWeights obj.modifiers[index]
			--	�ر�WeightTool��
			skinOps.closeWeightTool obj.modifiers[index]
			--	Skin��û�й�����
			if skinOps.GetNumberBones obj.modifiers[index] == 0 then
			(
				obj_info.ero = "Skin��û�й���"
			)
			--	Skin���й�������鶥�㡣
			else
			(
				--	��ÿ��������м�顣 (�ģ�ֻ�������Ȩ����Ϣ�������Ȩ�ر���)��������������
				for n in 1 to skinOps.GetNumberVertices obj.modifiers[index] do
				(
					
					local weightEro_bol = false
					
					--	�ö�����Ȩ����Ϣ��
					if skinOps.GetVertexWeightCount obj.modifiers[index] n == 0 then
					(
						if obj_info.eroVertex_ary == undefined do obj_info.eroVertex_ary = #()
						append obj_info.eroVertex_ary n
						if obj_info.ero == undefined then
						(
							obj_info.ero = "��Ȩ��"
						)
						weightEro_bol = false
					)
					--	��Ȩ�أ����Ȩ���Ƿ�ΪdefaultWeight�ı�����
					else
					(
						weightEro_bol = true
					)
				)
			)
			if obj_info.ero != undefined then append eroObj_ary obj_info
		)
		select sel_obj
		return eroObj_ary
	)
	
	--	Skin�����۹�����顣	
	Function fn_insideBoneCheck obj_ary =
	(
		local eroInside = #()
		local skinObj_ary = #()
		local customNameObj_ary = #()
		local selObj_ary = selection as array
		local nameStr_ary = #("_body","_hand","_head")
		
		--	��ȡ���������д�SKIN�޸��������嵽���飺skinObj_ary �С�
		for obj in obj_ary where obj.modifiers.count != 0 do
		(
			for n in 1 to obj.modifiers.count where classOf obj.modifiers[n] == Skin do
			(
				append skinObj_ary obj
				exit
			)
		)
		--	������ƹ��ˡ�
		for obj in skinObj_ary do
		(
			for str in nameStr_ary do
			(
				if findString obj.name str != undefined do
				(
					append customNameObj_ary obj
					exit
				)
			)
		)
		for obj in customNameObj_ary do
		(
			--	struct 	errorLoseBoneInfo (objc,loseBone,weightBone)
			local info = errorLoseBoneInfo objc:obj loseBone:#() weightBone:#()
			
			select obj
			max modify mode
			--	�ر�WeightTool��
			skinOps.closeWeightTool obj.modifiers[#Skin]
			--	���Ӧ�ð�������������Ƿ�ȱʧ��
			if (findString obj.name "_head") != undefined do info.loseBone = #("B_Hat")
			if (findString obj.name "_hand") != undefined do info.loseBone = #("B_RH","B_LH")
			if (findString obj.name "_body") != undefined do info.loseBone = #("B_LC","B_Long","B_LP","B_RC","B_RP","B_Spine","B_Spine2")
			for n in 1 to skinOps.GetNumberBones obj.modifiers[#Skin] do
			(
				local b_name = skinOps.GetBoneName obj.modifiers[#Skin] n 0
				
				if findItem info.loseBone b_name != 0 do
				(
					deleteItem info.loseBone (findItem info.loseBone b_name)
					append info.weightBone b_name
				)
			)
			--	���Ӧ�ð�������������Ƿ���Ȩ�ء�
			local temp = #()
			for n in 1 to (skinOps.GetNumberVertices obj.modifiers[#Skin]) where info.weightBone.count != 0 do
			(
				for m in 1 to (skinOps.GetVertexWeightCount obj.modifiers[#Skin] n) do
				(
					local bone_int = skinOps.GetVertexWeightBoneID obj.modifiers[#Skin] n m
					local b_name = skinOps.GetBoneName obj.modifiers[#Skin] bone_int 0
					
					for i_weightBone in info.weightBone do
					(
						if b_name == i_weightBone do
						(
							if findItem temp i_weightBone == 0 do append temp i_weightBone
							exit
						)
					)
				)
			)
			info.weightBone = temp
			if (info.loseBone.count + info.weightBone.count) != 0 do append eroInside info
		)
		clearSelection()
		select selObj_ary
		return eroInside
	)
	
	--	�������FB��顣
	Function fn_FBBoneCheck obj_ary=
	(
		local selObj_ary = selection as array
		local ero_ary = #()
		local FBBone_ary = #()
		local FBRBone_ary = #()
		local FBRParent_ary = #()
		local skinObj_ary = #()
		local info = errorFBBoneInfo eroFB:#() noWeightFBR:#()
		
		max modify mode
		--	�ҳ�FB���塣
		for obj in obj_ary where classOf obj == BoneGeometry do
		(
			if findString obj.name "FB" != undefined do append FBBone_ary obj
		)
		--	���FB�Ƿ�����BIPϵͳ��
		for obj in FBBone_ary do
		(
			if obj.parent == undefined then
			(
				append info.eroFB obj
			)
			else
			(
				local bipParent
				local i_parent = obj.parent
				
				while i_parent != undefined do
				(
					if classOf i_parent == Biped_Object then
					(
						bipParent = i_parent
						exit
					)
					else
					(
						if i_parent.parent == undefined and classOf i_parent == BoneGeometry and findString i_parent.name "headbone" == 1 then
						(
							bipParent = i_parent
							exit
						)
						else
						(
							i_parent = i_parent.parent
						)
					)
				)
				if bipParent == undefined do append info.eroFB obj
			)
		)
		--	��ȡFBR�ĸ��������ơ�
		for obj in FBBone_ary do
		(
			if findString obj.name "FBR" != undefined do
			(
				if obj.parent != undefined do append FBRParent_ary obj.parent.name
			)
		)
		--	��ȡ���������д�SKIN�޸��������嵽���飺skinObj_ary �С�
		for obj in obj_ary where obj.modifiers.count != 0 do
		(
			for n in 1 to obj.modifiers.count where classOf obj.modifiers[n] == Skin do
			(
				append skinObj_ary obj
				exit
			)
		)
		for obj in skinObj_ary do
		(
			select obj
			for n in 1 to skinOps.GetNumberBones obj.modifiers[#Skin] do
			(
				--	��ǰ���Ĺ��������ơ�
				local b_name = skinOps.GetBoneName obj.modifiers[#Skin] n 0
				
				--	�����������д��С�FBR���Ĺ�����
				if findItem FBRParent_ary b_name != 0 do
				(
					--	Ȩ����ϢΪ���ޡ�
					local weight_bol = false
					
					--	�����е��в�ѯ�ù�����Ȩ�ء�
					for m in 1 to skinOps.GetNumberVertices obj.modifiers[#Skin] do
					(
						for x in 1 to skinOps.GetVertexWeightCount obj.modifiers[#Skin] m do
						(
							if (skinOps.GetVertexWeightBoneID obj.modifiers[#Skin] m x) == n do weight_bol = true
						)
						if weight_bol do exit
					)
					if not(weight_bol) do append info.noWeightFBR #(b_name,obj.name)
				)
			)
		)
		ero_ary = #(info.eroFB,info.noWeightFBR)
		clearSelection()
		select selObj_ary
		return ero_ary
	)
	
	--	������Ϣ��顣
	Function fn_BoneTransCheck type =
	(
		f1_name = #("point_lp","point_rp","point_spine","point_long","point_lc","point_rc","point_spine2","point_rh","point_lh","point_hat","s_rp","s_lp","s_spine","s_long","s_spine2","s_rc","s_lc","s_fxmid","s_rh","s_lh","s_hat","s_fxtop","s_face","b_rp","x_rpnub","b_lp","x_lpnub","b_spine","x_spinenub","b_long","x_longnub","b_spine2","x_spine2nub","b_rc","x_rcnub","b_lc","x_lcnub","b_rh","x_rhnub","b_lh","x_lhnub","b_hat","x_hatnub","bone_shd_r","bone_r_armtwist","bone_shd_l","bone_l_armtwist","add_l102","add_l101","l1nub","add_r102","add_r101","r1nub","add_r502","add_r501","r5nub","add_r402","add_r401","r4nub","add_l402","add_l401","l4nub","add_l502","add_l501","l5nub")
		f1_msg = #(#([3.96793,-2.14192,27.7292],[1,1,1]),#([-3.83343,-2.14192,27.7473],[1,1,1]),#([1.73197e-005,2.09518,28.6944],[1,1,1]),#([-1.45263,3.23046,28.3777],[1,1,1]),#([4.55027,2.76581,39.6807],[1,1,1]),#([-5.18945,3.25581,39.5093],[1,1,1]),#([5.86044e-006,5.55988,33.6678],[1,1,1]),#([-11.4562,1.50336,23.4173],[1,1,1]),#([11.2154,1.5024,23.4653],[1,1,1]),#([-0.000182382,-1.33027,43.5356],[1,1,1]),#([-3.83343,-2.14192,27.7473],[0.6,0.6,0.6]),#([3.96793,-2.14192,27.7292],[0.6,0.6,0.6]),#([1.52913e-005,2.09518,28.6944],[0.6,0.6,0.6]),#([-1.45263,3.23046,28.3777],[0.6,0.6,0.6]),#([6.81856e-006,5.55988,33.6678],[0.6,0.6,0.6]),#([-5.18945,3.25581,39.5093],[0.6,0.6,0.6]),#([4.55027,2.76581,39.6807],[0.6,0.6,0.6]),#([7.56961e-006,-1.10521,33.5158],[0.6,0.6,0.6]),#([-11.4562,1.50336,23.4173],[0.6,0.6,0.6]),#([11.2154,1.5024,23.4653],[0.6,0.6,0.6]),#([-0.000186043,-1.33027,43.5356],[0.6,0.6,0.6]),#([3.01053e-005,-2.51228,50.5686],[0.6,0.6,0.6]),#([7.54966e-006,0.312131,38.5746],[1,1,1]),#([-3.83343,-2.14192,27.7473],[0.6,0.6,0.6]),#([-3.83343,-2.14192,27.7473],[1,1,1]),#([3.96793,-2.14192,27.7292],[0.6,0.6,0.6]),#([3.96793,-2.14192,27.7292],[1,1,1]),#([1.52913e-005,2.09518,28.6944],[0.6,0.6,0.6]),#([1.73197e-005,2.09518,28.6944],[1,1,1]),#([-1.45263,3.23046,28.3777],[0.6,0.6,0.6]),#([-1.45263,3.23046,28.3777],[1,1,1]),#([6.81855e-006,5.55988,33.6678],[0.6,0.6,0.6]),#([5.86044e-006,5.55988,33.6678],[1,1,1]),#([-5.18945,3.25581,39.5093],[0.6,0.6,0.6]),#([-5.18945,3.25581,39.5093],[1,1,1]),#([4.55027,2.76581,39.6807],[0.6,0.6,0.6]),#([4.55027,2.76581,39.6807],[1,1,1]),#([-11.4562,1.50336,23.4173],[0.6,0.6,0.6]),#([-11.4562,1.50336,23.4173],[1,1,1]),#([11.2154,1.5024,23.4653],[0.6,0.6,0.6]),#([11.2154,1.5024,23.4653],[1,1,1]),#([-0.000186043,-1.33027,43.5356],[0.6,0.6,0.6]),#([-0.000182382,-1.33027,43.5356],[1,1,1]),#([-3.46815,0.485488,36.9559],[0.8,0.8,0.8]),#([-3.63028,0.653466,35.0847],[1,1,1]),#([3.46807,0.48549,36.9559],[0.8,0.8,0.8]),#([3.63028,0.653475,35.0847],[1,1,1]),#([2.3462,-3.54852,23.0375],[1,1,1]),#([1.82835,-3.51968,28.0549],[1,1,1]),#([1.82835,-3.51968,28.0549],[1,1,1]),#([-2.36041,-3.56591,23.039],[0.999999,1,1]),#([-1.82821,-3.51986,28.0548],[1,1,1]),#([-1.82821,-3.51986,28.0548],[1,1,1]),#([-4.41556,-0.650764,23.9892],[1,1,1]),#([-3.1413,-1.11731,27.5265],[1,1,1]),#([-3.1413,-1.11731,27.5265],[1,1,1]),#([-2.45121,2.65385,24.2794],[1.12774,1,1]),#([-1.80651,1.21337,28.0116],[1,1,1]),#([-1.80651,1.21337,28.0116],[1,1,1]),#([2.45193,2.67598,24.2882],[0.8632,1,1]),#([1.82173,1.23788,27.9175],[1,1,1]),#([1.82174,1.23788,27.9175],[1,1,1]),#([4.41557,-0.650762,23.9892],[1,1,1]),#([3.14357,-1.11644,27.5204],[1,1,1]),#([3.14357,-1.11644,27.5204],[1,1,1]))
		f2_name = #("point_lp","point_rp","point_spine","point_spine2","point_rc","point_lc","point_long","point_hat","point_rh","point_lh","point06","point05","point04","point03","point02","point01","point15","point14","point13","point12","point11","point10","point09","point08","point07","bone38nub","add_r403","add_r402","add_r401","bone35nub","add_l403","add_l402","add_l401","bone10nub","add_m103","add_m102","add_m101","bone34nub","add_l103","add_l102","add_l101","bone37nub","add_r103","add_r102","add_r101","bone_r_thightwist","point_chest_r","point_chest_l","bone_chest_l","bone_chest_r","bone_shd_r","bone_r_armtwist","bone_shd_l","bone_l_armtwist","bone_l_thightwist","bone20nub","bone19nub","bone23nub","bone22nub","bone26nub","bone25nub","add_r203","add_r202","add_r201","bone29nub","bone28nub","bone32nub","bone31nub","bone36nub","add_r303","add_r302","add_r301","bone03nub","bone02nub","bone06nub","bone05nub","bone09nub","bone08nub","add_l203","add_l202","add_l201","bone12nub","bone11nub","bone15nub","bone14nub","bone33nub","add_l303","add_l302","add_l301","b_rp","b_lp","b_spine","b_lc","b_rc","b_spine2","b_long","b_hat","b_rh","b_lh","s_rp","s_lp","s_spine","s_lc","s_rc","s_spine2","s_fxmid","s_long","s_fxtop","s_hat","s_face","s_rh","s_lh")
		f2_msg = #(#([5.8522,-0.946671,41.9223],[1,1,1]),#([-5.85231,-0.946679,41.9223],[1,1,1]),#([1.31657e-005,4.41815,43.1456],[1,1,0.999999]),#([1.98287e-005,8.08299,49.3717],[1,1,1]),#([-5.27552,5.50105,57.304],[1,1,1]),#([5.18594,5.05028,57.201],[1,1,1]),#([-3.15086,5.02838,39.2278],[1,1,1]),#([5.50926e-006,-0.610498,60.8961],[1,1,1]),#([-19.5333,0.640368,38.2481],[1,1,1]),#([19.6185,0.644058,38.0992],[1,1,1]),#([-3.83173,-4.59897,26.6359],[1,1,1]),#([-3.28523,-3.46661,34.7392],[1,1,1]),#([-2.80922,-2.48029,41.7975],[1,1,1]),#([3.80357,-4.58297,26.6822],[1,1,1]),#([3.27777,-3.46705,34.6962],[1,1,1]),#([2.81177,-2.47807,41.7986],[1,1,1]),#([-3.53936,5.88825,26.0618],[1,1,1]),#([-3.09287,4.20763,34.5692],[1,1,1]),#([-2.76542,2.97507,40.8084],[1,1,1]),#([2.71993e-007,6.36538,26.0076],[1,1,1]),#([2.75861e-007,4.3715,34.1755],[1,1,1]),#([8.95119e-007,2.76221,40.768],[1,1,1]),#([3.54046,5.88824,26.0619],[1,1,1]),#([3.09427,4.20762,34.5692],[1,1,1]),#([2.76703,2.97506,40.8085],[1,1,1]),#([-4.05902,7.84433,16.1601],[0.999998,0.999999,1]),#([-3.53935,5.88825,26.0618],[0.999998,0.999999,1]),#([-3.09287,4.20763,34.5692],[0.999999,0.999999,1]),#([-2.76542,2.97507,40.8084],[0.999999,0.999999,1]),#([4.0598,7.84435,16.16],[1,1,0.999999]),#([3.54046,5.88825,26.0619],[1,1,0.999999]),#([3.09427,4.20762,34.5692],[1,1,0.999999]),#([2.76703,2.97506,40.8085],[1,1,0.999999]),#([4.92251e-006,8.77205,16.1485],[1,1,1]),#([3.95339e-006,6.36536,26.0076],[1,1,1]),#([1.15296e-006,4.3715,34.1755],[1,1,1]),#([1.12675e-006,2.76221,40.768],[1,1,1]),#([4.41823,-5.88745,17.3141],[1,0.999999,0.999999]),#([3.80357,-4.58296,26.6822],[1,0.999999,0.999999]),#([3.27777,-3.46706,34.6962],[1,0.999999,0.999999]),#([2.81177,-2.47807,41.7986],[1,0.999999,0.999999]),#([-4.46373,-5.90847,17.2649],[1,1,0.999999]),#([-3.83173,-4.59897,26.6359],[1,1,0.999999]),#([-3.28524,-3.46661,34.7392],[1,1,0.999999]),#([-2.80922,-2.48029,41.7975],[1,1,0.999999]),#([-3.03472,0.262899,36.7399],[1,1,1]),#([-1.94242,-2.01285,49.0885],[1,1,1]),#([1.94252,-2.01285,49.0885],[1,1,1]),#([1.94252,-2.01286,49.0885],[1,1,1]),#([-1.94242,-2.01285,49.0885],[1,1,1]),#([-3.82756,1.92863,54.5121],[1,1,1]),#([-4.72707,1.93497,52.3275],[1,1,1]),#([3.82747,2.76466,54.3685],[1,1,1]),#([4.72707,1.93498,52.3275],[1,1,1]),#([3.03472,0.262909,36.7399],[1,1,1]),#([-3.86166,0.669334,18.9005],[1,1,1]),#([-3.3973,-4.45627,28.4394],[1,1,1]),#([-3.87354,0.618199,20.2113],[1,1,1]),#([-3.68329,-5.05751,23.002],[1,1,1]),#([-3.96583,1.0091,16.8565],[1,1,1]),#([-4.03147,-5.83391,16.3875],[1,1,1]),#([-3.68325,-5.05751,23.002],[1,1,1]),#([-3.3973,-4.45625,28.4391],[1,1,1]),#([-3.07182,-3.7546,34.6035],[1,1,1]),#([-3.68979,0.862438,17.4694],[1,1,1]),#([-3.57709,5.53433,27.9359],[1,1,1]),#([-3.93556,1.4191,12.8312],[1,1,1]),#([-3.87967,6.73909,22.2239],[1,1,1]),#([-4.17476,7.91403,16.6535],[1,1,1]),#([-3.87967,6.73915,22.2239],[1,1,1]),#([-3.57708,5.53437,27.9358],[1,0.999999,1]),#([-3.22827,4.12673,34.4907],[1,1,1]),#([3.86173,0.669328,18.9005],[1,0.999999,1]),#([3.39747,-4.45625,28.4394],[1,1,1]),#([3.87354,0.618226,20.2113],[1,1,1]),#([3.68457,-5.0575,23.002],[1,1,1]),#([3.96568,1.00914,16.8565],[0.999999,1,1]),#([4.03398,-5.8338,16.3876],[0.999999,1,1]),#([3.68457,-5.0575,23.002],[1,1,1]),#([3.39747,-4.45625,28.4391],[1,0.999999,1]),#([3.07199,-3.7546,34.6035],[0.999999,1,1]),#([3.68969,0.85471,17.4826],[1,0.999999,1]),#([3.57328,5.51094,28.0436],[1,0.999999,1]),#([3.93667,1.41126,12.8446],[1,0.999999,1]),#([3.8786,6.71551,22.3319],[1,0.999999,1]),#([4.17638,7.89033,16.7616],[1,0.999999,1]),#([3.87861,6.71559,22.3319],[1,0.999999,1]),#([3.57328,5.51094,28.0436],[1,0.999999,1]),#([3.22807,4.12675,34.4907],[1,1,1]),#([-5.85231,-0.946677,41.9223],[1,1,1]),#([5.8522,-0.946671,41.9223],[1,1,1]),#([1.27284e-005,4.41815,43.1456],[1,1,1]),#([5.18594,5.05028,57.201],[1,1,1]),#([-5.27552,5.50105,57.304],[1,1,1]),#([1.98169e-005,8.08299,49.3717],[1,1,1]),#([-3.15086,5.02837,39.2278],[1,1,1]),#([5.19329e-006,-0.610499,60.8961],[1,1,1]),#([-19.5333,0.640372,38.2481],[1,1,1]),#([19.6185,0.644059,38.0992],[1,1,1]),#([-5.85231,-0.946678,41.9223],[1,1,1]),#([5.8522,-0.94667,41.9223],[1,1,1]),#([1.27284e-005,4.41815,43.1456],[1,1,1]),#([5.18595,5.05028,57.201],[1,1,1]),#([-5.27552,5.50105,57.304],[1,1,1]),#([1.98169e-005,8.08299,49.3717],[1,1,1]),#([3.53954e-007,0.678814,46.6314],[1,1,0.999999]),#([-3.15086,5.02837,39.2278],[1,1,1]),#([1.79429e-005,0.885803,71.5767],[1,1,1]),#([5.19329e-006,-0.610499,60.8961],[1,1,1]),#([-2.17184e-006,1.10712,56.1824],[1,1,1]),#([-19.5333,0.640374,38.2481],[1,1,1]),#([19.6185,0.644059,38.0992],[1,1,1]))
		m1_name = #("s_rp","s_lp","s_spine","s_long","s_spine2","s_rc","s_lc","s_fxmid","s_rh","s_lh","s_face","s_hat","s_fxtop","b_rp","b_lp","b_spine","b_long","b_spine2","b_rc","b_lc","b_rh","b_lh","b_hat","point_lp","point_rp","point_spine","point_long","point_lc","point_rc","point_spine2","point_rh","point_lh","point_hat","s_ltulwar","s_rtulwar","s_rod","s_bow","s_epee","s_pot","s_flute","add_l402nub","add_l402","add_l401","point04","add_r402nub","add_r402","add_r401","point03","add_r102nub","add_r102","add_r101","point02","add_l102nub","add_l102","add_l101","point01")
		m1_msg = #(#([-3.9739,-1.31944,25.2795],[1,1,1]),#([3.98817,-1.29943,25.2384],[1,1,1]),#([9.08219e-006,5.5534,26.4156],[1,1,1]),#([-0.924271,5.40583,27.1654],[1,1,1]),#([0.0698138,7.55692,30.1498],[1,1,1]),#([-6.59779,3.79149,37.7758],[1,1,1]),#([6.13856,2.71782,37.863],[1,1,1]),#([-3.58076e-007,1.01151,29.884],[1,1,1]),#([-11.2598,1.15132,21.5084],[1,1,1]),#([11.2992,1.9685,20.8661],[1,1,1]),#([-9.8137e-007,0.679526,36.5746],[1,1,1]),#([0.00375405,-0.623714,41.2171],[1,1,1]),#([1.41521e-005,1.27595,51.9589],[1,1,1]),#([-3.97389,-1.31944,25.2795],[1,1,1]),#([3.98817,-1.29943,25.2384],[1,1,1]),#([9.08219e-006,5.5534,26.4156],[1,1,1]),#([-0.92427,5.40583,27.1654],[1,1,1]),#([0.0698134,7.55691,30.1498],[1,1,1]),#([-6.59779,3.79149,37.7758],[1,1,1]),#([6.13856,2.71782,37.863],[1,1,1]),#([-11.2598,1.15132,21.5084],[1,1,1]),#([11.2992,1.9685,20.8661],[1,1,1]),#([0.00375405,-0.623714,41.2171],[1,1,1]),#([7.12291,-2.61468,28.5062],[1,1,1]),#([-7.02512,-2.67673,28.6583],[1,1,1]),#([9.2724e-006,5.5534,26.4156],[1,1,1]),#([-2.24658,7.22342,25.6055],[1,1,1]),#([5.06356,5.52755,40.3701],[1,1,1]),#([-5.06362,5.52755,40.3701],[1,1,1]),#([3.26316e-005,9.70059,33.9416],[1,1,1]),#([-11.1595,2.09002,20.2096],[1,1,1]),#([11.1595,2.09005,20.2096],[1,1,1]),#([5.46062e-006,0.307456,43.0818],[1,1,1]),#([-2.72042,4.77952,24.4819],[1,1,1]),#([0.766881,5.16765,25.8054],[1,1,1]),#([-8.49345,4.62234,25.2995],[1,1,1]),#([-10.6555,7.05811,24.6967],[1,1,1]),#([-16.6245,5.91436,27.7672],[1,1,1]),#([-1.32334,3.16019,28.1292],[1,1,1]),#([-2.40406,4.48633,31.0723],[1,1,1]),#([2.36221,5.43211,14.2371],[1,1,1]),#([2.36221,4.06864,19.6283],[1,1,1]),#([2.36221,2.55456,25.6149],[1,1,1]),#([2.36221,2.55456,25.6149],[1,1,1]),#([-2.3622,5.42445,14.2675],[1,1,1]),#([-2.3622,4.06865,19.6283],[1,1,1]),#([-2.3622,2.55456,25.6149],[1,1,1]),#([-2.3622,2.55456,25.6149],[1,1,1]),#([-2.36221,-4.05193,13.4621],[1,1,1]),#([-2.36221,-3.29863,19.67],[1,1,1]),#([-2.3622,-2.57882,25.7369],[1,1,1]),#([-2.3622,-2.57882,25.7369],[1,1,1]),#([2.3622,-4.05264,13.4566],[1,1,1]),#([2.36221,-3.29655,19.6875],[1,1,1]),#([2.36221,-2.57882,25.7369],[1,1,1]),#([2.36221,-2.57882,25.7369],[1,1,1]))
		m2_name = #("bone10nub","add_m103","add_m102","add_m101","bone35nub","add_l403","add_l402","add_l401","bone38nub","add_r403","add_r402","add_r401","bone37nub","add_r103","add_r102","add_r101","bone34nub","add_l103","add_l102","add_l101","point_rp","point_lp","point_spine","point_rh","point ȭ�׶�λ��r","point_lh","point ȭ�׶�λ��l","point_hat","point_spine2","point_rc","point_lc","point_long","point03","point02","point01","point15","point14","point13","point12","point11","point10","point09","point08","point07","point06","point05","point04","b_lp","b_rp","b_spine","b_rh","b_lh","b_hat","b_lc","b_rc","b_spine2","b_long","s_lp","s_rp","s_spine","s_rh","s_lh","s_face","s_hat","s_fxtop","s_fxmid","s_lc","s_rc","s_spine2","s_long","bone_l_thightwist","bone_r_thightwist","bone_shd_r","bone_r_armtwist","bone_shd_l","bone_l_armtwist","point100nub","bone09nub","bone08nub","add_l203","bone06nub","bone05nub","add_l202","bone03nub","bone02nub","add_l201","bone33nub","add_l303","bone15nub","bone14nub","add_l302","bone12nub","bone11nub","add_l301","bone36nub","add_r303","bone32nub","bone31nub","add_r302","bone29nub","bone28nub","add_r301","bone26nub","bone25nub","add_r203","bone23nub","bone22nub","add_r202","bone20nub","bone19nub","add_r201")
		m2_msg = #(#([1.25549e-005,8.24966,13.9467],[1,1,1]),#([8.78486e-006,6.40707,24.91],[1,1,1]),#([2.40014e-006,4.56668,35.8603],[1,1,1]),#([3.64451e-006,3.45525,42.4543],[1,1,1]),#([4.27218,7.42019,14.4172],[1,0.999999,1]),#([3.71621,5.7638,25.0799],[1,0.999999,1]),#([3.15128,4.08071,35.9145],[1,1,1]),#([2.7909,3.00704,42.826],[1,1,1]),#([-4.27169,7.42021,14.4171],[1,1,1]),#([-3.71592,5.76381,25.0799],[1,1,1]),#([-3.15119,4.08072,35.9145],[1,1,1]),#([-2.79094,3.00704,42.826],[1,1,1]),#([-5.06084,-5.5186,17.3636],[1,0.999999,0.999999]),#([-3.91454,-5.15762,26.949],[1,0.999999,0.999999]),#([-2.77513,-4.79882,36.4766],[1,1,0.999999]),#([-2.11496,-4.59093,41.9969],[1,1,0.999999]),#([5.032,-5.51665,17.4138],[1,0.999998,1]),#([3.89499,-5.15583,26.9956],[1,0.999998,1]),#([2.7751,-4.80045,36.433],[1,0.999999,1]),#([2.11487,-4.59093,41.9969],[1,0.999999,1]),#([-7.02512,-3.30987,45.4427],[1,1,1]),#([7.12291,-3.26363,45.285],[1,1,1]),#([8.2364e-006,4.72683,47.1521],[1,1,0.999999]),#([-15.0667,0.455185,38.5337],[1,1,1]),#([-15.0667,0.455185,38.5337],[1,1,1]),#([15.0667,0.455233,38.5337],[1,1,1]),#([15.0667,0.455233,38.5337],[1,1,1]),#([6.78649e-006,-1.15608,70.25],[1,1,1]),#([3.0433e-005,9.4042,53.1084],[1,1,1]),#([-5.06362,7.14967,60.4334],[1,1,1]),#([5.06356,7.14967,60.4334],[1,1,1]),#([-2.24658,4.74031,45.7683],[1,1,1]),#([-3.91453,-5.15761,26.949],[1,1,1]),#([-2.77513,-4.79881,36.4766],[1,1,1]),#([-2.11496,-4.59093,41.9969],[1,1,1]),#([5.25814e-006,6.40396,24.9095],[1,1,1]),#([3.21293e-006,4.56357,35.8598],[1,1,1]),#([3.88292e-006,3.45525,42.4543],[1,1,1]),#([3.71621,5.76381,25.0799],[1,1,1]),#([3.15128,4.08072,35.9145],[1,1,1]),#([2.7909,3.00704,42.826],[1,1,1]),#([-3.71592,5.7638,25.0799],[1,1,1]),#([-3.15119,4.08071,35.9145],[1,1,1]),#([-2.79094,3.00704,42.826],[1,1,1]),#([3.895,-5.15584,26.9956],[1,1,1]),#([2.7751,-4.80045,36.433],[1,1,1]),#([2.11487,-4.59093,41.9969],[1,1,1]),#([7.12291,-1.62608,45.2817],[1,1,1]),#([-7.02512,-1.6584,45.4428],[1,1,1]),#([8.04619e-006,4.72683,47.1521],[1,1,1]),#([-15.0667,0.455184,38.5337],[1,1,1]),#([15.0667,0.455233,38.5337],[1,1,1]),#([0.00375565,-2.45241,69.9187],[1,1,1]),#([7.08608,8.61755,65.2317],[1,1,1]),#([-7.33561,8.29508,65.211],[1,1,1]),#([0.0698114,8.29074,53.4626],[1,1,1]),#([-2.64406,2.18415,43.426],[1,1,1]),#([7.12291,-1.62608,45.2817],[1,1,1]),#([-7.02512,-1.6584,45.4428],[1,1,1]),#([8.04619e-006,4.72683,47.1521],[1,1,1]),#([-15.0667,0.455189,38.5337],[1,1,1]),#([15.0667,0.455233,38.5337],[1,1,1]),#([-2.46821e-006,-0.0804424,63.8215],[1,1,1]),#([0.00375565,-2.45241,69.9187],[1,1,1]),#([1.89275e-005,-1.15608,79.1797],[1,1,1]),#([-1.1875e-006,-0.0635883,51.5835],[1,1,1]),#([7.08608,8.61755,65.2317],[1,1,1]),#([-7.33561,8.29508,65.211],[1,1,1]),#([0.0698118,8.29074,53.4626],[1,1,1]),#([-2.64406,2.18415,43.426],[1,1,1]),#([3.51431,-0.818923,39.0275],[1,1,1]),#([-3.51431,-0.818934,39.0275],[1,1,1]),#([-4.34213,0.676807,62.4634],[1,1,1]),#([-7.10524,0.593768,58.7403],[1,1,1]),#([4.34215,0.676807,62.4634],[1,1,1]),#([7.10523,0.593789,58.7403],[1,1,1]),#([3.94481,-4.95344,36.2065],[1,1,1]),#([4.86177,-0.191878,18.276],[1,1,1]),#([5.38712,-6.70992,14.522],[1,1,1]),#([4.72975,-6.26086,22.4291],[1,1,1]),#([4.54034,-0.703713,23.2817],[1,1,1]),#([4.72975,-6.26086,22.4291],[1,1,1]),#([4.40348,-5.822,27.9296],[1,1,1]),#([4.66888,0.048346,21.1634],[1,1,1]),#([4.40349,-5.82195,27.9297],[1,1,1]),#([3.84065,-4.95725,36.1981],[1,1,1]),#([5.14507,10.8645,12.4827],[1,1,1]),#([4.38548,8.18378,22.3606],[1,1,1]),#([5.11319,0.594671,14.3235],[1,1,1]),#([4.38292,8.18349,22.3605],[1,1,1]),#([4.3503,5.95609,30.4323],[1,1,1]),#([4.74297,-0.0448937,21.2014],[1,1,1]),#([4.34975,5.95605,30.4325],[1,1,1]),#([4.04087,4.33854,35.7054],[1,1,1]),#([-4.22922,10.8897,12.4322],[1,1,1]),#([-3.69474,8.20592,22.2771],[1,1,1]),#([-3.78734,0.59477,14.3082],[1,1,1]),#([-3.69474,8.20591,22.2771],[1,1,1]),#([-3.68394,5.96925,30.4279],[1,1,1]),#([-3.33753,-0.044909,21.1664],[1,1,1]),#([-3.68394,5.96925,30.4279],[1,1,1]),#([-3.95531,4.36724,35.6526],[1,1,1]),#([-4.94219,-0.140312,18.3215],[1,1,1]),#([-5.15557,-6.76281,14.5269],[1,1,1]),#([-4.7246,-6.29213,22.2735],[1,1,1]),#([-4.66536,-0.649288,23.3288],[1,1,1]),#([-4.7246,-6.29213,22.2735],[1,1,1]),#([-4.41019,-5.78153,27.9073],[1,1,1]),#([-4.78264,0.0178342,21.1778],[1,1,1]),#([-4.41018,-5.78155,27.9075],[1,1,1]),#([-3.95525,-4.91959,36.1236],[1,1,1]))
		
		local eroObj_ary = #()

		layer_num = LayerManager.count
		for i=1 to (layer_num-1) do(
			local i_nodes
			i_layer = LayerManager.getLayer i
			i_layer.nodes &i_nodes
			for i_node in i_nodes do(
				local TransEro_bol = false
				local obj_info = errorBoneTransInfo objc:i_node
				if (classof i_node) == Point or (classof i_node) == BoneGeometry then(
					if type == "f1" then(
						index = findItem f1_name (tolower i_node.name)
						obj_info.ero = undefined
						if index > 0 then(
							num1 = abs (f1_msg[index][1][1] - i_node.pos[1])
							num2 = abs (f1_msg[index][1][2] - i_node.pos[2])
							num3 = abs (f1_msg[index][1][3] - i_node.pos[3])
							if num1 > 0.001 or num2 > 0.001 or num3 > 0.001 then(
								TransEro_bol = true
								obj_info.ero = "λ������(" + ((num1 * 25.4) as string) + "," + ((num2 * 25.4) as string) + "," + ((num3 * 25.4) as string) + ")"
							)
							num1 = abs (f1_msg[index][2][1] - i_node.scale[1])
							num2 = abs (f1_msg[index][2][2] - i_node.scale[2])
							num3 = abs (f1_msg[index][2][3] - i_node.scale[3])
							if num1 > 0.001 or num2 > 0.001 or num3 > 0.001 then(
								TransEro_bol = true
								if obj_info.ero != undefined then(
									obj_info.ero = obj_info.ero + ",��������(" + (num1 as string) + "," + (num2 as string) + "," + (num3 as string) + ")"
								)
								else(
									obj_info.ero = "��������(" + (num1 as string) + "," + (num2 as string) + "," + (num3 as string) + ")"
								)
							)
						)
					)
					if type == "f2" then(
						index = findItem f2_name (tolower i_node.name)
						obj_info.ero = undefined
						if index > 0 then(
							num1 = abs (f2_msg[index][1][1] - i_node.pos[1])
							num2 = abs (f2_msg[index][1][2] - i_node.pos[2])
							num3 = abs (f2_msg[index][1][3] - i_node.pos[3])
							if num1 > 0.001 or num2 > 0.001 or num3 > 0.001 then(
								TransEro_bol = true
								obj_info.ero = "λ������(" + ((num1 * 25.4) as string) + "," + ((num2 * 25.4) as string) + "," + ((num3 * 25.4) as string) + ")"
							)
							num1 = abs (f2_msg[index][2][1] - i_node.scale[1])
							num2 = abs (f2_msg[index][2][2] - i_node.scale[2])
							num3 = abs (f2_msg[index][2][3] - i_node.scale[3])
							if num1 > 0.001 or num2 > 0.001 or num3 > 0.001 then(
								TransEro_bol = true
								if obj_info.ero != undefined then(
									obj_info.ero = obj_info.ero + ",��������(" + (num1 as string) + "," + (num2 as string) + "," + (num3 as string) + ")"
								)
								else(
									obj_info.ero = "��������(" + (num1 as string) + "," + (num2 as string) + "," + (num3 as string) + ")"
								)
							)
						)
					)
					if type == "m1" then(
						index = findItem m1_name (tolower i_node.name)
						obj_info.ero = undefined
						if index > 0 then(
							num1 = abs (m1_msg[index][1][1] - i_node.pos[1])
							num2 = abs (m1_msg[index][1][2] - i_node.pos[2])
							num3 = abs (m1_msg[index][1][3] - i_node.pos[3])
							if num1 > 0.001 or num2 > 0.001 or num3 > 0.001 then(
								TransEro_bol = true
								obj_info.ero = "λ������(" + ((num1 * 25.4) as string) + "," + ((num2 * 25.4) as string) + "," + ((num3 * 25.4) as string) + ")"
							)
							num1 = abs (m1_msg[index][2][1] - i_node.scale[1])
							num2 = abs (m1_msg[index][2][2] - i_node.scale[2])
							num3 = abs (m1_msg[index][2][3] - i_node.scale[3])
							if num1 > 0.001 or num2 > 0.001 or num3 > 0.001 then(
								TransEro_bol = true
								if obj_info.ero != undefined then(
									obj_info.ero = obj_info.ero + ",��������(" + (num1 as string) + "," + (num2 as string) + "," + (num3 as string) + ")"
								)
								else(
									obj_info.ero = "��������(" + (num1 as string) + "," + (num2 as string) + "," + (num3 as string) + ")"
								)
							)
						)
					)
					if type == "m2" then(
						index = findItem m2_name (tolower i_node.name)
						obj_info.ero = undefined
						if index > 0 then(
							num1 = abs (m2_msg[index][1][1] - i_node.pos[1])
							num2 = abs (m2_msg[index][1][2] - i_node.pos[2])
							num3 = abs (m2_msg[index][1][3] - i_node.pos[3])
							if num1 > 0.001 or num2 > 0.001 or num3 > 0.001 then(
								TransEro_bol = true
								obj_info.ero = "λ������(" + ((num1 * 25.4) as string) + "," + ((num2 * 25.4) as string) + "," + ((num3 * 25.4) as string) + ")"
							)
							num1 = abs (m2_msg[index][2][1] - i_node.scale[1])
							num2 = abs (m2_msg[index][2][2] - i_node.scale[2])
							num3 = abs (m2_msg[index][2][3] - i_node.scale[3])
							if num1 > 0.001 or num2 > 0.001 or num3 > 0.001 then(
								TransEro_bol = true
								if obj_info.ero != undefined then(
									obj_info.ero = obj_info.ero + ",��������(" + (num1 as string) + "," + (num2 as string) + "," + (num3 as string) + ")"
								)
								else(
									obj_info.ero = "��������(" + (num1 as string) + "," + (num2 as string) + "," + (num3 as string) + ")"
								)
							)
						)
					)
					if type == "00" then(
						TransEro_bol = true
						obj_info.ero = "δ֪����/�ļ�δ����"
					)
				)
				if TransEro_bol == true then append eroObj_ary obj_info
			)
		)
		return eroObj_ary
	)
	
	/*
	--	�������ID��顣
 	Function fn_objMaterialIDCheck obj_ary =
 	(
 		local Ero_ary = #()
 		local checkObj_ary = for obj in obj_ary where (classof obj == PolyMeshObject or classof obj == Editable_Poly or classof obj == Editable_mesh) collect obj
 		
 		for obj in checkObj_ary do
 		(
 			local info = errorMatIDInfo objc:obj eroFace_ary:#()
 			
 			if classof obj == Editable_mesh then
 			(
 				for n in 1 to obj.numfaces do
 				(
 					if (getFaceMatID obj n != 1) do (append info.eroFace_ary n)
 				)
 			)
 			else
 			(
 				for n in 1 to (polyop.getNumFaces obj) do
 				(
 					if (polyop.getFaceMatID obj n != 1) do (append info.eroFace_ary n)
 				)
 			)
 			if info.eroFace_ary.count != 0 do (append Ero_ary info)
 		)
 		
 		return Ero_ary
 	)
	*/
	
	--	������Ϣ��顣
	Function fn_faceLimitCheck obj_ary =
	(
		local info = errorFaceLimitInfo objc:#() ero:#()
		
		for obj in obj_ary where (classof obj == PolyMeshObject or classof obj == Editable_Poly or classof obj == Editable_mesh) do
		(
			local int_limit = 987654321
			
			case of 
			(
				(undefined != findString obj.name "bodyN"):	(int_limit = 24247)
				(undefined != findString obj.name "bodyT"):	(int_limit = 18855)
				(undefined != findString obj.name "body"):	(int_limit = 25544)
				(undefined != findString obj.name "head"):	(int_limit = 18855)
				(undefined != findString obj.name "hand"):	(int_limit = 4381)
				(undefined != findString obj.name "leg"):	(int_limit = 4856)
				(undefined != findString obj.name "belt"):	(int_limit = 1730)
				(undefined != findString obj.name "hat"):	(int_limit = 14266)
				(undefined != findString obj.name "bang"):	(int_limit = 2153)
				(undefined != findString obj.name "plait"):	(int_limit = 1889)
				(undefined != findString obj.name "cloak"):	(int_limit = 25000)
				(undefined != findString obj.name "face"):	(int_limit = 10562)
				(undefined != findString obj.name "lglove"):(int_limit = 3500)
				(undefined != findString obj.name "rglove"):(int_limit = 3500)
				default:()
			)
			if (int_limit<obj.faces.count) do
			(
				append info.objc obj
				append info.ero (int_limit as string+" < Face count:"+obj.faces.count as string)
			)
		)
		
		return info
	)
	
/*  ����  */

/*  ����  */

rollout rol_nameCheck "Skin�����׺�����" width:196 height:138
(
	fn fn_nameCheckList Actx_ctr =
	(
		local theRange = #()
		local layout_def = #("��׺�������Ϲ����SKIN���壺")
		
		--	���ñ�����ʽ��
		Actx_ctr.gridLines = true
		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
		Actx_ctr.fullRowSelect = true
		Actx_ctr.MultiSelect = false
		Actx_ctr.Checkboxes = false
		Actx_ctr.Columns.Clear()
		Actx_ctr.Columns.add layout_def[1] 172
		
		for obj in nameEro do
		(
			local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" obj.name
			
			append theRange Actx_obj
		)
		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
		Actx_ctr.Items.AddRange theRange
	)
	
	button 		btn_reCheck "���¼����������" pos:[8,8] width:180 height:16
	dotNetControl actx_nameCheck "System.Windows.Forms.ListView" pos:[8,32] width:180 height:97
	----------------------------
	on rol_nameCheck open do
	(
		fn_nameCheckList actx_nameCheck
	)
	on btn_reCheck pressed do
	(
		if rol_AnimOutputCheck.rdo_sel.state == 1 then nameEro = fn_skinObjNameCheck (objects as array)
		else nameEro = fn_skinObjNameCheck (selection as array)
		fn_nameCheckList actx_nameCheck
		if nameEro.count == 0 then
		(
			rol_AnimOutputCheck.actx_list.items.item[0].SubItems.item[1].text = "ͨ�����"
			destroyDialog rol_nameCheck
		)
		else
		(
			rol_AnimOutputCheck.actx_list.items.item[0].SubItems.item[1].text = "δͨ�����"
		)
	)
	on actx_nameCheck BeforeLabelEdit Cancel do
	(
		enableAccelerators = false
	)
	on actx_nameCheck AfterLabelEdit Cancel NewString do
	(
		nameEro[actx_nameCheck.SelectedItem.index].name = NewString
		enableAccelerators = true
	)
	on actx_nameCheck DoubleClick do
	(
		local obj = nameEro[actx_nameCheck.SelectedItems.item[0].index+1]
		
		obj.INodeLayerProperties.layer.current = true
		obj.ishidden = false
		select obj
	)
)

rollout rol_linkCheck "Skin����linkֵ���" width:600 height:138
(
	fn fn_linkCheckList Actx_ctr =
	(
		local theRange = #()
		local layout_def = #("SKIN����","������Ϣ")
		
		--	���ñ�����ʽ��
		Actx_ctr.gridLines = true
		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
		Actx_ctr.fullRowSelect = true
		Actx_ctr.MultiSelect = false
		Actx_ctr.Checkboxes = false
		Actx_ctr.Columns.Clear()
		for i in layout_def do (Actx_ctr.Columns.add i 100)
		
		--	struct 	errorMatInfo (objc,mat,diffuseOnly,diffuseMap,bitmapFileMiss,bitmapFileName,bitmapFileCopy)
		for info in linkEro do
		(
			local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" info.objc.name
			
			Actx_obj.SubItems.add info.ero
			append theRange Actx_obj
		)
		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
		Actx_ctr.Items.AddRange theRange
	)
	
	button 		btn_reCheck "���¼������linkֵ" pos:[8,8] width:120 height:16
	label 		lbl_note "˵������ = ͨ����飻--- = δ��顣" pos:[136,8] width:560 height:16
	dotNetControl actx_linkCheck "System.Windows.Forms.ListView" pos:[8,32] width:570 height:97
	---------------------------------
	on rol_linkCheck open do
	(
		fn_linkCheckList actx_linkCheck
	)
	on btn_reCheck pressed do
	(
		if rol_AnimOutputCheck.rdo_sel.state == 1 then linkEro = fn_skinObjLinkCheck (objects as array)
		else linkEro = fn_skinObjLinkCheck (selection as array)
		
		fn_linkCheckList actx_linkCheck
		if linkEro.count == 0 then
		(
			rol_AnimOutputCheck.actx_list.items.item[1].SubItems.item[1].text = "ͨ�����"
			destroyDialog rol_linkCheck
		)
		else
		(
			rol_AnimOutputCheck.actx_list.items.item[1].SubItems.item[1].text = "δͨ�����"
		)
	)
	on actx_linkCheck DoubleClick do
	(
	)
)

rollout rol_objWeightCheck "Skin����Ȩ�ؼ��" width:240 height:188
(
	fn fn_objWeightCheck Actx_ctr =
	(
		local theRange = #()
		local layout_def = #("SKIN����","������Ϣ")
		
		--	���ñ�����ʽ��
		Actx_ctr.gridLines = true
		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
		Actx_ctr.fullRowSelect = true
		Actx_ctr.MultiSelect = false
		Actx_ctr.Checkboxes = false
		Actx_ctr.Columns.Clear()
		for i in layout_def do (Actx_ctr.Columns.add i 100)
		
		--	struct 	errorMatInfo (objc,mat,diffuseOnly,diffuseMap,bitmapFileMiss,bitmapFileName,bitmapFileCopy)
		for info in weightEro do
		(
			local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" info.objc.name
			
			Actx_obj.SubItems.add info.ero
			
			append theRange Actx_obj
		)
		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
		Actx_ctr.Items.AddRange theRange
	)
	
	button 		btn_reCheck "���¼��Ȩ�ش��������" pos:[8,8] width:224 height:16
	dotNetControl actx_objWeightCheck "System.Windows.Forms.ListView" pos:[8,32] width:224 height:92
	label 		lbl_info "����ѡ�����壬˫���򿪴���Ȩ���б���\n����Ȩ��ǰ���ȱ��浱ǰ�ļ���" pos:[8,128] width:224 height:32
-- 	button 		btn_repair "����ѡ������Ȩ��" pos:[8,160] width:128 height:16
-- 	spinner 		spn_weight "����:" pos:[156,160] width:76 height:16 range:[0,760919,defaultWeight] scale:0.01
	----------------------------------
	on rol_objWeightCheck open do
	(
		fn_objWeightCheck actx_objWeightCheck
	)
	on btn_reCheck pressed do
	(
		if rol_AnimOutputCheck.rdo_sel.state == 1 then weightEro = fn_skinObjVertWeightCheck (objects as array)
		else weightEro = fn_skinObjVertWeightCheck (selection as array)
		fn_objWeightCheck actx_objWeightCheck
		if weightEro.count == 0 then
		(
			rol_AnimOutputCheck.actx_list.items.item[2].SubItems.item[1].text = "ͨ�����"
			destroyDialog rol_objWeightCheck
		)
		else
		(
			rol_AnimOutputCheck.actx_list.items.item[2].SubItems.item[1].text = "δͨ�����"
		)
	)
	on actx_objWeightCheck Click do
	(
		if weightEro.count != 0 do
		(
			local obj = weightEro[actx_objWeightCheck.SelectedItems.item[0].index+1].objc
			
			obj.isHidden = false
			select obj
		)
	)
	on actx_objWeightCheck DoubleClick do
	(
		local sel = actx_objWeightCheck.SelectedItems.item[0].index+1
		
		max modify mode
		if weightEro.count != 0 and weightEro[sel].ero != "Skin��û�й���" do
		(
			local eroVert = #{}
			
			modPanel.setCurrentObject weightEro[sel].objc.modifiers[#Skin]
			weightEro[sel].objc.modifiers[#Skin].filter_vertices = on
			weightEro[sel].objc.modifiers[#Skin].filter_cross_sections = off
			weightEro[sel].objc.modifiers[#Skin].filter_envelopes = off
			weightEro[sel].objc.modifiers[#Skin].backfacecull = off
			weightEro[sel].objc.modifiers[#Skin].selectElement = off
			
			for n in weightEro[sel].eroVertex_ary do append eroVert n
			skinOps.SelectVertices weightEro[sel].objc.modifiers[#Skin] eroVert
			
			skinOps.buttonWeightTable weightEro[sel].objc.modifiers[#Skin]
			weightEro[sel].objc.modifiers[#Skin].wt_activeVertexSet = 1
		)
	)
	on btn_repair pressed do
	(
		local repairedWeight = #()
		local sel_ary = selection as array
		
		if weightEro.count != 0 do
		(
			local sel = #()
			
			for n in 1 to actx_objWeightCheck.items.count do
			(
				if actx_objWeightCheck.items.item[n-1].selected do append sel n
			)
			for n in sel do
			(
				local obj = weightEro[n].objc
				
				if weightEro[n].ero != "Skin��û�й���" and weightEro[n].eroVertex_ary != undefined do
				(
					local reCheckEro_ary = #()
					
					select obj
					for x in weightEro[n].eroVertex_ary do
					(
						local bone_ary = #()
						local weight_ary = #()
						
						if skinOps.GetVertexWeightCount obj.modifiers[#Skin] x != 0 do
						(
							for b in 1 to skinOps.GetNumberBones obj.modifiers[#Skin] do
							(
								local i_weight
								
								try(i_weight = skinOps.GetVertexWeight obj.modifiers[#Skin] x b)catch()
								if i_weight != undefined do
								(
									local sub = (i_weight / defaultWeight) as string
									
									sub = (filterString sub ".")[2]
									if sub != "0" do
									(
										local newCount
										local b_ID
										
										if sub[1] as integer < 5 then newCount = defaultWeight * (floor (i_weight / defaultWeight))
										else newCount = defaultWeight * (ceil (i_weight / defaultWeight))
										b_ID = skinOps.GetVertexWeightBoneID obj.modifiers[#Skin] x b
										append bone_ary b_ID
										append weight_ary newCount
									)
								)
							)
						)
						skinOps.SetVertexWeights obj.modifiers[#Skin] x bone_ary weight_ary
					)
					--	�������������ٴμ�������Ȩ�ء�
					reCheckEro_ary = fn_skinObjVertWeightCheck #(obj)
					if reCheckEro_ary.count == 0 then append repairedWeight weightEro[n]
				)
			)
		)
		select sel_ary
		--	������ϣ����¼��Ȩ�ش�������ͱ�����Ϣ��
		if rol_AnimOutputCheck.rdo_sel.state == 1 then weightEro = fn_skinObjVertWeightCheck (objects as array)
		else weightEro = fn_skinObjVertWeightCheck (selection as array)
		fn_objWeightCheck actx_objWeightCheck
		if weightEro.count == 0 then
		(
			rol_AnimOutputCheck.actx_list.items.item[2].SubItems.item[1].text = "ͨ�����"
			destroyDialog rol_objWeightCheck
		)
		else
		(
			rol_AnimOutputCheck.actx_list.items.item[2].SubItems.item[1].text = "δͨ�����"
		)
	)
	on spn_weight changed val do
	(
		defaultWeight = val
	)
)

rollout rol_insideBoneCheck "Skin�����۹������" width:500 height:152
(
	Function fn_insideCheck Actx_ctr =
	(
		local theRange = #()
		local layout_def = #("����","ȱ�ٹ���","��Ȩ�ص�ָ���Ĺ���")
		
		--	���ñ�����ʽ��
		Actx_ctr.gridLines = true
		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
		Actx_ctr.fullRowSelect = true
		Actx_ctr.MultiSelect = false
		Actx_ctr.Checkboxes = false
		Actx_ctr.Columns.Clear()
		for i in layout_def do (Actx_ctr.Columns.add i 64)
		
		--	struct 	errorLoseBoneInfo (objc,loseBone,weightBone)
		for info in insideBoneEro do
		(
			local txt = ""
			local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" info.objc.name
			
			for n in 1 to info.loseBone.count do
			(
				if n != info.loseBone.count then txt += info.loseBone[n] + "��"
				else txt += info.loseBone[n]
			)
			Actx_obj.SubItems.add txt
			txt = ""
			for n in 1 to info.weightBone.count do
			(
				if n != info.weightBone.count then txt += info.weightBone[n] + "��"
				else txt += info.weightBone[n]
			)
			Actx_obj.SubItems.add txt
			
			append theRange Actx_obj
		)
		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
		Actx_ctr.Items.AddRange theRange
	)
	
	button btn_reCheck "���¼���۴��������" pos:[8,8] width:224 height:16
	button btn_addLoseBone "����ȱʧ�Ĺ���" pos:[248,8] width:100 height:16
	dotNetControl actx_insideBoneCheck "System.Windows.Forms.ListView" pos:[8,32] width:484 height:112
	on rol_insideBoneCheck open  do
	(
		fn_insideCheck actx_insideBoneCheck
	)
	on btn_reCheck pressed  do
	(
		if rol_AnimOutputCheck.rdo_sel.state == 1 then insideBoneEro = fn_insideBoneCheck (objects as array)
		else insideBoneEro = fn_insideBoneCheck (selection as array)
		fn_insideCheck actx_insideBoneCheck
		if insideBoneEro.count == 0 then
		(
			rol_AnimOutputCheck.actx_list.items.item[3].SubItems.item[1].text = "ͨ�����"
			destroyDialog rol_insideBoneCheck
		)
		else
		(
			rol_AnimOutputCheck.actx_list.items.item[3].SubItems.item[1].text = "δͨ�����"
		)
	)
	on actx_insideBoneCheck Click do
	(
		if insideBoneEro.count != 0 do
		(
			local obj = insideBoneEro[actx_insideBoneCheck.SelectedItems.item[0].index+1].objc
			
			obj.isHidden = false
			select obj
		)
	)
	on btn_addLoseBone pressed do
	(
		--	struct 	errorLoseBoneInfo (objc,loseBone,weightBone)insideBoneEro
		for info in insideBoneEro where info.loseBone.count != 0 do
		(
			for i_bone in info.loseBone do
			(
				local addBone = getNodeByName i_bone
				if addBone != undefined do skinOps.addbone info.objc.modifiers[#Skin] addBone 1
			)
		)
		if rol_AnimOutputCheck.rdo_sel.state == 1 then insideBoneEro = fn_insideBoneCheck (objects as array)
		else insideBoneEro = fn_insideBoneCheck (selection as array)
		fn_insideCheck actx_insideBoneCheck
		if insideBoneEro.count == 0 then
		(
			rol_AnimOutputCheck.actx_list.items.item[3].SubItems.item[1].text = "ͨ�����"
			destroyDialog rol_insideBoneCheck
		)
		else
		(
			rol_AnimOutputCheck.actx_list.items.item[3].SubItems.item[1].text = "δͨ�����"
		)
	)
)

rollout rol_FBBoneCheck "�������FB���" width:360 height:152
(
	fn fn_FBCheck Actx_ctr =
	(
		local theRange = #()
		local layout_def = #("���� ����/������","������Ϣ")
		
		--	���ñ�����ʽ��
		Actx_ctr.gridLines = true
		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
		Actx_ctr.fullRowSelect = true
		Actx_ctr.MultiSelect = false
		Actx_ctr.Checkboxes = false
		Actx_ctr.Columns.Clear()
		for i in layout_def do (Actx_ctr.Columns.add i 64)
		
		--	struct 	errorFBBoneInfo (eroFB,noWeightFBR)
		if FBBoneEro[1].count != 0 do
		(
			for n in 1 to FBBoneEro[1].count do
			(
				local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" FBBoneEro[1][n].name
				
				Actx_obj.SubItems.add  "FB���������ڹ���ϵͳ��һ����"
				append theRange Actx_obj
			)
		)
		if FBBoneEro[2].count != 0 do
		(
			for n in 1 to FBBoneEro[2].count do
			(
				local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" FBBoneEro[2][n][1]
				
				Actx_obj.SubItems.add ("������������:" + FBBoneEro[2][n][2] + "����Ȩ��")
				append theRange Actx_obj
			)
		)
		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
		Actx_ctr.Items.AddRange theRange
	)
	
	button btn_reCheck "���¼���������" pos:[8,8] width:224 height:16
	dotNetControl actx_FBBoneCheck "System.Windows.Forms.ListView" pos:[8,32] width:344 height:112
	on rol_FBBoneCheck open  do
	(
		fn_FBCheck actx_FBBoneCheck
	)
	on btn_reCheck pressed  do
	(
		if rol_AnimOutputCheck.rdo_sel.state == 1 then FBBoneEro = fn_FBBoneCheck (objects as array)
		else FBBoneEro = fn_FBBoneCheck (selection as array)
		fn_FBCheck actx_FBBoneCheck
		if FBBoneEro[1].count + FBBoneEro[2].count == 0 then
		(
			rol_AnimOutputCheck.actx_list.items.item[4].SubItems.item[1].text = "ͨ�����"
			destroyDialog rol_FBBoneCheck
		)
		else
		(
			rol_AnimOutputCheck.actx_list.items.item[4].SubItems.item[1].text = "δͨ�����"
		)
	)
	on actx_FBBoneCheck Click do
	(
		local obj = getNodeByName (actx_FBBoneCheck.ListItems[actx_FBBoneCheck.SelectedItems.item[0].index+1].text)
		
		if obj != undefined do select obj
	)
)

rollout rol_transCheck "������Ϣ���" width:500 height:138
(
	fn fn_TransCheckList Actx_ctr =
	(
		local theRange = #()
		local layout_def = #("����","������Ϣ")
		
		--	���ñ�����ʽ��
		Actx_ctr.gridLines = true
		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
		Actx_ctr.fullRowSelect = true
		Actx_ctr.MultiSelect = false
		Actx_ctr.Checkboxes = false
		Actx_ctr.Columns.Clear()
		Actx_ctr.Columns.add layout_def[1] 120
		Actx_ctr.Columns.add layout_def[2] 360
		--for i in layout_def do (Actx_ctr.Columns.add i 100)
		
		--	struct 	errorMatInfo (objc,mat,diffuseOnly,diffuseMap,bitmapFileMiss,bitmapFileName,bitmapFileCopy)
		for info in transEro do
		(
			local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" info.objc.name
			
			Actx_obj.SubItems.add info.ero
			append theRange Actx_obj
		)
		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
		Actx_ctr.Items.AddRange theRange
	)
	
	button 		btn_reCheck "���¼�������Ϣ" pos:[8,8] width:120 height:16
	label 		lbl_note "˵������ = ͨ����飻--- = δ��顣" pos:[136,8] width:560 height:16
	dotNetControl actx_transCheck "System.Windows.Forms.ListView" pos:[8,32] width:570 height:97
	on rol_transCheck open do
	(
		fn_TransCheckList actx_transCheck
	)
	on btn_reCheck pressed do
	(
		file_name = maxFileName as string
		if (2>file_name.count) do (file_name = "00")
		type = tolower (file_name[1] + file_name[2])
		if rol_AnimOutputCheck.rdo_sel.state == 1 then transEro = fn_BoneTransCheck type
		else transEro = fn_BoneTransCheck type
		
		fn_TransCheckList actx_transCheck
		if transEro.count == 0 then
		(
			rol_AnimOutputCheck.actx_list.items.item[1].SubItems.item[1].text = "ͨ�����"
			destroyDialog rol_transCheck
		)
		else
		(
			rol_AnimOutputCheck.actx_list.items.item[1].SubItems.item[1].text = "δͨ�����"
		)
	)
	on actx_transCheck Click do
	(
		local obj = transEro[actx_transCheck.SelectedItems.item[0].index+1].objc
			
		if obj != undefined do select obj
	)
)

/*
rollout rol_materialIDCheck "�������ID���" width:200 height:168
(
	fn fn_IDCheckList Actx_ctr =
 	(
 		local theRange = #()
 		local layout_def = #("����","ID��Ϊ1����")
 		
 		--	���ñ�����ʽ��
 		Actx_ctr.gridLines = true
 		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
 		Actx_ctr.fullRowSelect = true
 		Actx_ctr.MultiSelect = false
 		Actx_ctr.Checkboxes = false
 		Actx_ctr.Columns.Clear()
 		for i in layout_def do (Actx_ctr.Columns.add i 64)
 		
 		--	struct 	errorMatInfo (objc,mat,diffuseOnly,diffuseMap,bitmapFileMiss,bitmapFileName,bitmapFileCopy)
 		for info in matIDEro do
 		(
 			local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" info.objc.name
 			
 			Actx_obj.SubItems.add (info.eroFace_ary as string)
 			append theRange Actx_obj
 		)
 		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
 		Actx_ctr.Items.AddRange theRange
 	)
 		
 	button btn_reCheck "���¼������Ƭ��ID�Ƿ�Ϊ1" pos:[8,8] width:184 height:16
 	button btn_setID "��������Ƭ��ID" pos:[8,144] width:112 height:16
 	dotNetControl actx_materialIDCheck "System.Windows.Forms.ListView" pos:[8,32] width:184 height:104
 	spinner spn_setID "ID=" pos:[136,144] width:56 height:16 range:[0,9999,1] type:#integer scale:1
 	--------------------------
	on rol_materialIDCheck open do
 	(
 		fn_IDCheckList actx_materialIDCheck
 	)
 	on btn_reCheck pressed do
 	(
 		if rol_AnimOutputCheck.rdo_sel.state == 1 then matIDEro = fn_objMaterialIDCheck (objects as array)
 		else matIDEro = fn_objMaterialIDCheck (selection as array)
 		fn_IDCheckList actx_materialIDCheck
 		if matIDEro.count == 0 then
 		(
 			rol_AnimOutputCheck.actx_list.items.item[5].SubItems.item[1].text = "ͨ�����"
 			destroyDialog rol_materialIDCheck
 		)
 		else
 		(
 			rol_AnimOutputCheck.actx_list.items.item[5].SubItems.item[1].text = "δͨ�����"
 		)
 	)
 	on btn_setID pressed do
 	(
 		local obj_ary = #()
 		local setIDObj_ary = #()
 		
 		if rol_AnimOutputCheck.rdo_sel.state == 1 then obj_ary = objects as array
 		else obj_ary = selection as array
 		setIDObj_ary = for obj in obj_ary where (classof obj == PolyMeshObject or classof obj == Editable_Poly or classof obj == Editable_mesh) collect obj
 		
 		for obj in setIDObj_ary do
 		(
 			if classof obj == Editable_mesh then
 			(
 				for n in 1 to obj.numfaces do setFaceMatID obj n spn_setID.value
 			)
 			else
 			(
 				polyop.setFaceMatID obj #{1..(polyop.getNumFaces obj)} spn_setID.value
 			)
 		)
 		
 		if rol_AnimOutputCheck.rdo_sel.state == 1 then matIDEro = fn_objMaterialIDCheck (objects as array)
 		else matIDEro = fn_objMaterialIDCheck (selection as array)
 		fn_IDCheckList actx_materialIDCheck
 		if matIDEro.count == 0 then
 		(
 			rol_AnimOutputCheck.actx_list.items.item[5].SubItems.item[1].text = "ͨ�����"
 			destroyDialog rol_materialIDCheck
 		)
 		else
 		(
 			rol_AnimOutputCheck.actx_list.items.item[5].SubItems.item[1].text = "δͨ�����"
 		)
 	)
)
*/

rollout rol_faceLimitCheck "�����������" width:256 height:168
(
	fn fn_faceLimitList Actx_ctr =
	(
		local theRange = #()
		local layout_def = #("����","��ǰ����")
		
		--	���ñ�����ʽ��
		Actx_ctr.gridLines = true
		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
		Actx_ctr.fullRowSelect = true
		Actx_ctr.MultiSelect = false
		Actx_ctr.Checkboxes = false
		Actx_ctr.Columns.Clear()
		for i in layout_def do (Actx_ctr.Columns.add i 64)
		
		--	struct	errorFaceLimitInfo (objc,ero)
		if (undefined == faceLimitEro) do return()
		for n = 1 to faceLimitEro.objc.count do
		(
			local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" faceLimitEro.objc[n].name
			
			Actx_obj.SubItems.add faceLimitEro.ero[n]
			
			append theRange Actx_obj
		)
		
		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
		Actx_ctr.Items.AddRange theRange
	)
 		
 	button btn_reCheck "���¼����������" pos:[8,8] width:240 height:24
 	dotNetControl actx_faceLimitCheck "System.Windows.Forms.ListView" pos:[8,40] width:240 height:120
 	------------------------------
	on rol_faceLimitCheck open do
 	(
 		fn_faceLimitList actx_faceLimitCheck
 	)
 	on btn_reCheck pressed do
 	(
 		if rol_AnimOutputCheck.rdo_sel.state == 1 then faceLimitEro = fn_faceLimitCheck (objects as array)
 		else faceLimitEro = fn_faceLimitCheck (selection as array)
 		fn_faceLimitList actx_faceLimitCheck
 		if faceLimitEro.objc.count == 0 then
 		(
 			rol_AnimOutputCheck.actx_list.items.item[6].SubItems.item[1].text = "ͨ�����"
 			destroyDialog rol_faceLimitCheck
 		)
 		else
 		(
 			rol_AnimOutputCheck.actx_list.items.item[6].SubItems.item[1].text = "δͨ�����"
 		)
 	)
)

--	���û����档
rollout rol_AnimOutputCheck "�����ļ�����ǰ��鹤��" width:200 height:320
(
	--	< ������ֲ��������� >
	---		�ű����ơ�
	local 	AnimOutputCheck_Name = "AnimOutputCheck"
	--		�ű��汾��
	local 	AnimOutputCheck_Version = "1.00"
	--		�ű��ڲ���š�
	local 	AnimOutputCheck_ID = "In-Company"
	--		�ű�������Ϣ��
	local 	AnimOutputCheck_BuildInfo = "3dsMax 2012. 2014-08-06, at Company."
	--		����������д��
	local 	rol = rol_AnimOutputCheck
	--		������Ŀ���顣
	local 	actxList_ary = #()
	--	< ���溯�� >
	fn fn_checklist Actx_ctr =
	(
		local theRange = #()
		local layout_def = #("�����","״��")
		
		--	���ñ�����ʽ��
		Actx_ctr.gridLines = true
		Actx_ctr.View = (dotNetClass "System.Windows.Forms.View").Details
		Actx_ctr.fullRowSelect = true
		Actx_ctr.MultiSelect = false
		Actx_ctr.Checkboxes = true
		Actx_ctr.Columns.Clear()
		Actx_ctr.Columns.add layout_def[1] 96
		Actx_ctr.Columns.add layout_def[2] 64
		
		for info in actxList_ary do
		(
			local Actx_obj = dotNetObject "System.Windows.Forms.ListViewItem" info.name
			
			Actx_obj.Checked = info.isSelect
			Actx_obj.SubItems.add info.stat
			
			append theRange Actx_obj
		)
		for n = 1 to Actx_ctr.items.count do (Actx_ctr.items.RemoveAt 0)
		Actx_ctr.Items.AddRange theRange
	)
	
	/*	ע��������ע����������ԭ���á�	*/
	fn fn_AnimOutputCheckUndefined =
	(
		try
		(
			nameEro = undefined
			--materialEro = undefined
			linkEro = undefined
			weightEro = undefined
			insideBoneEro = undefined
			FBBoneEro = undefined
			defaultWeight = undefined
			transEro = undefined
			faceLimitEro = undefined
			checkInfo = undefined
			--errorMatInfo = undefined
			errorWeightObjInfo = undefined
			errorLoseBoneInfo = undefined
			errorFBBoneInfo = undefined
			errorTransEro = undefined
			
			fn_skinObjNameCheck = undefined
			--fn_skinObjMaterialCheck = undefined
			fn_skinObjLinkCheck = undefined
			fn_skinObjVertWeightCheck = undefined
			fn_insideBoneCheck = undefined
			fn_FBBoneCheck = undefined
			fn_BoneTransCheck = undefined
			fn_faceLimitCheck = undefined
			
			try(destroyDialog rol_nameCheck) catch()
			--try(destroyDialog rol_materialCheck) catch()
			try(destroyDialog rol_objWeightCheck) catch()
			try(destroyDialog rol_insideBoneCheck) catch()
			try(destroyDialog rol_FBBoneCheck) catch()
			try(destroyDialog rol_AnimOutputCheck) catch()
			try(destroyDialog rol_transCheck) catch()
			try(destroyDialog rol_faceLimitCheck) catch()
			
			rol_nameCheck = undefined
			--rol_materialCheck = undefined
			rol_objWeightCheck = undefined
			rol_insideBoneCheck = undefined
			rol_FBBoneCheck = undefined
			rol_AnimOutputCheck = undefined
			rol_transCheck = undefined
			rol_faceLimitCheck = undefined
		)
		catch()
	)
	
	--	<������ؼ�����>
	--	�����׺�� ���ʺ���ͼ SKINȨ��ֵ ��۹��� ������� �����Ķ���
	button btn_check "���������Ŀ" pos:[8,8] width:152 height:24
	button btn_info "˵��" pos:[160,8] width:32 height:24
	radiobuttons rdo_sel "" pos:[8,36] width:228 height:16 labels:#("���е�����    ", "ѡ�������    ") columns:2
	dotNetControl actx_list "System.Windows.Forms.ListView" pos:[8,56] width:200 height:148
	label lbl_info "˫������ĳ����Ŀ�ɲ鿴��ϸ��Ϣ" pos:[8,208] width:180 height:16
	checkbox chk_batCheck "�������" pos:[8,229] width:97 height:20
	button btn_batCheck "��ʼ�������" pos:[8,281] width:184 height:19 enabled:false
	edittext edt_batCheckPath "" pos:[4,252] width:188 height:22 enabled:false
	Timer tmr_batCheck "Timer" pos:[105,225] width:24 height:24 active:false
	--	<������ؼ�����>

	on rol_AnimOutputCheck open do
	(
	--	2016.10.31ȥ�����������ID���
	--	local checkName_ary = #("�����׺��","���ʺ���ͼ","SKINȨ��ֵ","��۹���","�������","�������ID")
	--	2023.01.31�����������������Ƶļ��
	-- 	local checkName_ary = #("�����׺��","���ʺ���ͼ","SKINȨ��ֵ","��۹���","�������")
		local checkName_ary = #("�����׺��","linkֵ","SKINȨ��ֵ","��۹���","�������","������Ϣ","��������")
		
		clearListener()
		for str in checkName_ary do
		(
			local listInfo = checkInfo isSelect:true name:str stat:"δ���"
			append actxList_ary listInfo
		)
		fn_checklist actx_list
	)
	on rol_AnimOutputCheck close do
	(
		fn_AnimOutputCheckUndefined()
	)
	on btn_check pressed do
	(
		for n = 1 to actx_list.items.count do
		(
			if n == 1 and actx_list.items.item[n-1].checked do
			(
				if rol_AnimOutputCheck.rdo_sel.state == 1 then nameEro = fn_skinObjNameCheck (objects as array)
				else nameEro = fn_skinObjNameCheck (selection as array)
				if nameEro.count == 0 then
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
				)
				else
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
				)
			)
			if n == 2 and actx_list.items.item[n-1].checked do
			(
				if rol_AnimOutputCheck.rdo_sel.state == 1 then linkEro = fn_skinObjLinkCheck (objects as array)
				else linkEro = fn_skinObjLinkCheck (selection as array)
				if linkEro.count == 0 then
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
				)
				else
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
				)
			)
			if n == 3 and actx_list.items.item[n-1].checked do
			(
				if rol_AnimOutputCheck.rdo_sel.state == 1 then weightEro = fn_skinObjVertWeightCheck (objects as array)
				else weightEro = fn_skinObjVertWeightCheck (selection as array)
				if weightEro.count == 0 then
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
				)
				else
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
				)
			)
			if n == 4 and actx_list.items.item[n-1].checked do
			(
				if rol_AnimOutputCheck.rdo_sel.state == 1 then insideBoneEro = fn_insideBoneCheck (objects as array)
				else insideBoneEro = fn_insideBoneCheck (selection as array)
				if insideBoneEro.count == 0 then
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
				)
				else
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
				)
			)
			if n == 5 and actx_list.items.item[n-1].checked do
			(
				if rol_AnimOutputCheck.rdo_sel.state == 1 then FBBoneEro = fn_FBBoneCheck (objects as array)
				else FBBoneEro = fn_FBBoneCheck (selection as array)
				if FBBoneEro[1].count + FBBoneEro[2].count == 0 then
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
				)
				else
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
				)
			)
			if n == 6 and actx_list.items.item[n-1].checked do
			(
				file_name = maxFileName as string
				if (2>file_name.count) do (file_name = "00")
				type = tolower (file_name[1] + file_name[2])
				if rol_AnimOutputCheck.rdo_sel.state == 1 then transEro = fn_BoneTransCheck type
				else transEro = fn_BoneTransCheck type
				if transEro.count == 0 then
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
				)
				else
				(
					actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
				)
			)
			/*
 			if n == 6 and actx_list.items.item[n-1].checked do
 			(
 				if rol_AnimOutputCheck.rdo_sel.state == 1 then matIDEro = fn_objMaterialIDCheck (objects as array)
 				else matIDEro = fn_objMaterialIDCheck (selection as array)
 				if matIDEro.count == 0 then
 				(
 					actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
 				)
 				else
 				(
 					actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
 				)
 			)
			*/
			if n == 7 and actx_list.items.item[n-1].checked do
 			(
 				if rol_AnimOutputCheck.rdo_sel.state == 1 then faceLimitEro = fn_faceLimitCheck (objects as array)
				else faceLimitEro = fn_faceLimitCheck (selection as array)
				if faceLimitEro.objc.count == 0 then
				(
					rol_AnimOutputCheck.actx_list.items.item[6].SubItems.item[1].text = "ͨ�����"
					destroyDialog rol_faceLimitCheck
				)
				else
				(
					rol_AnimOutputCheck.actx_list.items.item[6].SubItems.item[1].text = "δͨ�����"
				)
 			)
		)
	)
	on btn_info pressed do
	(
		local check_txt = ""
		local readme = newScript()
		
		check_txt += "��1��Skin�����׺����飺\n"
		check_txt += "���������SKIN�Ķ���ε����ֺ�׺Ϊ��_body   _belt  _hand  _head _face  _leg����SKIN������û����Щ��׺����ʾ��\n"
		check_txt += "\n"
		check_txt += "��2��Skin����linkֵ��飺\n"
		check_txt += "���������SKIN�Ķ���ε�Bone Afeact LimitֵҪΪ4��\n"
		check_txt += "\n"
		check_txt += "��3��Skin����Ȩ�ؼ�飺\n"
		check_txt += "���������SKIN�Ķ���ε�Weight Table�е���ֵ�Ƿ�Ϊ0������Ϊ0.05�ı����������Եĵ��г���\n"
		check_txt += "��ͨ���б�ѡ�е㣬��������ͼ����ʾ�۲죻\n"
		check_txt += "�������޸���Щ���淶Ȩ�أ�\n"
		check_txt += "����������������Щ���淶��Ȩ�س�Ϊ0.05�ı�����\n"
		check_txt += "����Ƿ������ȫû��Ȩ�صĵ㣬������ģ�����ƺ͵��ID��ʾ��\n"
		check_txt += "\n"
		check_txt += "��4��Skin�����۹�����飺\n"
		check_txt += "���������SKIN�Ķ���ε�skin�б���Ӧ���������²�۹�����\n"
		check_txt += "_head��׺ģ�����в��B_Hat\n"
		check_txt += "_hand����������������B_RH    B_LH\n"
		check_txt += "_body����������������B_LC B_Long B_LP B_RC B_RP B_Spine B_Spine2\n"
		check_txt += "��_belt��_leg�޲��Ҫ��\n"
		check_txt += "�����Щ�������SKIN���Ƿ�ռ��Ȩ�أ����У����ģ�����ƺͶ�Ӧ�Ĳ�۹������ơ�\n"
		check_txt += "\n"
		check_txt += "��5���������FB��飺\n"
		check_txt += "���е����壨��FB��ͷ�Ĺ�����Ӧ������������ϵͳ��FBR��ͷ�Ĺ���������ĵ�һ�����ĸ�������SKIN��Ϣ��Ӧ��Ȩ�ء�\nͷ����������ɲ�������������ϵͳ������Щ����ͷ����������� ���յĸ�������룺������Ǽ������ӹ�ϵ��ΪBone���� �� �����ԡ�headbone����ʼ"
		check_txt += "\n"
		check_txt += "��6��������Ϣ��飺\n"
		check_txt += "���SKIN����Ĺ���������͵ı�׼������Ϣ�Ƿ���ȫһ�¡�\n"
		format check_txt to:readme
	)
	on actx_list itemChecked ctl do
	(
		actxList_ary[ctl.item.index+1].isSelect = ctl.item.checked
	)
	on actx_list DoubleClick do
	(
		local i = 0
		
		for n = 1 to actx_list.Items.count do
		(
			if (actx_list.Items.item[n-1].Selected) do (i = n)
		)
		case i of
		(
			1 : 
			(
				try(destroyDialog rol_nameCheck)catch()
				createDialog rol_nameCheck 196 138
			)
			2 :
			(
				try(destroyDialog rol_linkCheck)catch()
				createDialog rol_linkCheck 586 138
			)
			3 :
			(
				try(destroyDialog rol_objWeightCheck)catch()
				createDialog rol_objWeightCheck 240 188
			)
			4 :
			(
				try(destroyDialog rol_insideBoneCheck)catch()
				createDialog rol_insideBoneCheck 500 152
			)
			5 :
			(
				try(destroyDialog rol_FBBoneCheck)catch()
				createDialog rol_FBBoneCheck 360 152
			)
			6 :
			(
				try(destroyDialog rol_transCheck)catch()
				createDialog rol_transCheck 500 138
			)
			/*
 			6 :
 			(
 				try(destroyDialog rol_materialIDCheck)catch()
 				createDialog rol_materialIDCheck 200 168
 			)
			*/
			7 :
 			(
 				try(destroyDialog rol_faceLimitCheck)catch()
 				createDialog rol_faceLimitCheck
 			)
			default : ()
		)
	)
	on chk_batCheck changed state do
	(
		if chk_batCheck.checked then(
			rdo_sel.enabled = false
			btn_check.enabled = false
			btn_batCheck.enabled = true
			edt_batCheckPath.enabled = true
		)
		else(
			rdo_sel.enabled = true
			btn_check.enabled = true
			btn_batCheck.enabled = false
			edt_batCheckPath.enabled = false
		)
	)
	on btn_batCheck pressed do
	(
		btn_batCheck.enabled = false
		strMaxPath = edt_batCheckPath.text
		if strMaxPath != "" then(
			fn_create_log() 
			fn_getMaxFile strMaxPath
			if my_files.count > 0 then(
				fStream = OpenFile logPath mode:"a"		--��log�ļ�
				tmr_batCheck.active = true
			)
			else(
				edt_batCheckPath.text = "��·����û��max�ļ���"
			)
		)
		else(
			edt_batCheckPath.text = "���ڸ��ı�����������·����"
		)
		edt_batCheckPath.enabled = false	
	)
	on tmr_batCheck tick do
	(
		if tmr_batCheck.active then(
			fn_reset()
			strMaxPath = edt_batCheckPath.text
			fn_load_maxFile my_files[file_index] strMaxPath
			for n = 1 to actx_list.items.count do
			(
				if n == 1 and actx_list.items.item[n-1].checked do
				(
					if rol_AnimOutputCheck.rdo_sel.state == 1 then nameEro = fn_skinObjNameCheck (objects as array)
					else nameEro = fn_skinObjNameCheck (selection as array)
					if nameEro.count == 0 then
					(
						actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
					)
					else
					(
						for obj in nameEro do(
							cName = obj.name as string
							format ("[ERROR]\tSKIN����["+cName+"]�ĺ�׺�������Ϲ���\n") to: fStream
						)
						actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
					)
				)
				if n == 2 and actx_list.items.item[n-1].checked do
				(
					if rol_AnimOutputCheck.rdo_sel.state == 1 then linkEro = fn_skinObjLinkCheck (objects as array)
					else linkEro = fn_skinObjLinkCheck (selection as array)
					if linkEro.count == 0 then
					(
						actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
					)
					else
					(
						for info in linkEro do(
							cName = info.objc.name as string
							format ("[ERROR]\tSKIN����["+cName+"]��linkֵ������4\n") to: fStream
						)
						actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
					)
				)
				if n == 3 and actx_list.items.item[n-1].checked do
				(
					if rol_AnimOutputCheck.rdo_sel.state == 1 then weightEro = fn_skinObjVertWeightCheck (objects as array)
					else weightEro = fn_skinObjVertWeightCheck (selection as array)
					if weightEro.count == 0 then
					(
						actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
					)
					else
					(
						for info in weightEro do(
							cName = info.objc.name as string
							err_msg = info.ero
							format ("[ERROR]\tSKIN����["+cName+"]"+err_msg+"\n") to: fStream
						)
						actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
					)
				)
				if n == 4 and actx_list.items.item[n-1].checked do
				(
					local err_msg = ""
					if rol_AnimOutputCheck.rdo_sel.state == 1 then insideBoneEro = fn_insideBoneCheck (objects as array)
					else insideBoneEro = fn_insideBoneCheck (selection as array)
					if insideBoneEro.count == 0 then
					(
						actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
					)
					else
					(
						for info in insideBoneEro do(
							cName = info.objc.name as string
							for n in 1 to info.loseBone.count do(
								if n != info.loseBone.count then err_msg += info.loseBone[n] + "��"
								else(
									err_msg += info.loseBone[n]
									format ("[ERROR]\tSKIN����["+cName+"]��"+err_msg+" ȱ�ٹ���\n") to: fStream
								)
							)
							err_msg = ""
							for n in 1 to info.weightBone.count do(
								if n != info.weightBone.count then err_msg += info.weightBone[n] + "��"
								else(
									err_msg += info.weightBone[n]
									format ("[ERROR]\tSKIN����["+cName+"]�Ĳ��"+err_msg+" ռ��Ȩ��\n") to: fStream
								)
							)
						)
						actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
					)
				)
				if n == 5 and actx_list.items.item[n-1].checked do
				(
					if rol_AnimOutputCheck.rdo_sel.state == 1 then FBBoneEro = fn_FBBoneCheck (objects as array)
					else FBBoneEro = fn_FBBoneCheck (selection as array)
					if FBBoneEro[1].count + FBBoneEro[2].count == 0 then
					(
						actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
					)
					else
					(
						if FBBoneEro[1].count != 0 then(
							for n in 1 to FBBoneEro[1].count do(
								cName = FBBoneEro[1][n].name as string
								format ("[ERROR]\t����["+cName+"] FB���������ڹ���ϵͳ��һ����\n") to: fStream
							)
						)
						if FBBoneEro[2].count != 0 then(
							for n in 1 to FBBoneEro[2].count do(
								cName = FBBoneEro[2][n][1] as string
								format ("[ERROR]\t������������["+cName+"]����Ȩ��\n") to: fStream
							)
						)
						actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
					)
				)
				if n == 6 and actx_list.items.item[n-1].checked do
				(
					file_name = maxFileName as string
					if (2>file_name.count) do (file_name = "00")
					type = tolower (file_name[1] + file_name[2])
					if rol_AnimOutputCheck.rdo_sel.state == 1 then transEro = fn_BoneTransCheck type
					else transEro = fn_BoneTransCheck type
					if transEro.count == 0 then
					(
						
						actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
					)
					else
					(
						for info in transEro do(
							cName = info.objc.name as string
							err_msg = info.ero
							format ("[ERROR]\t����["+cName+"]"+err_msg+"\n") to: fStream
						)
						actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
					)
				)
-- 				if n == 6 and actx_list.items.item[n-1].checked do
-- 				(
-- 					if rol_AnimOutputCheck.rdo_sel.state == 1 then matIDEro = fn_objMaterialIDCheck (objects as array)
-- 					else matIDEro = fn_objMaterialIDCheck (selection as array)
-- 					if matIDEro.count == 0 then
-- 					(
-- 						actx_list.items.item[n-1].SubItems.item[1].text = "ͨ�����"
-- 					)
-- 					else
-- 					(
-- 						actx_list.items.item[n-1].SubItems.item[1].text = "δͨ�����"
-- 					)
-- 				)
			)
			flush fStream
			file_index += 1
			if file_index > my_files.count then(
				close fStream
				file_index = 1
				my_files = #()
				btn_batCheck.enabled = true
				edt_batCheckPath.enabled = true
				tmr_batCheck.active = false
			)
		)
	)
)

/*  �����û����洰��  */
createDialog rol_AnimOutputCheck

/*  ��������  */


--    End AnimOutputCheck_V1.00    --
