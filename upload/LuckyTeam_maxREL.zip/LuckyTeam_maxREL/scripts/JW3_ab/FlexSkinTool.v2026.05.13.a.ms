/*

2023.01.19 created by Ou Jian.

*/

------------------------------------------------------------
--����������Custom Attribute������������--
------------------------------------------------------------

--	Attribute_FlexVertexColor = undefined
--	����Flex���϶���ɫ�������á�ע��汾��version��Flex Skin Tool�Ŀ��ܻ᲻ͬ��
Attribute_FlexVertexColor = attributes KG3D_FlexVertexColor version:20230126 attribID:#(0x39db0957, 0x1913f9ed)
(
	local node_current = $
	local ary_baseObjectAlphas = #()
	local ary_baseObjectIlluminations = #()
	local ary_baseObjectVertexColors = #()
	
	----	<local_function_decl>	----
	
	
	--	����ƥ�䶥��ɫ��MapVerts������
	fn fn_rematchMapVertex node_obj int_mapChannel =
	(
		local ary_colorList = #()
		local ary_sameColor = #()
		local bary_hiddenVerts = polyop.getHiddenVerts node_obj
		local ary_paintVerts = #{1..node_obj.verts.count}
		local bary_selVerts = node_obj.EditablePoly.GetSelection #Vertex
		
		if ( undefined == int_mapChannel ) do return()
		setWaitCursor()
		node_obj.EditablePoly.unhideAll #Vertex
		polyop.setMapSupport node_obj int_mapChannel true
		
		--	Ѱ��ͬɫ�Ķ��㣬����ŵ�ary_sameColorȥ��
		ary_colorList[1] = white
		ary_sameColor[1] = polyop.getVertsByColor node_obj white 0 0 0 channel:0
		ary_paintVerts = ary_paintVerts-ary_sameColor[1]
		for int_v in ary_paintVerts do
		(
			local pt3_vertColor,int_sameColor,bary_current,bary_allSames,bary_sames
			
			node_obj.EditablePoly.SetSelection #Vertex #{int_v}
			pt3_vertColor = node_obj.EditablePoly.GetVertexColor int_mapChannel
			bary_sames = polyop.getVertsByColor node_obj pt3_vertColor 0.001 0.001 0.001 channel:int_mapChannel
			
			for v in bary_sames do
			(
				local int_n = findItem ary_paintVerts v
				
				if ( 0<int_n ) do ( deleteItem ary_paintVerts int_n )
			)
			
			pt3_vertColor = pt3_vertColor as point3
			int_sameColor = findItem ary_colorList pt3_vertColor
			if ( 0 == int_sameColor ) then
			(
				append ary_colorList pt3_vertColor
				append ary_sameColor bary_sames
			)
			else
			(
				ary_sameColor[int_sameColor] += bary_sames
			)
		)
		
		--	��ԭ����ɫΪĬ��ֵ��
		polyop.defaultMapFaces node_obj int_mapChannel
		
		--	�������û�ԭ��ԭ���Ķ�����ɫ��
		for n = 1 to ary_colorList.count do
		(
			polyop.setVertColor node_obj int_mapChannel ary_sameColor[n] ( ary_colorList[n] as color )
		)
		
		polyop.setHiddenVerts node_obj bary_hiddenVerts
		node_obj.EditablePoly.SetSelection #Vertex bary_selVerts
		setArrowCursor()
	)
	
	--	��ȡ����ζ�����ɫ��
	fn fn_getPolyVertexColor node_obj int_channel =
	(
		local ary_colors = #()
		
		if ( true == polyop.getMapSupport node_obj int_channel ) do
		(
			for int_v in 1 to node_obj.verts.count do
			(
				local color_vert = polyop.getMapVert node_obj int_channel int_v
				
				append ary_colors ( color_vert*255 )
			)
		)
		
		return ary_colors
	)
	
	parameters par_paintMode rollout:rol_paintMode
	(
		vertexShadedOff type:#boolean default:false ui:ckb_shadedOff
		alphaChannel type:#boolean default:false ui:ckb_alpha
		illuminationChannel type:#boolean default:false ui:ckb_Illumination
		vertexColorChannel type:#boolean default:false ui:ckb_VertexColor
	)
	rollout rol_paintMode "Paint Mode" rolledUp:false
	(
		fn fn_setVertexChannel i_control state = 
		(
			local name_channel = toLower i_control.name
			
			case of
			(
				( undefined != findString name_channel "alpha" ) : ( name_channel = #alpha )
				( undefined != findString name_channel "color" ) : ( name_channel = #color )
				( undefined != findString name_channel "illum" ) : ( name_channel = #illum )
				default:()
			)
			
			this.rol_paintMode.ckb_alpha.state = this.rol_paintMode.ckb_Illumination.state = this.rol_paintMode.ckb_VertexColor.state = false
			for obj in selection do
			(
				obj.vertexColorType = name_channel
				obj.showVertexColors = false
				obj.showVertexColors = state
				obj.vertexColorsShaded = not this.vertexShadedOff
			)
			i_control.state = state
			case of
			(
				( true == this.alphaChannel ) : ( this.rol_paintVertexes.int_vertexMapChannel = -2 )
				( true == this.illuminationChannel ) : ( this.rol_paintVertexes.int_vertexMapChannel = -1 )
				( true == this.vertexColorChannel ) : ( this.rol_paintVertexes.int_vertexMapChannel = 0 )
				default:( this.rol_paintVertexes.int_vertexMapChannel = undefined )
			)
		)
		
		button 'btn_hide' "Hide Sub..." pos:[16,8] width:60 height:20 align:#left
		button 'btn_unhide' "Unhide All" pos:[84,8] width:60 height:20 align:#left
		button 'btn_hideUnselected' "Hide Unselected" pos:[16,32] width:128 height:20 align:#left
		label 'lbl_ObjectShading' "Object Shading:" pos:[16,60] width:80 height:16 align:#left
		checkbutton 'ckb_Wireframe' "Wireframe" pos:[96,56] width:24 height:24 toolTip:"Wireframe" border:false align:#left
		checkbutton 'ckb_material' "Material" pos:[120,56] width:24 height:24 toolTip:"Material" border:false align:#left
		label 'lbl_VertexChannel' "Vertex Channel:" pos:[16,92] width:80 height:16 align:#left
		checkbutton 'ckb_shadedOff' "Shaded" pos:[96,88] width:48 height:20 highlightColor:(color 180 180 180) align:#left
		checkbutton 'ckb_alpha' "Alpha" pos:[20,112] width:40 height:24 toolTip:"Alpha" border:false align:#left
		checkbutton 'ckb_Illumination' "Illumination" pos:[60,112] width:40 height:24 toolTip:"Illumination" border:false align:#left
		checkbutton 'ckb_VertexColor' "Color" pos:[100,112] width:40 height:24 toolTip:"Color" border:false align:#left
		button 'btn_resetAllColors' "Reset All Colors" pos:[16,136] width:128 height:24 align:#left
		button 'btn_WarpSelectedColor' "Warp Selected Color" pos:[16,160] width:128 height:24 align:#left
		------------------------
		on rol_paintMode open do
		(
			local bmp_icon = "VertexPaint_i.bmp"
			
			node_current = $
			ckb_Alpha.images = #(bmp_icon, bmp_icon, 23, 13, 13, 13, 13, true, true)
			ckb_Illumination.images = #(bmp_icon, bmp_icon, 23, 1, 1, 1, 1, true, true)
			ckb_VertexColor.images = #(bmp_icon, bmp_icon, 23, 4, 4, 4, 4, true, true)
			
			ckb_Wireframe.images = #(bmp_icon, bmp_icon, 23, 5, 5, 5, 5, false, true)
			ckb_Material.images = #(bmp_icon, bmp_icon, 23, 3, 3, 3, 3, false, true)
			if ( true == this.alphaChannel ) do ( this.rol_paintVertexes.int_vertexMapChannel = -2 )
			if ( true == this.illuminationChannel ) do ( this.rol_paintVertexes.int_vertexMapChannel = -1 )
			if ( true == this.vertexColorChannel ) do ( this.rol_paintVertexes.int_vertexMapChannel = 0 )
			
			--	ʹ��when��ʵʱ���¿ؼ�״̬��
			when parameters node_current change id:#KG3D_FlexVertexColor_subobjectLevel handleAt:#redrawViews do
			(
				if ( Editable_Poly == classOf node_current.baseobject ) do
				(
					local bol_gradual = ( 2 == subobjectLevel )
					local bol_channels = ( true == this.alphaChannel ) or ( true == this.illuminationChannel ) or ( true == this.vertexColorChannel )
					
					for ctrl in this.rol_paintVertexes.controls do ( ctrl.enabled = bol_channels )
					btn_hide.enabled = ( 0<subobjectLevel )
					btn_WarpSelectedColor.enabled = ( 0<subobjectLevel ) and ( undefined != this.rol_paintVertexes.int_vertexMapChannel )
					this.rol_paintVertexes.btn_ring.enabled = this.rol_paintVertexes.btn_loop.enabled = bol_gradual
					this.rol_paintVertexes.btn_PaintGradualColor.enabled = ( bol_gradual and 0<this.rol_paintVertexes.ary_selGradualEdges.count )
				)
			)
			this.vertexShadedOff = node_current.vertexColorsShaded
		)
		on rol_paintMode close do
		(
			deleteAllChangeHandlers id:#KG3D_FlexVertexColor_subobjectLevel
		)
		on btn_hide pressed do
		(
			local bary_selFaces = #{}
			local bary_selVerts = #{}
			
			case subobjectLevel of
			(
				( 1 ):
				(
					bary_selFaces = getVertSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selFaces = polyop.getFacesUsingVert node_current bary_selFaces
				)
				( 2 ):
				(
					bary_selFaces = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selFaces = polyop.getFacesUsingEdge node_current bary_selFaces
					node_current.EditablePoly.SetSelection #Edge #{}
				)
				( 3 ):
				(
					bary_selFaces = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selFaces = polyop.getFacesUsingEdge node_current bary_selFaces
					node_current.EditablePoly.SetSelection #Edge #{}
				)
				( 4 ):
				(
					bary_selFaces = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
				)
				( 5 ):
				(
					bary_selFaces = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
				)
				default:()
			)
			bary_selVerts = polyop.getVertsUsingFace node_current bary_selFaces
			polyop.setHiddenVerts node_current bary_selVerts
			polyop.setHiddenFaces node_current bary_selFaces
			setFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor] #{}
			redrawViews()
		)
		on btn_unhide pressed do
		(
			polyop.unHideAllFaces node_current
			polyop.unHideAllVerts node_current
			redrawViews()
		)
		on btn_hideUnselected pressed do
		(
			local bary_selFaces = #{}
			local bary_selVerts = #{}
			
			case subobjectLevel of
			(
				( 1 ):
				(
					bary_selFaces = getVertSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selFaces = polyop.getFacesUsingVert node_current bary_selFaces
				)
				( 2 ):
				(
					bary_selFaces = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selFaces = polyop.getFacesUsingEdge node_current bary_selFaces
					node_current.EditablePoly.SetSelection #Edge #{}
				)
				( 3 ):
				(
					bary_selFaces = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selFaces = polyop.getFacesUsingEdge node_current bary_selFaces
					node_current.EditablePoly.SetSelection #Edge #{}
				)
				( 4 ):
				(
					bary_selFaces = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
				)
				( 5 ):
				(
					bary_selFaces = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
				)
				default:()
			)
			bary_selVerts = polyop.getVertsUsingFace node_current bary_selFaces
			polyop.setHiddenVerts node_current ( #{1..node_current.verts.count}-bary_selVerts )
			polyop.setHiddenFaces node_current ( #{1..node_current.faces.count}-bary_selFaces )
			
			redrawViews()
		)
		on ckb_Wireframe changed state do ( viewport.SetShowEdgeFaces state )
		on ckb_material changed state do
		(
			if ( true == state ) then ( displayColor.shaded = #material )
			else ( displayColor.shaded = #object )
		)
		on ckb_shadedOff changed state do ( for obj in selection do ( obj.vertexColorsShaded = not state ) )
		on ckb_alpha changed state do ( fn_setVertexChannel ckb_alpha state )
		on ckb_Illumination changed state do ( fn_setVertexChannel ckb_Illumination state )
		on ckb_VertexColor changed state do ( fn_setVertexChannel ckb_VertexColor state )
		on btn_resetAllColors pressed do
		(
			if ( true == queryBox "Reset All Verts Colors In All channels?" ) do
			(
				polyop.defaultMapFaces node_current  0
				polyop.defaultMapFaces node_current -1
				polyop.defaultMapFaces node_current -2
				redrawViews()
			)
		)
		on btn_WarpSelectedColor pressed do
		(
			local bary_selVerts = #{}
			
			case subobjectLevel of
			(
				( 1 ):
				(
					bary_selVerts = getVertSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
				)
				( 2 ):
				(
					bary_selVerts = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selVerts = polyop.getVertsUsingEdge node_current bary_selVerts
				)
				( 3 ):
				(
					bary_selVerts = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selVerts = polyop.getVertsUsingEdge node_current bary_selVerts
				)
				( 4 ):
				(
					bary_selVerts = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selVerts = polyop.getVertsUsingFace node_current bary_selVerts
				)
				( 5 ):
				(
					bary_selVerts = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selVerts = polyop.getVertsUsingFace node_current bary_selVerts
				)
				default:()
			)
			
			if ( false == bary_selVerts.isEmpty ) do
			(
				local temp
				local pt3_Vmax = [0,0,0]
				local pt3_Vmin = [0,0,0]
				local int_extend = (node_current.max-node_current.min)/23
				local bary_warpTarget = #{1..node_current.verts.count}-bary_selVerts
				
				--	����ѡ�ж���������С��Χ��
				temp = sort ( for int_v in bary_selVerts collect node_current.verts[int_v].pos.x )
				pt3_Vmin.x = temp[1]
				pt3_Vmax.x = temp[temp.count]
				temp = sort ( for int_v in bary_selVerts collect node_current.verts[int_v].pos.y )
				pt3_Vmin.y = temp[1]
				pt3_Vmax.y = temp[temp.count]
				temp = sort ( for int_v in bary_selVerts collect node_current.verts[int_v].pos.z )
				pt3_Vmin.z = temp[1]
				pt3_Vmax.z = temp[temp.count]
				--	��ѡ�ж��㰴λ�÷ֿ�ֿ飨Ϊ�˿��ټ��㣩��
				
				
				
				--	�ʵ���չ��Χ�������ڷ�Χ�ڵ�WarpTargetȥ����
				pt3_Vmin = pt3_Vmin-int_extend
				pt3_Vmax = pt3_Vmax+int_extend
				temp = #{}
				for int_v in bary_warpTarget do
				(
					if 	( pt3_Vmin.x<node_current.verts[int_v].pos.x and pt3_Vmax.x>node_current.verts[int_v].pos.x ) and \
						( pt3_Vmin.y<node_current.verts[int_v].pos.y and pt3_Vmax.y>node_current.verts[int_v].pos.y ) and \
						( pt3_Vmin.z<node_current.verts[int_v].pos.z and pt3_Vmax.z>node_current.verts[int_v].pos.z )
					do 	( append temp int_v )
				)
				bary_warpTarget = temp-( polyop.getHiddenVerts node_current.baseobject )
				--	warp����Ķ��㡣
				for int_v in bary_selVerts do
				(
					local flt_min = 65535.0
					local pt3_warp = [0,0,0]
					local int_min = 1
					
					for int_w in bary_warpTarget do
					(
						local flt_length = distance node_current.verts[int_v].pos node_current.verts[int_w].pos
						
						if ( flt_min>flt_length ) do
						(
							int_min = int_w
							flt_min = flt_length
						)
					)
					node_current.EditablePoly.SetSelection #Vertex #{int_min}
					pt3_warp = node_current.GetVertexColor this.rol_paintVertexes.int_vertexMapChannel
					polyop.setVertColor node_current this.rol_paintVertexes.int_vertexMapChannel int_v pt3_warp
				)
				node_current.EditablePoly.SetSelection #Vertex #{}
				update node_current
			)
		)
	)
	
	parameters par_paintVertexes rollout:rol_paintVertexes
	(
		mapAlpha type:#point3Tab tabSizeVariable:true
		mapVertexColor type:#point3Tab tabSizeVariable:true
		mapIllumination type:#point3Tab tabSizeVariable:true
		
		currentPaintColor type:#color animatable:true default:white ui:cp_CurrentPaintColor
		
		brushPaintSize type:#float default:5 ui:spn_BrushPaintSize
		brushPressure type:#boolean default:false ui:chk_EnableBrushPressure
		
		redChannel type:#boolean default:true ui:ckb_redChannel
		greenChannel type:#boolean default:true ui:ckb_greenChannel
		blueChannel type:#boolean default:true ui:ckb_blueChannel
		vertexHold type:#boolean default:false ui:ckb_hold
		
		paintState type:#boolean default:false ui:ckb_paintState
		eraseState type:#boolean default:false ui:ckb_eraseState
		pickState type:#boolean default:false ui:ckb_PickState
		
		gradualWhite type:#boolean default:true ui:chk_IncludeWhiteColor
		gradualEnd type:#color default:black ui:cp_GradualEnd
		gradualStart type:#color default:white ui:cp_GradualStart
		
		specialState1 type:#boolean default:true ui:ckb_SpecialColor1
		specialState2 type:#boolean default:true ui:ckb_SpecialColor2
		specialState3 type:#boolean default:true ui:ckb_SpecialColor3
		specialState4 type:#boolean default:true ui:ckb_SpecialColor4
		specialState5 type:#boolean default:false ui:ckb_SpecialColor5
		specialState6 type:#boolean default:false ui:ckb_SpecialColor6
		specialColor1 type:#color default:(color 0 254 0) animatable:true
		specialColor2 type:#color default:(color 0 253 0) animatable:true
		specialColor3 type:#color default:(color 0 250 0) animatable:true
		specialColor4 type:#color default:(color 0 249 0) animatable:true
		specialColor5 type:#color default:black animatable:true
		specialColor6 type:#color default:black animatable:true
		
		on currentPaintColor postSet val do
		(
			this.rol_paintVertexes.spn_R.value = val.r
			this.rol_paintVertexes.spn_G.value = val.g
			this.rol_paintVertexes.spn_B.value = val.b
		)
		
		on specialState6 preset val do
		(
			--	preSet����Ҫ�з���ֵ
			val
		)
	)
	rollout rol_paintVertexes "Paint Vertexes" width:160 height:560 rolledUp:false
	(
		local bary_gatheredPoints = #{}
		local ary_selGradualEdges = #()
		local pt3_paintRGBChannel = [0,0,0]
		local int_vertexMapChannel = undefined
		
		--	�������� A-->B >> C������һ��������ţ�intֵ��
		fn fn_getExtendVert node_obj int_vert0 int_vertA int_vertB =
		(
			local int_extend = 0
			local ary_extVerts = #()
			local bary_extEdgesA = polyop.getEdgesUsingVert node_obj int_vertA
			local bary_extVertsA = polyop.getVertsUsingEdge node_obj bary_extEdgesA
			local bary_extEdgesB = polyop.getEdgesUsingVert node_obj int_vertB
			local bary_extVertsB = polyop.getVertsUsingEdge node_obj bary_extEdgesB
			
			--	�ı������ڣ�����չ�ų������㡣A-->B
			if ( 4 == bary_extEdgesA.numberSet and 4 == bary_extEdgesB.numberSet ) then
			(
				bary_extVertsA = bary_extVertsA-#{int_vertA,int_vertB}
				bary_extVertsB = bary_extVertsB-#{int_vertA,int_vertB}
				--	��չ��Χ
				bary_extEdgesA = polyop.getEdgesUsingVert node_obj bary_extVertsA
				
				for int_v in bary_extVertsB do
				(
					local bary_vertEdges = polyop.getEdgesUsingVert node_obj int_v
					--	��int_v��Edge��A�����չEdge�޽�����
					if ( bary_extEdgesA.numberSet == ( bary_extEdgesA-bary_vertEdges ).numberSet ) do
					(
						int_extend = int_v
						exit
					)
				)
			)
			--	���������ڣ��þ����㡣max�д�ʱĬ�ϻ�ֹͣ��չ��
			else
			(
				local bary_extFacesB = polyop.getFacesUsingVert node_obj int_vertB
				local flt_minZ,x_normal,y_normal,z_normal,matrix_B
				
				bary_extEdgesB = polyop.getEdgesUsingVert node_obj int_vertB
				bary_extVertsB = polyop.getVertsUsingEdge node_obj bary_extEdgesB
				
				if ( undefined == int_vert0 ) then
				( x_normal = normalize ( node_obj.verts[int_vertB].pos-node_obj.verts[int_vertA].pos ) )
				else
				( x_normal = normalize ( node_obj.verts[int_vertB].pos-node_obj.verts[int_vert0].pos ) )
				y_normal = [0,0,0]
				for i_face in bary_extFacesB do
				(
					y_normal += polyop.getFaceNormal node_obj i_face node:node_obj
				)
				y_normal = normalize ( y_normal/bary_extFacesB.numberSet )
				z_normal = normalize(cross x_normal y_normal)
				y_normal = normalize(cross z_normal x_normal)
				matrix_B = matrix3 x_normal y_normal z_normal node_obj.verts[int_vertB].pos
				
				bary_extVertsB = bary_extVertsB-#{int_vertA,int_vertB}
				flt_minZ = 65535
				for int_v in bary_extVertsB do
				(
					local pt3_pos = in coordSys matrix_B node_obj.verts[int_v].pos
					local flt_scale = ( abs pt3_pos.z )/( length pt3_pos )
					
					if ( flt_minZ>flt_scale ) do
					(
						flt_minZ = flt_scale
						int_extend = int_v
					)
				)
			)
			
			return int_extend
		)
		
		--	��ȡָ��Edge��loopEdges������һ����������ary_loopEdges��
		fn fn_getLoopEdges node_obj int_edge bary_borderEdges =
		(
			local bary_borderVerts = #{}
			local bary_exceptVerts = #{}
			local bary_exceptEdges = #{}
			local ary_loopEdges = #(int_edge)
			local ary_loopVerts = ( polyop.getVertsUsingEdge node_obj int_edge ) as array
			local ary_LoopA = #(ary_loopVerts[1],ary_loopVerts[2])
			local ary_LoopB = #(ary_loopVerts[2],ary_loopVerts[1])
			local bary_borderVerts = polyop.getVertsUsingEdge node_obj bary_borderEdges
			
			--	int_edge���Ǳ�Ե�ϵ��߶Σ���������������Ե��
			if ( 0 == findItem bary_borderEdges int_edge ) then
			(
				for int_v in ary_LoopA do
				(
					local int_extend
					local int_vert0 = undefined
					local int_vertA = ary_LoopA[ary_LoopA.count-1]
					local int_vertB = ary_LoopA[ary_LoopA.count]
					
					if ( 0 == findItem bary_borderVerts int_vertB ) then
					(
						bary_exceptEdges = polyop.getEdgesUsingVert node_obj int_vertA
						bary_exceptVerts += polyop.getVertsUsingEdge node_obj bary_exceptEdges
						
						if ( 3<ary_LoopA.count ) do ( int_vert0 = ary_LoopA[1] )
						int_extend = fn_getExtendVert node_obj int_vert0 int_vertA int_vertB
						
						if ( 0 == findItem bary_exceptVerts int_extend ) do
						(
							local bary_edgeB = polyop.getEdgesUsingVert node_obj int_vertB
							local bary_EdgeC = polyop.getEdgesUsingVert node_obj int_extend
							
							append ary_LoopA int_extend
							append ary_loopVerts int_extend
							append ary_loopEdges ( ( bary_edgeB-(bary_edgeB-bary_edgeC) ) as array )[1]
						)
					--	if ( 0 != findItem bary_borderVerts int_extend ) do exit
					)
					else
					(
						exit
					)
				)
				bary_exceptVerts = #{}
				for int_v in ary_LoopB do
				(
					local int_extend
					local int_vert0 = undefined
					local int_vertA = ary_LoopB[ary_LoopB.count-1]
					local int_vertB = ary_LoopB[ary_LoopB.count]
					
					if ( 0 == findItem bary_borderVerts int_vertB ) then
					(
						bary_exceptEdges = polyop.getEdgesUsingVert node_obj int_vertA
						bary_exceptVerts += polyop.getVertsUsingEdge node_obj bary_exceptEdges
						
						if ( 3<ary_LoopB.count ) do ( int_vert0 = ary_LoopB[1] )
						int_extend = fn_getExtendVert node_obj int_vert0 int_vertA int_vertB
						
						if ( 0 == findItem bary_exceptVerts int_extend ) do
						(
							local bary_edgeB = polyop.getEdgesUsingVert node_obj int_vertB
							local bary_EdgeC = polyop.getEdgesUsingVert node_obj int_extend
							
							append ary_LoopB int_extend
							insertItem int_extend ary_loopVerts 1
							insertItem ( ( bary_edgeB-(bary_edgeB-bary_edgeC) ) as array )[1] ary_loopEdges 1
						)
					--	if ( 0 != findItem bary_borderVerts int_extend ) do exit
					)
					else
					(
						exit
					)
				)
			)
			--	int_edgeΪ��Ե�ϵ��߶Σ��ڱ�Ե��������������ֹͣ�߼��ϡ�
			else
			(
				local int_vert,int_extEdge
				
				ary_loopVerts = ( polyop.getVertsUsingEdge node_obj int_edge ) as array
				
				int_vert = ary_loopVerts[2]
				int_extEdge = int_edge
				while ( 0<int_vert ) do
				(
					local bary_vEdges = polyop.getEdgesUsingVert node_obj int_vert
					local bary_eFaces = polyop.getFacesUsingEdge node_obj int_extEdge
					local bary_fEdges = polyop.getEdgesUsingFace node_obj bary_eFaces
					local bary_same = bary_vEdges-bary_fEdges
					
					if ( 0<bary_same.numberSet ) then
					(
						int_extEdge = ( ( bary_vEdges-bary_fEdges ) as array )[1]
						int_vert = ( ( (polyop.getVertsUsingEdge node_obj #{int_extEdge})-(ary_loopVerts as bitArray) ) as array )[1]
						bary_vEdges = polyop.getEdgesUsingVert node_obj int_vert
						if ( 3<bary_vEdges.numberSet ) then
						(
							int_vert = 0
						)
						else
						(
							append ary_loopVerts int_vert
							append ary_loopEdges int_extEdge
						)
					)
					else
					(
						int_vert = 0
					)
				)
				int_vert = ary_loopVerts[1]
				int_extEdge = int_edge
				while ( 0<int_vert ) do
				(
					local bary_vEdges = polyop.getEdgesUsingVert node_obj int_vert
					local bary_eFaces = polyop.getFacesUsingEdge node_obj int_extEdge
					local bary_fEdges = polyop.getEdgesUsingFace node_obj bary_eFaces
					local bary_same = bary_vEdges-bary_fEdges
					
					if ( 0<bary_same.numberSet ) then
					(
						int_extEdge = ( ( bary_vEdges-bary_fEdges ) as array )[1]
						int_vert = ( ( (polyop.getVertsUsingEdge node_obj #{int_extEdge})-(ary_loopVerts as bitArray) ) as array )[1]
						bary_vEdges = polyop.getEdgesUsingVert node_obj int_vert
						if ( 3<bary_vEdges.numberSet ) then
						(
							int_vert = 0
						)
						else
						(
							insertItem int_vert ary_loopVerts 1
							insertItem int_extEdge ary_loopEdges 1
						)
					)
					else
					(
						int_vert = 0
					)
				)
			)
			--	setEdgeSelection $ $.modifiers[1] ary_loopEdges --keep:true
			--	setVertSelection $ $.modifiers[1] ary_loopVerts --keep:true
			
			return ary_loopEdges
		)
		
		--	��ѡ�е�ringEdges���򣬷���һ����������顣#(#(��1��Ring)��#(��2��Ring)...#(#(��m����1��Loop),#(��m����2��Loop)...#(��m����n��Loop))...#(��n��Ring))
		fn fn_sortRingEdges node_obj bary_selectedEdges =
		(
			local ary_sortRingEdges = #()
			local bary_borderEdges = #{}
			local bary_startEdges = #{}
			
			--	�ռ�ģ�ͱ�Ե�ߡ�
			for i_edge in bary_selectedEdges do
			(
				local bary_faces = polyop.getFacesUsingEdge node_obj i_edge
				
				if ( 1 == bary_faces.numberSet ) then
				(
					append bary_borderEdges i_edge
				)
				else
				(
					local bary_extEdges = polyop.getEdgesUsingFace node_obj bary_faces
					
					if ( 3>( bary_extEdges-(bary_extEdges-bary_selectedEdges) ).numberSet ) do
					(
						append bary_startEdges i_edge
					)
				)
			)
			if ( 11 == i_debug ) do ( format "bary_startEdges=%;bary_borderEdges=%\n" bary_startEdges bary_borderEdges )
			
			for i_border in bary_borderEdges do
			(
				local ary_sortEdges = #(i_border)
				
				for i_edge in ary_sortEdges do
				(
					local bary_faces = polyop.getFacesUsingEdge node_obj i_edge
					local bary_extEdges = polyop.getEdgesUsingFace node_obj bary_faces
					local bary_same = ( bary_extEdges-(bary_extEdges-bary_selectedEdges) )-( ary_sortEdges as bitArray )
					
					if ( 0<bary_same.numberSet ) do
					(
						local int_same = ( bary_same as array )[1]
						
						bary_startEdges = bary_startEdges-bary_same
						append ary_sortEdges int_same
						if ( true == bary_borderEdges[int_same] ) do ( deleteItem bary_borderEdges int_same )
					)
				)
				if ( 0 == ary_sortRingEdges.count ) then
				(
					ary_sortRingEdges[1] = ary_sortEdges
				)
				else
				(
					for n = 1 to ary_sortRingEdges.count do
					(
						if ( ary_sortEdges.count<ary_sortRingEdges[n].count ) then
						(
							insertItem ary_sortEdges ary_sortRingEdges n
						)
						else
						(
							if ( undefined == ary_sortRingEdges[n+1] ) do
							( append ary_sortRingEdges ary_sortEdges )
						)
					)
				)
			)
			
			for i_start in bary_startEdges do
			(
				local ary_sortEdges = #(i_start)
				
				for i_edge in ary_sortEdges do
				(
					local bary_faces = polyop.getFacesUsingEdge node_obj i_edge
					local bary_extEdges = polyop.getEdgesUsingFace node_obj bary_faces
					local bary_same = ( bary_extEdges-(bary_extEdges-bary_selectedEdges) )-( ary_sortEdges as bitArray )
					
					join ary_sortEdges bary_same
					for i_same in bary_same do ( deleteItem bary_startEdges i_same )
				)
				if ( 0 == ary_sortRingEdges.count ) then
				(
					ary_sortRingEdges[1] = ary_sortEdges
				)
				else
				(
					for n = 1 to ary_sortRingEdges.count do
					(
						if ( ary_sortEdges.count<ary_sortRingEdges[n].count ) then
						(
							insertItem ary_sortEdges ary_sortRingEdges n
						)
						else
						(
							if ( undefined == ary_sortRingEdges[n+1] ) do
							( append ary_sortRingEdges ary_sortEdges )
						)
					)
				)
			)
			
			return ary_sortRingEdges
		)
		
		--	����Ϊ��ˢ����	--
		fn startStroke = 
		(
			if ( 11 == i_debug ) do ( format "KG3D_FlexVertexColor:>thePainterInterface startStroke.\n" )
			thePainterInterface.undoStart() 
			--	�Ƿ�����ɿ��Ÿ������ݡ�
			thePainterInterface.updateOnMouseUp = false
			thePainterInterface.updateMeshes true
			thePainterInterface.offMeshHitType = 0
		)
		
		fn paintStroke = 
		(
			if ( 11 == i_debug ) do ( format "KG3D_FlexVertexColor:>thePainterInterface paintStroke:\n" )
			local rol_current
			local node_current = $
			local bary_newPoint = #{}
			local bary_selVerts = #{1..node_current.verts.count}
			local bary_current = thePainterInterface.getPointGatherHits node_current
			
			if ( undefined == node_current.modifiers[#KG3D_FlexVertexColor] ) then
			(
				rol_current = node_current.rol_paintVertexes
			)
			else
			(
				rol_current = node_current.modifiers[#KG3D_FlexVertexColor].rol_paintVertexes
			)
			
			bary_newPoint += bary_current-bary_gatheredPoints
			bary_gatheredPoints += bary_current
			case subobjectLevel of
			(
				( 1 ):
				(
					bary_selVerts = getVertSelection node_current 1
				)
				( 2 ):
				(
					bary_selVerts = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selVerts = polyop.getVertsUsingEdge node_current bary_selVerts
				)
				( 3 ):
				(
					bary_selVerts = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selVerts = polyop.getVertsUsingEdge node_current bary_selVerts
				)
				( 4 ):
				(
					bary_selVerts = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selVerts = polyop.getVertsUsingFace node_current bary_selVerts
				)
				( 5 ):
				(
					bary_selVerts = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					bary_selVerts = polyop.getVertsUsingFace node_current bary_selVerts
				)
				default:()
			)
			bary_newPoint = bary_selVerts-( bary_selVerts-bary_newPoint )-( polyop.getHiddenVerts node_current.baseobject )
			if ( 11 == i_debug ) do ( format "bary_newPoint=%;bary_current=%;bary_gatheredPoints=%\n" bary_newPoint bary_current bary_gatheredPoints )
			
			if ( false == bary_newPoint.isEmpty and undefined != int_vertexMapChannel ) do
			(
				local pt3_color = rol_current.cp_CurrentPaintColor.color as point3
				
				if ( true == rol_current.ckb_eraseState.state ) do ( pt3_color = [255,255,255] )
				
				if ( [1,1,1] == rol_current.pt3_paintRGBChannel ) then
				(
					polyop.setVertColor node_current int_vertexMapChannel bary_newPoint ( pt3_color as color )
				)
				else
				(
					local ary_colorList = #()
					local ary_sameColor = #()
					local bary_selVerts = node_current.EditablePoly.GetSelection #Vertex
					
					for int_v in bary_newPoint do
					(
						local pt3_vertColor,int_sameColor
						
						node_current.EditablePoly.SetSelection #Vertex #{int_v}
						pt3_vertColor = ( node_current.EditablePoly.GetVertexColor int_vertexMapChannel ) as point3
						int_sameColor = findItem ary_colorList pt3_vertColor
						
						if ( 0 == int_sameColor ) then
						(
							append ary_colorList pt3_vertColor
							append ary_sameColor #{int_v}
						)
						else
						(
							append ary_sameColor[int_sameColor] int_v
						)
					)
					for n = 1 to ary_colorList.count do
					(
						if ( 1 == rol_current.pt3_paintRGBChannel.x ) do ( ary_colorList[n].x = pt3_color.x )
						if ( 1 == rol_current.pt3_paintRGBChannel.y ) do ( ary_colorList[n].y = pt3_color.y )
						if ( 1 == rol_current.pt3_paintRGBChannel.z ) do ( ary_colorList[n].z = pt3_color.z )
						polyop.setVertColor node_current int_vertexMapChannel ary_sameColor[n] ( ary_colorList[n] as color )
					)
					node_current.EditablePoly.SetSelection #Vertex bary_selVerts
				)
				update node_current
			)
		)
		
		fn endStroke = 
		(
			if ( 11 == i_debug ) do ( format "KG3D_FlexVertexColor:>thePainterInterface endStroke,bary_gatheredPoints=%\n" bary_gatheredPoints )
			bary_gatheredPoints = #{}
			thePainterInterface.addToStroke [1,1] true true
			thePainterInterface.undoAccept()
		)
		
		fn cancelStroke = 
		(
			if ( 11 == i_debug ) do ( format "KG3D_FlexVertexColor:>thePainterInterface cancelStroke\n" )
			thePainterInterface.undoCancel()
		)
		
		fn systemEnd = 
		(
			if ( 11 == i_debug ) do ( format "KG3D_FlexVertexColor:>thePainterInterface systemEnd\n" )
			rol_paintVertexes.ckb_paintState.state = rol_paintVertexes.ckb_eraseState.state = false
			thePainterInterface.clearStroke()
			thePainterInterface.pointGatherEnable = false
			
		)
		
		fn fn_mousePainter =
		(
			node_current = $
			if ( true == this.alphaChannel ) do ( int_vertexMapChannel = -2 )
			if ( true == this.illuminationChannel ) do ( int_vertexMapChannel = -1 )
			if ( true == this.vertexColorChannel ) do ( int_vertexMapChannel = 0 )
			
			if ( not( IsValidNode node_current ) or thePainterInterface.InPaintMode() ) then
			(
				thePainterInterface.endPaintSession()
			)
			else
			(
				thePainterInterface.ScriptFunctions startStroke paintStroke endStroke cancelStroke systemEnd
				thePainterInterface.pointGatherEnable = true
				thePainterInterface.initializeNodes 0 node_current
				
				thePainterInterface.startPaintSession()
			)
		)
		
		--	�����ɫ��
		fn fn_fillVertexesColor pt3_color =
		(
			local bary_paintVerts = #{}
			
			update node_current
			if ( undefined != int_vertexMapChannel ) do
			(
				case subobjectLevel of
				(
					( 0 ):
					(
						bary_paintVerts = #{1..node_current.verts.count}
					)
					( 1 ):
					(
						bary_paintVerts = getVertSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
					)
					( 2 ):
					(
						bary_paintVerts = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
						bary_paintVerts = polyop.getVertsUsingEdge node_current bary_paintVerts
					)
					( 3 ):
					(
						bary_paintVerts = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
						bary_paintVerts = polyop.getVertsUsingEdge node_current bary_paintVerts
					)
					( 4 ):
					(
						bary_paintVerts = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
						bary_paintVerts = polyop.getVertsUsingFace node_current bary_paintVerts
					)
					( 5 ):
					(
						bary_paintVerts = getFaceSelection node_current node_current.modifiers[#KG3D_FlexVertexColor]
						bary_paintVerts = polyop.getVertsUsingFace node_current bary_paintVerts
					)
					default:()
				)
				bary_paintVerts = bary_paintVerts-( polyop.getHiddenVerts node_current.baseobject )
				if ( true == ( this.redChannel and this.greenChannel and this.blueChannel ) ) then
				(
					polyop.setVertColor node_current int_vertexMapChannel bary_paintVerts ( pt3_color as color )
				)
				else
				(
					local bary_except = #{}
					local ary_colorList = #()
					local ary_sameColor = #()
					local bary_selVerts = node_current.EditablePoly.GetSelection #Vertex
					local ary_paintVerts = bary_paintVerts as array
					
					for int_v in ary_paintVerts do
					(
						local pt3_vertColor,int_sameColor,bary_current,bary_allSames,bary_sames
						
						node_current.EditablePoly.SetSelection #Vertex #{int_v}
						pt3_vertColor = node_current.EditablePoly.GetVertexColor int_vertexMapChannel
						bary_allSames = polyop.getVertsByColor node_current pt3_vertColor 0.1 0.1 0.1 channel:int_vertexMapChannel
						bary_current = ary_paintVerts as bitArray
						bary_sames = bary_current-( bary_current-bary_allSames )
						for v in bary_sames do
						(
							deleteItem ary_paintVerts ( findItem ary_paintVerts v )
						)
						
						pt3_vertColor = pt3_vertColor as point3
						int_sameColor = findItem ary_colorList pt3_vertColor
						if ( 0 == int_sameColor ) then
						(
							append ary_colorList pt3_vertColor
							append ary_sameColor bary_sames
						)
						else
						(
							ary_sameColor[int_sameColor] += bary_sames
						)
					)
					
					for n = 1 to ary_colorList.count do
					(
						if ( true == this.redChannel ) do ( ary_colorList[n].x = pt3_color.x )
						if ( true == this.greenChannel ) do ( ary_colorList[n].y = pt3_color.y )
						if ( true == this.blueChannel ) do ( ary_colorList[n].z = pt3_color.z )
						polyop.setVertColor node_current int_vertexMapChannel ary_sameColor[n] ( ary_colorList[n] as color )
					)
					node_current.EditablePoly.SetSelection #Vertex bary_selVerts
				)
				update node_current
			)
			max views redraw
		)
		
		--	ע��: �ؼ� checkbutton �� highlightColor ����Ϊ ֻ��д�룬���ɶ�ȡ��
		fn fn_setSpecialColors i_control state =
		(
			local int_index = i_control.name[i_control.name.count] as integer
			local name_propState = ( "specialState"+int_index as string ) as name
			local name_highlight = ( "specialColor"+int_index as string ) as name
			local bol_propState = getProperty this name_propState
			local color_highlight = getProperty this name_highlight
			
			case of
			(
				--	ָ����ɫ��
				( true == state and true == bol_propState ):
				(
					local pt3_pos = [gw.getWinSizeX(),gw.getWinSizeY()]
					local color_new = colorPickerDlg color_highlight "Set Special Color" alpha:false pos:pt3_pos applyUIScaling:true
					
					if ( undefined == color_new ) then
					(
						setProperty this name_propState false
					)
					else
					(
						setProperty this name_highlight color_new
						color_highlight = color_new
					)
				)
				--	��Ϊ��ǰɫ��
				( true == state and false == bol_propState ):
				(
					setProperty this name_propState true
					rol_paintVertexes.cp_CurrentPaintColor.color = color_highlight
				)
				--	�����ָ��ɫ��
				( false == state and true == bol_propState ):
				(
					setProperty this name_propState false
				)
				default:()
			)
			
			if ( true == i_control.state ) then
			(
				i_control.highlightColor = color_highlight
				i_control.text = "R:"+color_highlight.r as string+"\nG:"+color_highlight.g as string+"\nB:"+color_highlight.b as string
			)
			else
			(
				i_control.text = "Special Color"+int_index as string
			)
		)
		
		fn fn_updateChannelState =
		(
			pt3_paintRGBChannel = [0,0,0]
			if ( true == this.redChannel ) do ( pt3_paintRGBChannel.x = 1 )
			if ( true == this.greenChannel ) do ( pt3_paintRGBChannel.y = 1 )
			if ( true == this.blueChannel ) do ( pt3_paintRGBChannel.z = 1 )
			if ( true == this.alphaChannel ) do ( int_vertexMapChannel = -2 )
			if ( true == this.illuminationChannel ) do ( int_vertexMapChannel = -1 )
			if ( true == this.vertexColorChannel ) do ( int_vertexMapChannel = 0 )
		)
		
		--	���½���ɫ�ؼ���
		fn fn_updateGradualControls =
		(
			local bmp_Gradual = bitmap 80 16
			local color_step = (this.gradualStart-this.gradualEnd)/80.0
			local ary_pixer = for x in 0 to 79 collect ( this.gradualStart-color_step*x )
			local bol_gradual = ( 2 == subobjectLevel and Editable_Poly == classOf node_current.baseobject )
			
			for y = 0 to 15 do ( setPixels bmp_Gradual [0,y] ary_pixer )
			this.rol_paintVertexes.btn_GradualBmp.images = #(bmp_Gradual, undefined, 1, 1, 1, 1, 1)
		)
		
		--	����ɫ��ؼ���
		fn fn_updateSpecialColorControls =
		(
			local ary_controls = for ctrl in this.rol_paintVertexes.controls where ( undefined != findString ctrl.name "ckb_SpecialColor" ) collect ctrl
			
			for int_c = 1 to ary_controls.count do
			(
				local color_highlight = getProperty this ( ( "specialColor"+int_c as string ) as name )
				
				if ( true == ary_controls[int_c].state ) then
				(
					ary_controls[int_c].highlightColor = color_highlight
					ary_controls[int_c].text = "R:"+color_highlight.r as string+"\nG:"+color_highlight.g as string+"\nB:"+color_highlight.b as string
				)
				else
				(
					ary_controls[int_c].text = "Special Color"+int_c as string
				)
			)
		)
		
		label 'lbl_CurrentPaintColor' "Current Paint Color:" pos:[16,8] width:128 height:16 align:#left
		colorPicker 'cp_CurrentPaintColor' "" pos:[12,24] width:68 height:64 color:(color 255 255 255) align:#left
		label 'lbl_R' "R:" pos:[88,24] width:16 height:16 align:#left
		label 'lbl_G' "G:" pos:[88,40] width:16 height:16 align:#left
		label 'lbl_B' "B:" pos:[88,56] width:16 height:16 align:#left
		spinner 'spn_R' "" pos:[104,24] width:40 height:16 range:[0,255,255] type:#integer scale:1 align:#left
		spinner 'spn_G' "" pos:[104,40] width:40 height:16 range:[0,255,255] type:#integer scale:1 align:#left
		spinner 'spn_B' "" pos:[104,56] width:40 height:16 range:[0,255,255] type:#integer scale:1 align:#left
		button 'btn_SelectSame' "Sel-Same" pos:[88,72] width:56 height:16 align:#left
		
		label 'lbl_PaintColorChannel' "Paint Color To Channel:" pos:[16,96] width:128 height:16 align:#left
		checkbutton 'ckb_redChannel' "R" pos:[16,112] width:40 height:24 highlightColor:(color 200 0 0) checked:true align:#left
		checkbutton 'ckb_greenChannel' "G" pos:[60,112] width:40 height:24 highlightColor:(color 0 200 0) checked:true align:#left
		checkbutton 'ckb_blueChannel' "B" pos:[104,112] width:40 height:24 highlightColor:(color 0 0 200) checked:true align:#left
		
		button 'btn_paintAll' "Paint All" pos:[16,136] width:32 height:32 border:false align:#left
		checkbutton 'ckb_paintState' "Paint" pos:[48,136] width:32 height:32 border:false align:#left
		checkbutton 'ckb_eraseState' "Erase" pos:[80,136] width:32 height:32 border:false align:#left
		button 'btn_eraseAll' "Erase All" pos:[112,136] width:32 height:32 border:false align:#left
		checkbutton 'ckb_PickState' "Pick" pos:[16,168] width:32 height:32 border:false align:#left
		checkbutton 'ckb_hold' "Hold colors" pos:[48,168] width:64 height:16 highlightColor:(color 0 128 0) border:false align:#left
		button 'btn_remapping' "�� Repair��" pos:[48,184] width:64 height:16 align:#left
		button 'btn_brushOptions' "Brush Options" pos:[112,168] width:32 height:32 border:false align:#left
		
		spinner 'spn_BrushPaintSize' "Brush Paint Size:" pos:[16,201] width:102 height:16 range:[1,1024,5] type:#float scale:0.1 align:#left
		checkbox 'chk_EnableBrushPressure' "Enable Brush Pressure" pos:[16,215] width:128 height:16 checked:false border:false align:#left
		
		GroupBox 'grp_GradualPaint' "Gradual Paint:" pos:[16,240] width:128 height:104 align:#left
		checkbox 'chk_IncludeWhiteColor' "Include White Color" pos:[25,256] width:112 height:16 align:#left
		button 'btn_ring' "Ring" pos:[24,272] width:40 height:24 align:#left
		checkbutton 'ckb_gradula' "<->" pos:[68,272] width:24 height:24 highlightColor:(color 255 255 0) align:#left
		button 'btn_loop' "Loop" pos:[96,272] width:40 height:24 align:#left
		colorPicker 'cp_GradualStart' "" pos:[20,296] width:20 height:16 color:(color 255 255 255) align:#left
		button 'btn_GradualBmp' "GradualBmp" pos:[40,296] width:80 height:16 enabled:false border:false align:#left
		colorPicker 'cp_GradualEnd' "" pos:[116,296] width:20 height:16 color:(color 0 0 0) align:#left
		button 'btn_PaintGradualColor' "Paint Gradual Color" pos:[24,312] width:112 height:24 enabled:false align:#left
		
		label 'lbl_SpecialColors' "Special Colors:" pos:[16,352] width:128 height:16 align:#left
		checkbutton 'ckb_SpecialColor1' "Special Color1" pos:[16,368] width:42 height:42 highlightColor:(color 0 254 0) align:#left
		checkbutton 'ckb_SpecialColor2' "Special Color2" pos:[59,368] width:42 height:42 highlightColor:(color 0 253 0) align:#left
		checkbutton 'ckb_SpecialColor3' "Special Color3" pos:[102,368] width:42 height:42 highlightColor:(color 0 250 0) align:#left
		checkbutton 'ckb_SpecialColor4' "Special Color4" pos:[16,411] width:42 height:42 highlightColor:(color 0 249 0) align:#left
		checkbutton 'ckb_SpecialColor5' "Special Color5" pos:[59,411] width:42 height:42 highlightColor:(color 0 0 0) align:#left
		checkbutton 'ckb_SpecialColor6' "Special Color6" pos:[102,411] width:42 height:42 highlightColor:(color 0 0 0) align:#left
		----------------------------
		on rol_paintVertexes open do
		(
			local bmp_icon = "VertexPaint_i.bmp"
			
			btn_paintAll.images = #(bmp_icon, bmp_icon, 23, 17, 17, 17, 17, true, true)
			ckb_paintState.images = #(bmp_icon, bmp_icon, 23, 19, 19, 19, 19, true, true)
			ckb_eraseState.images = #(bmp_icon, bmp_icon, 23, 18, 18, 18, 18, true, true)
			btn_eraseAll.images = #(bmp_icon, bmp_icon, 23, 20, 20, 20, 20, true, true)
			ckb_PickState.images = #(bmp_icon, bmp_icon, 23, 9, 9, 9, 9, true, true)
			btn_brushOptions.images = #(bmp_icon, bmp_icon, 23, 21, 21, 21, 21, true, true)
			bmp_icon = "EditMesh_24i.bmp"
			ckb_gradula.images = #(bmp_icon, bmp_icon, 10, 2, 7, 2, 7, true, true)
			
			spn_R.value = this.currentPaintColor.r
			spn_G.value = this.currentPaintColor.g
			spn_B.value = this.currentPaintColor.b
			
			if ( true == ckb_hold.state ) then
			(
				ckb_hold.text = "Fetch Colors"
				ckb_hold.toolTip = "LeftClick:Fetch vertex colors;\nRightClick:Clear holded vertex colors."
			)
			else
			(
				ckb_hold.text = "Hold Colors"
				ckb_hold.toolTip = "Hold current vertex colors."
			)
			--	��ǰ����
			node_current = $
			--	ȥ����������
			node_current.deleteIsoVerts()
			--	��ˢ��С
			thePainterInterface.maxSize = spn_BrushPaintSize.value
			thePainterInterface.pressureEnable = chk_EnableBrushPressure.checked
			
			fn_updateChannelState()
			fn_updateGradualControls()
			fn_updateSpecialColorControls()
		)
		on rol_paintVertexes close do
			()
		on cp_CurrentPaintColor changed col do
		(
			spn_R.value = this.currentPaintColor.r
			spn_G.value = this.currentPaintColor.g
			spn_B.value = this.currentPaintColor.b
		)
		on spn_R changed val do
			( this.currentPaintColor.r = spn_R.value )
		on spn_G changed val do
			( this.currentPaintColor.g = spn_G.value )
		on spn_B changed val do
			( this.currentPaintColor.b = spn_B.value )
		on btn_SelectSame pressed do
		(
			local bary_selectSame = #{}
			local int_mapChannel = undefined
			
			subobjectLevel = 1
			if ( true == this.alphaChannel ) do ( int_mapChannel = -2 )
			if ( true == this.illuminationChannel ) do ( int_mapChannel = -1 )
			if ( true == this.vertexColorChannel ) do ( int_mapChannel = 0 )
			bary_selectSame = polyop.getVertsByColor node_current this.currentPaintColor 0.1 0.1 0.1 channel:int_mapChannel
			if ( 0<node_current.modifiers.count ) then
			( setVertSelection node_current node_current.modifiers[#KG3D_FlexVertexColor] bary_selectSame )
			else
			( setVertSelection node_current bary_selectSame )
		)
		on ckb_redChannel changed state do
		(
			fn_updateChannelState()
		)
		on ckb_greenChannel changed state do
		(
			fn_updateChannelState()
		)
		on ckb_blueChannel changed state do
		(
			fn_updateChannelState()
		)
		on btn_paintAll pressed do with undo "KG3D_FlexVertexColor:paint all" on
		(
			local pt3_color = this.currentPaintColor as point3
			
			fn_fillVertexesColor pt3_color
		)
		on ckb_paintState changed state do
		(
			if ( true == state ) do
			(
				ckb_PickState.state = false
				ckb_eraseState.state = false
				if ( true == thePainterInterface.InPaintMode() ) do ( thePainterInterface.endPaintSession() )
			)
			fn_mousePainter()
		)
		on ckb_eraseState changed state do
		(
			if ( true == state ) do
			(
				ckb_PickState.state = false
				ckb_paintState.state = false
				if ( true == thePainterInterface.InPaintMode() ) do ( thePainterInterface.endPaintSession() )
			)
			fn_mousePainter()
		)
		on btn_eraseAll pressed do with undo "KG3D_FlexVertexColor:erase all" on
		(
			fn_fillVertexesColor [255,255,255]
		)
		on ckb_PickState changed state do
		(
			if ( undefined == int_vertexMapChannel ) then
			(
				ckb_PickState.state = false
			)
			else
			(
				if ( true == state ) do
				(
					local current_mesh = snapshot $
					
					fn fn_pickVertexColor callback_fn i_ray i_node faceNum shift ctrl alt current_mesh =
					(
						if ( #mousePoint == callback_fn ) do
						(
						--	format " i_ray=%\n i_node=%\n faceNum=%\n shift=%\n ctrl=%\n alt=%\n user_define=%\n" i_ray i_node faceNum shift ctrl alt user_define
							if ( undefined != faceNum ) do
							(
								local color_v
								local int_v = 0
								local flt_short = 65535
								local pt3_cross = i_ray.pos
								local bary_verts = meshop.getVertsUsingFace current_mesh faceNum
								
								for v in bary_verts do
								(
									local flt_length = length ( current_mesh.verts[v].pos-pt3_cross )
									
									if ( flt_short>flt_length ) do
									(
										flt_short = flt_length
										int_v = v
									)
								)
								color_v = ( meshop.getMapVert current_mesh int_vertexMapChannel int_v )*255
								--	��������
								if ( 0.5>( color_v.x-( color_v.x as integer ) ) ) then ( color_v.x = floor color_v.x )
								else ( color_v.x = ceil color_v.x )
								if ( 0.5>( color_v.y-( color_v.y as integer ) ) ) then ( color_v.y = floor color_v.y )
								else ( color_v.y = ceil color_v.y )
								if ( 0.5>( color_v.z-( color_v.z as integer ) ) ) then ( color_v.z = floor color_v.z )
								else ( color_v.z = ceil color_v.z )
								
								cp_CurrentPaintColor.color = color color_v.x color_v.y color_v.z
							)
						)
						if ( #mouseAbort == callback_fn ) do
						(
							delete current_mesh
							ckb_PickState.state = false
							return()
						)
						#continue
					)
					
					current_mesh.isHidden = true
					mouseTrack on:current_mesh snap:#3D trackCallback:#(fn_pickVertexColor,current_mesh)
					if ( true == isValidNode current_mesh ) do ( delete current_mesh )
				)
			)
		)
		
		on ckb_hold changed state do
		(
			local int_allCount = ary_baseObjectAlphas.count+ary_baseObjectIlluminations.count+ary_baseObjectVertexColors.count
			
			if ( true == state ) then
			(
				start = timeStamp()
				setWaitCursor()
				this.mapAlpha = fn_getPolyVertexColor node_current -2
				this.mapIllumination = fn_getPolyVertexColor node_current -1
				this.mapVertexColor = fn_getPolyVertexColor node_current 0
				if ( 0<this.mapAlpha.count+this.mapIllumination.count+this.mapVertexColor.count ) then
				(
					ckb_hold.state = true
					ckb_hold.text = "Fetch Color"
					ckb_hold.toolTip = "LeftClick:Fetch vertex colors;\nRightClick:Clear holded vertex colors."
				)
				else
				(
					ckb_hold.state = false
					ckb_hold.text = "Hold Color"
					ckb_hold.toolTip = "Hold current vertex colors."
				)
				setArrowCursor()
				end = timeStamp()
				if ( 11 == i_debug ) do ( format "KG3D_FlexVertexColor:>Holding original vertexColors took % seconds.\n" ( ( end-start )/1000.0 ) )
			)
			else
			(
				if ( 0<this.mapAlpha.count+this.mapIllumination.count+this.mapVertexColor.count ) do
				(
					if (true == queryBox "Fetch original vertex colors?" title:"KG3D_FlexVertexColor:") do
					(
						local bol_state = node_current.showVertexColors
						
						for int_v = 1 to this.mapAlpha.count do ( polyop.setVertColor node_current -2 int_v this.mapAlpha[int_v] )
						for int_v = 1 to this.mapIllumination.count do ( polyop.setVertColor node_current -1 int_v this.mapIllumination[int_v] )
						for int_v = 1 to this.mapVertexColor.count do ( polyop.setVertColor node_current 0 int_v this.mapVertexColor[int_v] )
						
						update node_current
						node_current.showVertexColors = false
						node_current.showVertexColors = bol_state
					)
				)
				ckb_hold.state = true
			)
		)
		on ckb_hold rightClick do
		(
			ckb_hold.state = false
			ckb_hold.text = "Hold Color"
			ckb_hold.toolTip = "Hold current vertex colors."
		)
		on btn_remapping pressed do
		(
			fn_rematchMapVertex node_current int_vertexMapChannel
		)
		on btn_brushOptions pressed do
			( thePainterInterface.paintOptions() )
		on spn_BrushPaintSize changed val do
			( thePainterInterface.maxSize = val )
		on chk_EnableBrushPressure changed state do
			( thePainterInterface.pressureEnable = state )
		on btn_ring pressed do
		(
			local bary_selEdges
			
			if ( undefined == node_current.modifiers[#KG3D_FlexVertexColor] ) then
			( bary_selEdges = getEdgeSelection node_current )
			else
			( bary_selEdges = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor] )
			--	select edges on base object.
			node_current.EditablePoly.SetSelection #Edge bary_selEdges
			node_current.buttonOp #SelectEdgeRing
			bary_selEdges = node_current.EditablePoly.GetSelection #Edge
			--	������ɫ���֡�
			if ( false == this.gradualWhite ) do
			(
				for int_e in bary_selEdges do
				(
					local bary_verts = polyop.getVertsUsingEdge node_current int_e
					
					node_current.EditablePoly.SetSelection #Vertex bary_verts
					bary_selEdges[int_e] = ( white != ( node_current.EditablePoly.GetVertexColor int_vertexMapChannel ) )
				)
			)
			node_current.EditablePoly.SetSelection #Edge bary_selEdges
			
			if ( undefined == node_current.modifiers[#KG3D_FlexVertexColor] ) then
			(
				SetEdgeSelection node_current bary_selEdges
			)
			else
			(
				SetEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor] bary_selEdges
			)
			--	����
			ary_selGradualEdges = fn_sortRingEdges node_current bary_selEdges			--	���顣
			for n = 1 to ary_selGradualEdges.count do
			(
				ary_selGradualEdges[n] = for i_edge in ary_selGradualEdges[n] collect ( #(i_edge) )
			)
			fn_updateGradualControls()
			update node_current
		)
		on ckb_gradula changed state do
		(
			if ( true == state ) then
			(
				subobjectLevel = 2
				this.rol_paintMode.ckb_Wireframe.state = true
				viewport.SetShowEdgeFaces state
			)
			else ( subobjectLevel = 0 )
			fn_updateGradualControls()
			update node_current
		)
		on btn_loop pressed do
		(
			local bary_selEdges
			
			if ( undefined == node_current.modifiers[#KG3D_FlexVertexColor] ) then
			( bary_selEdges = getEdgeSelection node_current )
			else
			( bary_selEdges = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor] )
			
			--	ary_selGradualEdges����
			ary_selGradualEdges = fn_sortRingEdges node_current bary_selEdges
			
			for n = 1 to ary_selGradualEdges.count do
			(
				--	�ռ�Element��Ե��
				local int_edge = 0
				local bary_borderEdges = #{}
				local bary_elementEdges = #{}
				
				if ( array == classOf ary_selGradualEdges[n][1] ) then
				(
					bary_elementEdges = #{ary_selGradualEdges[n][1][1]}
				)
				else
				(
					bary_elementEdges = #{ary_selGradualEdges[n][1]}
				)
				
				while ( int_edge != bary_elementEdges.numberSet ) do
				(
					local bary_faces = polyop.getFacesUsingEdge node_current bary_elementEdges
					
					int_edge = bary_elementEdges.numberSet
					bary_elementEdges = polyop.getEdgesUsingFace node_current bary_faces
				)
				
				for n in bary_elementEdges do
				(
					local bary_faces = polyop.getFacesUsingEdge node_current #{n}
					
					if ( 1 == bary_faces.numberSet ) do
					(
						append bary_borderEdges n
					)
				)
				
				for m = 1 to ary_selGradualEdges[n].count do
				(
					local bary_hiddens = #{}
					local int_loopEdge = 0
					
					if ( array == classOf ary_selGradualEdges[n][m] ) then
					(
						int_loopEdge = ary_selGradualEdges[n][m][1]
					)
					else
					(
						int_loopEdge = ary_selGradualEdges[n][m]
					)
					ary_selGradualEdges[n][m] = fn_getLoopEdges node_current int_loopEdge bary_borderEdges
					
					--	������ɫ���֡�
					if ( false == this.gradualWhite ) do
					(
						for int_e = 1 to ary_selGradualEdges[n][m].count do
						(
							local bary_verts = polyop.getVertsUsingEdge node_current ary_selGradualEdges[n][m][int_e]
							
							node_current.EditablePoly.SetSelection #Vertex bary_verts
							if ( white == ( node_current.EditablePoly.GetVertexColor int_vertexMapChannel ) ) do
							(
								ary_selGradualEdges[n][m][int_e] = 0
							)
						)
						ary_selGradualEdges[n][m] = for int_e in ary_selGradualEdges[n][m] where ( 0<int_e ) collect int_e
					)
					
					--	�������صĲ��֡�
					node_current.EditablePoly.SetSelection #Edge ( ary_selGradualEdges[n][m] as bitArray )
					bary_selEdges = node_current.EditablePoly.GetSelection #Edge
					
					if ( undefined == node_current.modifiers[#KG3D_FlexVertexColor] ) then
					( setEdgeSelection node_current bary_selEdges keep:true )
					else
					( setEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor] bary_selEdges keep:true )
				)
			)
			fn_updateGradualControls()
			update node_current
		)
		on cp_GradualStart changed col do
			( fn_updateGradualControls() )
		on cp_GradualEnd changed col do
			( fn_updateGradualControls() )
		on btn_PaintGradualColor pressed do
		(
			local color_step = 1
			local int_mapChannel = undefined
			local bary_selEdges
			
			if ( undefined == node_current.modifiers[#KG3D_FlexVertexColor] ) then
			( bary_selEdges = getEdgeSelection node_current )
			else
			( bary_selEdges = getEdgeSelection node_current node_current.modifiers[#KG3D_FlexVertexColor] )
			
			if ( true == this.alphaChannel ) do ( int_mapChannel = -2 )
			if ( true == this.illuminationChannel ) do ( int_mapChannel = -1 )
			if ( true == this.vertexColorChannel ) do ( int_mapChannel = 0 )
			if ( undefined != int_mapChannel ) do
			(
				--	���δѡ���Edge��
				for n = 1 to ary_selGradualEdges.count do
				(
					for i_row = 1 to ary_selGradualEdges[n].count do
					(
						local bary_row = ary_selGradualEdges[n][i_row] as bitArray
						
						bary_row = bary_row-(bary_row-bary_selEdges)
						ary_selGradualEdges[n][i_row] = bary_row as array
					)
				)
				
				for n = 1 to ary_selGradualEdges.count do
				(
					local ary_subGradualEdges = ary_selGradualEdges[n]
					local color_step = ( this.gradualStart-this.gradualEnd )/( ary_subGradualEdges.count-1 )
					
					for x_row = 1 to ary_subGradualEdges.count do
					(
						local bary_verts = polyop.getVertsUsingEdge node_current ary_subGradualEdges[x_row]
						local pt3_color = ( ( ( this.gradualStart-color_step*( x_row-1 ) ) as point3 )*pt3_paintRGBChannel ) as color
						
						polyop.setVertColor node_current int_mapChannel bary_verts pt3_color
					)
				)
				update node_current
			)
		)
		on ckb_SpecialColor1 changed state do
			( fn_setSpecialColors ckb_SpecialColor1 true )
		on ckb_SpecialColor1 rightClick do
			( fn_setSpecialColors ckb_SpecialColor1 false )
		on ckb_SpecialColor2 changed state do
			( fn_setSpecialColors ckb_SpecialColor2 true )
		on ckb_SpecialColor2 rightClick do
			( fn_setSpecialColors ckb_SpecialColor2 false )
		on ckb_SpecialColor3 changed state do
			( fn_setSpecialColors ckb_SpecialColor3 true )
		on ckb_SpecialColor3 rightClick do
			( fn_setSpecialColors ckb_SpecialColor3 false )
		on ckb_SpecialColor4 changed state do
			( fn_setSpecialColors ckb_SpecialColor4 true )
		on ckb_SpecialColor4 rightClick do
			( fn_setSpecialColors ckb_SpecialColor4 false )
		on ckb_SpecialColor5 changed state do
			( fn_setSpecialColors ckb_SpecialColor5 true )
		on ckb_SpecialColor5 rightClick do
			( fn_setSpecialColors ckb_SpecialColor5 false )
		on ckb_SpecialColor6 changed state do
			( fn_setSpecialColors ckb_SpecialColor6 true )
		on ckb_SpecialColor6 rightClick do
			( fn_setSpecialColors ckb_SpecialColor6 false )
	)
	
	parameters par_about rollout:rol_about
	(
		versionDate type:#string default:"" ui:hpl_version
	)
	rollout rol_about "About..." rolledUp:false
	(
		button 'btn_expFile' "Export .mesh to:>" pos:[16,8] width:104 height:24 align:#left
		button 'btn_expPath' "..." pos:[120,8] width:24 height:24 align:#left
		editText 'edt_expPath' "" pos:[12,32] width:132 height:19 align:#left
		checkbutton 'ckb_collapseToBaseobject' "Collapse To Baseobject" pos:[16,60] width:128 height:24 highlightColor:(color 0 0 0) checked:true align:#left
		HyperLink 'hpl_year' "\xa9 2019" pos:[16,92] width:128 height:16 enabled:false color:(color 0 0 0) align:#left
		HyperLink 'hpl_company' "Seasun Entertainment" pos:[16,108] width:128 height:16 color:(color 255 0 0) address:"http://www.xishanju.com/" align:#left
		HyperLink 'hpl_version' "Version:��" pos:[16,124] width:128 height:16 enabled:false color:(color 0 0 0) align:#left
		HyperLink 'hpl_by' "By" pos:[16,140] width:16 height:16 enabled:false color:(color 0 0 0) align:#left
		HyperLink 'hpl_writer' "Oujian" pos:[32,140] width:32 height:16 color:(color 0 0 0) address:"mailto:oujian@kingsoft.com" align:#left
		---------------------
		on rol_about open do
		(
			local str_version = this.version as string
			
			if ( 0<maxFileName.count ) do ( edt_expPath.text = maxFilePath )
			hpl_version.text  = "Version:"+str_version[1]+str_version[2]+str_version[3]+str_version[4]+"."+str_version[5]+str_version[6]+"."+str_version[7]+str_version[8]
		)
		on rol_about close do
		(
		--	format "KG3D_FlexVertexColor:>Closed rol_about.\n"
		)
		on btn_expFile pressed do
		(
			local str_path
			local str_temp = ( getDir #temp )+"\\"
			
			if ( 0<edt_expPath.text.count ) then
			(
				str_path = edt_expPath.text+"\\" 
			)
			else
			(
				if ( 0<maxFilePath.count ) then
				(
					str_path = maxFilePath
				)
				else
				(
					str_path = getSaveFileName caption:"Save scene File..." types:"3ds Max(*.max)|*.max"
				)
			)
			if ( undefined != str_path ) do
			(
				local str_temp = ( getDir #temp )+"\\KG3D_FlexVertexColor"
				local str_KG3DPluginSettingFileName = ( getDir #maxData )+"KSMaxExporter.ini"
				
				setIniForceUTF16Default false
				setINISetting str_KG3DPluginSettingFileName "ExportType" "Type" "0"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "Mesh" "0"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "Material" "0"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "Animation" "1"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "UnitTo1Model" "1"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "ExchangeYZAxis" "1"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "Inch2CM" "1"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "InMaxDir" "0"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "JsonInspack" "0"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "HD" "1"
				setINISetting str_KG3DPluginSettingFileName "OutputOption" "AniWithHD" "1"
				setINISetting str_KG3DPluginSettingFileName "Animation" "Type" "13"
				setINISetting str_KG3DPluginSettingFileName "MeshOption" "VerticesDiffuse" "1"
				setINISetting str_KG3DPluginSettingFileName "MeshOption" "VerticesEmissive" "1"
				setINISetting str_KG3DPluginSettingFileName "MeshOption" "VerticesUVWChannel1" "1"
				setINISetting str_KG3DPluginSettingFileName "MeshOption" "VerticesUVWChannel2" "1"
				setINISetting str_KG3DPluginSettingFileName "MeshOption" "VerticesUVWChannel3" "1"
				setINISetting str_KG3DPluginSettingFileName "MeshOption" "Allow4WeightPerVertex" "1"
				setIniForceUTF16Default true
				
				makeDir str_temp
				if ( true == exportFile ( str_temp+"\\"+$.name+"_HD.mesh" ) #noPrompt selectedOnly:true ) do
				(
					deleteFile ( str_path+$.name+"_HD.mesh" )
					copyFile ( str_temp+"\\"+$.name+"_HD.mesh" ) ( str_path+$.name+"_HD.mesh" )
					HiddenDOSCommand ( "del /S /Q "+str_temp )
				)
			)
		)
		on btn_expPath pressed do
		(
			local str_path = getSavePath caption:"Export Path" initialDir:maxFilePath
			
			if (undefined != str_path) do ( edt_expPath.text = str_path )
		)
		on ckb_collapseToBaseobject changed state do with undo "Collopse vertex color" on
		(
			if ( GeometryClass != superClassof ( modPanel.getCurrentObject() ) ) do
			(
				local bol_execute = queryBox "Collopse this modifier and paint vertex colors to the baseobject?" title:"KG3D_FlexVertexColor Warning:"
				
				ckb_collapseToBaseobject.state = true
				if ( true == bol_execute ) do
				(
					local i_modifier = modPanel.getCurrentObject()
					local int_index = modPanel.getModifierIndex node_current i_modifier
					
					if ( node_current.modifiers.count != int_index ) do
					(
						deleteModifier node_current int_index
						addmodifier node_current i_modifier before:node_current.modifiers.count
					)
				--	maxOps.CollapseNodeTo node_current node_current.modifiers.count on
				)
			)
		)
	)
	
	------------	attrib actions	----------
	on create do 
	(
		fn_rematchMapVertex $  0
		fn_rematchMapVertex $ -1
		fn_rematchMapVertex $ -2
		format "KG3D_FlexVertexColor:>create\n"
	)
	on postCreate do 
	(
		start = timeStamp()
		if ( 0 == ary_baseObjectAlphas.count ) do ( ary_baseObjectAlphas = fn_getPolyVertexColor node_current -2 )
		if ( 0 == ary_baseObjectIlluminations.count ) do ( ary_baseObjectIlluminations = fn_getPolyVertexColor node_current -1 )
		if ( 0 == ary_baseObjectVertexColors.count ) do ( ary_baseObjectVertexColors = fn_getPolyVertexColor node_current 0 )
		end = timeStamp()
		if ( 11 == i_debug ) do ( format "KG3D_FlexVertexColor:>postCreate:>Processing original vertexColors took % seconds.\n" ( ( end-start )/1000.0 ) )
	)
	on postLoad do
	(
		format "KG3D_FlexVertexColor:>postLoaded\n"
	)
	on update do
	(
		format "KG3D_FlexVertexColor:>updated\n"
	)
	on attachedToNode nodeObj do 
	(
		format "KG3D_FlexVertexColor:>attachedToNode:>%\n" nodeObj
	)
	on detachedFromNode nodeObj do
	(
		format "KG3D_FlexVertexColor:>detachedFromNode:>%\n" nodeObj
	)
	on deleted do
	(
		format "KG3D_FlexVertexColor:>deleted\n"
	)
	on clone original do
	(
		format "KG3D_FlexVertexColor:>clone:>%\n" original
	)
)


----------------------------------------------------------------------------------------------------
--������������������� Flex Skin Tool �����������������������--
----------------------------------------------------------------------------------------------------

clearlistener()
try(destroyDialog rol_flexSkinTool)
catch()

--	����ѧ���Ϲ���Flex Skin Tool��ע��汾���붥��ɫ����Attribute_FlexVertexColor�Ŀ��ܻ᲻ͬ��
rollout rol_flexSkinTool "Flex Skin Tool" width:256 height:560
(
	local rol = rol_flexSkinTool
	
	local aryMaxDistance = #()
	local aryBackStopOffset = #()
	local aryBackStopRadius = #()
	local aryLatchnearest = #()
	local aryLatchGroup = #()
	local ary_mergeSkinWeight = #()
	local ary_vertColorInfo = #()
	local ary_vertDQWeight = #()
	local stuc_skinWeight,copyedColorInfo
	
	struct vertsInfo (vertPos,vertColor,colorList,sameColor,vertIllumination,illuminationList,sameIllumination,vertAlpha,alphaList,sameAlpha)
	struct skinInfo ( selVerts,vertsPos,bonesName,bonesBindTM,vertBones,vertWeights,DQWeight )
	
	fn fn_setCopyrightInfo rol str_version =
	(
		local int_posY = rol.height-21
		
		--	HyperLink 'Hyp_copyright' "C"
		rol.Hyp_copyright.pos = [8,int_posY]
		rol.Hyp_copyright.enabled = false
		rol.Hyp_copyright.color = black
		--	HyperLink 'Hyp_copyrightYear' "1998"
		rol.Hyp_copyrightYear.pos = [21,int_posY]
		rol.Hyp_copyrightYear.enabled = false
		rol.Hyp_copyrightYear.color = black
		--	HyperLink 'Hyp_copyrightOwner' "SeasunGame"
		rol.Hyp_copyrightOwner.pos = [48,int_posY]
		rol.Hyp_copyrightOwner.color = rol.Hyp_copyrightOwner.visitedcolor = red
		rol.Hyp_copyrightOwner.address = "http://www.xishanju.com/"
		--	"HyperLink 'Hyp_textVer' "Ver:"
		rol.Hyp_textVer.pos = [(rol.width-140),int_posY]
		rol.Hyp_textVer.enabled = false
		rol.Hyp_textVer.color = black
		--	HyperLink 'Hyp_version' "2008.01.08.a"
		rol.Hyp_version.text = str_version
		rol.Hyp_version.pos = [(rol.width-120),int_posY]
		rol.Hyp_version.enabled = false
		rol.Hyp_version.color = black
		--	HyperLink 'Hyp_textBy' "by"
		rol.Hyp_textBy.pos = [(rol.width-60),int_posY]
		rol.Hyp_textBy.enabled = false
		rol.Hyp_textBy.color = gray
		--	HyperLink 'Hyp_editor' "Oj Jian"
		rol.Hyp_editor.pos = [(rol.width-45),int_posY]
		rol.Hyp_editor.color = rol.Hyp_editor.visitedcolor = color 32 128 255
		rol.Hyp_editor.address = "mailto:oujian@kingsoft.com"
		/*��Ȩ���汾 ��Ϣ��������rollout�ؼ��ĵ����
		--	fn_setCopyrightInfo rol "2024.03.22"
		HyperLink 'Hyp_copyright' "\xa9"
		HyperLink 'Hyp_copyrightYear' "2019"
		HyperLink 'Hyp_copyrightOwner' "SeasunGame"
		HyperLink 'Hyp_textVer' "Ver:"
		HyperLink 'Hyp_version' "2000.00.00"
		HyperLink 'Hyp_textBy' "by"
		HyperLink 'Hyp_editor' "Ou Jian"
		*/
	)
	
	--	���PhyX Clothing Constraint���Զ�����ײ�塣
	fn fn_expConstraint =
	(
		local txt = ""
		local iPoint = point name:"capsuleTemp"
		local aryCons = for obj in objects where (findString obj.name "Constraint" != undefined) collect obj
		
		txt += "[simulations]"+"\n"
		txt += "count="+aryCons.count as string+"\n"
		txt += "unit=inch"+"\n"
		txt += "inCoordSys="+(biped.getNode aryCons[1].parent #pelvis).parent.name+"\n"
		txt += "\n"
		
		for n = 1 to aryCons.count do
		(
			local i = aryCons[n]
			local iPos = [0,0,0]
			
			txt += "[constraint"+n as string+"]"+"\n"
			
			case (classOf i) of
			(
				Capsule:
				(
					txt += "type=capsule"+"\n"
					txt += "parent="+i.parent.name+"\n"
					
					in coordSys i (iPoint.pos = [0,0,i.radius])
					iPos = in coordSys i.parent iPoint.pos
					iPos.x = ((iPos.x*1000) as integer)/1000.0
					iPos.y = ((iPos.y*1000) as integer)/1000.0
					iPos.z = ((iPos.z*1000) as integer)/1000.0
					txt += "pos1="+iPos.x as string+","+iPos.y as string+","+iPos.z as string+"\n"
					
					if (i.heighttype == 0) then
					(
						in coordSys i (iPoint.pos = [0,0,(i.height-i.radius)])
					)
					else
					(
						in coordSys i (iPoint.pos = [0,0,(i.height+i.radius)])
					)
					iPos = in coordSys i.parent iPoint.pos
					iPos.x = ((iPos.x*1000) as integer)/1000.0
					iPos.y = ((iPos.y*1000) as integer)/1000.0
					iPos.z = ((iPos.z*1000) as integer)/1000.0
					txt += "pos2="+iPos.x as string+","+iPos.y as string+","+iPos.z as string+"\n"
					
					txt += "radius="+i.radius as string+"\n"
				)
				Box:
				(
					txt += "type=box"+"\n"
					txt += "parent="+i.parent.name+"\n"
					
					iPoint.transform = i.transform
					iPoint.pos = i.center
					iPos = in coordSys i.parent iPoint.pos
					iPos.x = ((iPos.x*1000) as integer)/1000.0
					iPos.y = ((iPos.y*1000) as integer)/1000.0
					iPos.z = ((iPos.z*1000) as integer)/1000.0
					txt += "center="+iPos.x as string+","+iPos.y as string+","+iPos.z as string+"\n"
					
					iPos = in coordSys i.parent iPoint.dir
					iPos.x = ((iPos.x*1000) as integer)/1000.0
					iPos.y = ((iPos.y*1000) as integer)/1000.0
					iPos.z = ((iPos.z*1000) as integer)/1000.0
					txt += "dir="+iPos.x as string+","+iPos.y as string+","+iPos.z as string+"\n"
					
					txt += "length="+i.length as string+"\n"
					txt += "width="+i.width as string+"\n"
					txt += "height="+i.height as string+"\n"
				)
				default:()
			)
			
			txt += "\n"
		)
		delete iPoint
		
		return txt
	)
	
	--	ȥ��Skin����Ȩ�صĹ�����
	fn fn_removeZeroWeightBone obj =
	(
		local iSkin,ary_iBoneID
		
		iSkin = obj.modifiers[#Skin]
		modPanel.setCurrentObject iSkin
		skinOps.RemoveZeroWeights iSkin
		
		ary_iBoneID = for n in 1 to (skinOps.GetNumberBones iSkin) collect (skinOps.GetBoneIDByListID iSkin n)
		for v = 1 to (skinOps.GetNumberVertices iSkin) where (ary_iBoneID.count > 0) do
		(
			for n = 1 to (skinOps.GetVertexWeightCount iSkin v) do
			(
				local i = findItem ary_iBoneID (skinOps.GetVertexWeightBoneID iSkin v n)
				
				if (i != 0) do 
				(
					deleteItem ary_iBoneID i
					exit
				)
			)
		)
		sort ary_iBoneID
		
		for n = ary_iBoneID.count to 1 by -1 do
		(
			modPanel.setCurrentObject iSkin
			skinOps.removeBone iSkin ary_iBoneID[n]
		)
		
		skinOps.RemoveZeroWeights iSkin
	)
	
	--	���Skin��
	fn fn_splitSkinObj obj =
	(
		local objNew,iSkin,iFaces,iSkin
		local arySelection = selection as array
		
		--	�Ƚ�ռ�ڴ�,����԰�ȫ��
		objNew = copy obj
		
		select obj
		polyop.deleteFaces $.baseObject ( polyop.getFaceSelection $.baseObject )
		skinOps.RemoveZeroWeights $.modifiers[#Skin]
		
		select objNew
		polyop.deleteFaces $.baseObject ( #{1..$.faces.count}-( polyop.getFaceSelection $.baseObject ) )
		skinOps.RemoveZeroWeights $.modifiers[#Skin]
		
		return (#(obj,objNew))
	)
	
	--	�ϲ�Skin��
	fn fn_mergeSkin aryObj weldThreshold =
	(
		local newSkinObj = aryObj[1]
		local arySkinBoneList = #()
		local aryVertWeightBone = #()
		local aryVertWeight = #()
		
		sliderTime = animationRange.start
		--	�ռ�������
		for n = 1 to aryObj.count do
		(
			local obj = aryObj[n]
			
			max modify mode
			modPanel.setCurrentObject obj.modifiers[#Skin]
			--	����Ȩ�ء�
			modPanel.setCurrentObject obj.modifiers[#Skin]
			obj.modifiers[#Skin].weightAllVertices = true
			skinOps.RemoveZeroWeights obj.modifiers[#Skin]
			--	��ȡ�����б���
			for i = 1 to (skinOps.GetNumberBones obj.modifiers[#Skin]) do
			(
				local iName = skinOps.GetBoneName obj.modifiers[#Skin] i 1
				
				if (findItem arySkinBoneList iName == 0) do
				(
					append arySkinBoneList iName
				)
			)
		)
		sort arySkinBoneList
		
		--	�ռ�Ȩ�ء�
		for n = 1 to aryObj.count do
		(
			local obj = aryObj[n]
			
			--	����ϲ��modifier��skin������modifier���㣬���򶥵�������ֲ��졣
			while (obj.modifiers[1] != undefined and classof obj.modifiers[1] != skin) do
			(
				deleteModifier obj 1
			)
			
			modPanel.setCurrentObject obj.modifiers[1]
			for v = 1 to (skinOps.GetNumberVertices obj.modifiers[#Skin]) do
			(
				local aryBoneID = for y in 1 to arySkinBoneList.count collect y
				local aryWeight = for y in 1 to arySkinBoneList.count collect 0.0
				
				for x = 1 to (skinOps.GetVertexWeightCount obj.modifiers[#skin] v) do
				(
					local iBoneID = skinOps.GetVertexWeightBoneID obj.modifiers[#Skin] v x
					local iName = skinOps.GetBoneName obj.modifiers[#Skin] iBoneID 1
					local new = findItem arySkinBoneList iName
					
					aryWeight[new] = skinOps.GetVertexWeight obj.modifiers[#Skin] v x
				)
				
				append aryVertWeightBone aryBoneID
				append aryVertWeight aryWeight
			)
			
			convertTo obj Editable_Poly
		)
		
		--	�ϲ����塣
		for n = 2 to aryObj.count do
		(
			newSkinObj.EditablePoly.attach aryObj[n] newSkinObj
		)
		--	���Ӷ���
		if (0 < weldThreshold) do
		(
			newSkinObj.EditablePoly.SetSelection #Vertex #{1..newSkinObj.verts.count}
			newSkinObj.weldThreshold = weldThreshold
			polyop.weldVertsByThreshold newSkinObj #{1..newSkinObj.verts.count}
		)
		
		--	����Skin������Ȩ�ء�
		addmodifier newSkinObj (skin() )
		modPanel.setCurrentObject newSkinObj.modifiers[#Skin]
		for n = 1 to arySkinBoneList.count do
		(
			local iBone = getNodeByName arySkinBoneList[n]
			
			if (undefined == iBone) then
			(messagebox "miss Bone:" title:rol.title)
			else
			(skinOps.addbone newSkinObj.modifiers[#Skin] iBone 1)
		)
		
		clearSelection()
		modPanel.setCurrentObject newSkinObj.modifiers[#Skin]
		for n = 1 to newSkinObj.verts.count do
		(
			skinOps.ReplaceVertexWeights newSkinObj.modifiers[#Skin] n aryVertWeightBone[n] aryVertWeight[n]
		)
		newSkinObj.modifiers[#Skin].bone_Limit = 4
		skinOps.RemoveZeroWeights newSkinObj.modifiers[#Skin]
		
		return (#(aryVertWeightBone,aryVertWeight))
	)
	
	--	����Ȩ�ء�struct skinInfo ( selVerts,vertsPos,bonesName,bonesBindTM,vertBones,vertWeights,DQWeight )
	fn fn_copySkinWeight obj = 
	(
		local modifier_skin = obj.modifiers[#skin]
		local struct_info = skinInfo selVerts:#{} vertsPos:#() bonesName:#() bonesBindTM:#() vertBones:#() vertWeights:#() DQWeight:#()
		
		select obj
		max modify mode
		modPanel.setCurrentObject obj.modifiers[#Skin]
		skinOps.closeWeightTool obj.modifiers[#skin]
		subobjectLevel = 0
		skinOps.RemoveZeroWeights obj.modifiers[#Skin]
		obj.modifiers[#Skin].weightAllVertices = true
		for n = 1 to ( skinOps.GetNumberBones modifier_skin ) do
		(
			struct_info.bonesName[n] = skinOps.GetBoneName modifier_skin n 0
			struct_info.bonesBindTM[n] = skinUtils.GetBoneBindTM obj ( getNodeByName struct_info.bonesName[n] )
		)
		
		for v = 1 to obj.verts.count where ( 0<struct_info.bonesName.count ) do
		(
			local aryBoneID = for i in 1 to struct_info.bonesName.count collect i
			local aryWeight = for i in 1 to struct_info.bonesName.count collect 0.0
			
			struct_info.vertsPos[v] = in coordSys local obj.verts[v].pos
			struct_info.selVerts[v] = ( 1 == skinOps.IsVertexSelected modifier_skin v )
			
			for x = 1 to (skinOps.GetVertexWeightCount modifier_skin v) do
			(
				local iBoneID = skinOps.GetVertexWeightBoneID modifier_skin v x
				local iName = skinOps.GetBoneName modifier_skin iBoneID 1
				local new = findItem struct_info.bonesName iName
				
				aryWeight[new] = skinOps.GetVertexWeight modifier_skin v x
			)
			
			append struct_info.vertBones aryBoneID
			append struct_info.vertWeights aryWeight
			append struct_info.DQWeight ( skinOps.getVertexDQWeight modifier_skin v )
		)
		
		return struct_info
	)
	
	--	ճ��Ȩ�ء�
	fn fn_pasteSkinWeight obj struct_info bol_selOnly =
	(
		local modifier_skin = obj.modifiers[#skin]
		local aryCurrentBones = for n in 1 to (skinOps.GetNumberBones modifier_skin) collect (skinOps.GetBoneName modifier_skin n 1)
		
		select obj
		max modify mode
		modPanel.setCurrentObject obj.modifiers[#Skin]
		skinOps.closeWeightTool obj.modifiers[#skin]
		for n = 1 to struct_info.bonesName.count do
		(
			if (0 == findItem aryCurrentBones struct_info.bonesName[n]) do
			(
				local i_boneByName = getNodeByName struct_info.bonesName[n] 
				
				if (undefined == i_boneByName) then
				(
					format ("Warning:> Missing Bone "+struct_info.bonesName[n]+"\n")
				)
				else
				(
					skinOps.addbone modifier_skin i_boneByName 0
					skinUtils.SetBoneBindTM obj i_boneByName struct_info.bonesBindTM[n]
				)
			)
		)
		skinOps.RemoveZeroWeights modifier_skin
		modifier_skin.weightAllVertices = true
		modifier_skin.bone_Limit = 4
		for v = 1 to obj.verts.count do
		(
			if ( bol_selOnly and 0 == skinOps.IsVertexSelected modifier_skin v ) do continue
			if ( undefined == struct_info.vertBones[v] ) then
			(
				format "%:>struct_info.vertBones[%] = undefined?\n" obj.name v
			)
			else
			(
				try
				(
					skinOps.ReplaceVertexWeights modifier_skin v struct_info.vertBones[v] struct_info.vertWeights[v] node:obj
					skinOps.setVertexDQWeight modifier_skin v struct_info.DQWeight[v]
				)
				catch()
			)
		)
		skinOps.RemoveZeroWeights modifier_skin
	)
	
	--	���Ȩ�ء�struct skinInfo ( selVerts,vertsPos,bonesName,bonesBindTM,vertBones,vertWeights,DQWeight )
	fn fn_deformSkinWeight obj skinStuc bol_selOnly bol_DQOnly =
	(
		local iSkinModf = obj.modifiers[#skin]
		local aryCurrentBones = for n in 1 to ( skinOps.GetNumberBones iSkinModf ) collect ( skinOps.GetBoneName iSkinModf n 1 )
		
		select obj
		max modify mode
		modPanel.setCurrentObject obj.modifiers[#Skin]
		
		for n = 1 to skinStuc.bonesName.count do
		(
			if ( 0 == findItem aryCurrentBones skinStuc.bonesName[n] ) do
			(
				local bone_add = getNodeByName skinStuc.bonesName[n]
				
				if ( undefined != bone_add ) do ( skinOps.addbone iSkinModf bone_add 0 )
			)
		)
		iSkinModf.bone_Limit = 4
		skinOps.RemoveZeroWeights iSkinModf
		iSkinModf.weightAllVertices = true
		
		for v = 1 to obj.verts.count do
		(
			local deformN = 0
			local vPos = in coordSys local (obj.verts[v].pos)
			local min = 65535.0
			
			if ( bol_selOnly and 0 == skinOps.IsVertexSelected iSkinModf v ) do continue
			
			--	��skinStuc�м�¼�Ķ�����Ѱ����obj.verts[n]�����һ�������Ȩ�أ�������������һ���࣬λ��Ҳ����ƥ�䡣
			for m = 1 to skinStuc.vertsPos.count where ( undefined != vPos ) do
			(
				local dist = distance vPos skinStuc.vertsPos[m]
				
				if ( min > dist ) do
				(
					min = dist
					deformN = m
				)
			)
			
			if ( false == bol_DQOnly ) do ( skinOps.ReplaceVertexWeights iSkinModf v skinStuc.aryVertBone[deformN] skinStuc.aryVertWeight[deformN] )
			skinOps.setVertexDQWeight iSkinModf v skinStuc.DQWeight[deformN]
		)
		skinOps.RemoveZeroWeights iSkinModf
	)
	
	--	���ƶ�����ɫ��
	fn fn_copyVertexColor node_obj int_channel =
	(
		local ary_colors = #()
		
		polyop.setMapSupport node_obj int_channel true
		if ( true == polyop.getMapSupport node_obj int_channel ) do
		(
			for int_v in 1 to node_obj.verts.count do
			(
				local color_vert = polyop.getMapVert node_obj int_channel int_v
				
				append ary_colors ( color_vert*255 )
			)
		)
		
		return ary_colors
	)
	
	--	ͬ���������ѡ�񼯶��㡣
	fn fn_syncSubobjectSelection node_obj =
	(
		local bary_subSelection = #{}
		
		max modify mode
		node_obj.deleteIsoVerts()
		if ( node_obj.modifiers[#KG3D_FlexVertexColor] == modPanel.getCurrentObject() ) then
		(
			bary_subSelection = getVertSelection node_obj node_obj.modifiers[#KG3D_FlexVertexColor]
			node_obj.EditablePoly.SetSelection #Vertex bary_subSelection
			bary_subSelection = getEdgeSelection node_obj node_obj.modifiers[#KG3D_FlexVertexColor]
			node_obj.EditablePoly.SetSelection #edge bary_subSelection
			bary_subSelection = getFaceSelection node_obj node_obj.modifiers[#KG3D_FlexVertexColor]
			node_obj.EditablePoly.SetSelection #face bary_subSelection
		)
		else
		(
			if ( undefined != node_obj.modifiers[#KG3D_FlexVertexColor] ) do
			(
				bary_subSelection = node_obj.EditablePoly.GetSelection #Vertex
				setVertSelection node_obj node_obj.modifiers[#KG3D_FlexVertexColor] bary_subSelection
				bary_subSelection = node_obj.EditablePoly.GetSelection #Vertex
				setEdgeSelection node_obj node_obj.modifiers[#KG3D_FlexVertexColor] bary_subSelection
				bary_subSelection = node_obj.EditablePoly.GetSelection #Vertex
				setFaceSelection node_obj node_obj.modifiers[#KG3D_FlexVertexColor] bary_subSelection
			)
		)
	)
	
	--	ճ��������ɫ��
	fn fn_pasteVertexColor node_obj =
	(
		local col_RGB = [0,0,0]
		local int_channel = 0
		local bary_selVerts = #{}
		local ary_colorList = #()
		local ary_sameColor = #()
		
		if ( true == rol.chk_copyRed.state ) do ( col_RGB.x = 1 )
		if ( true == rol.chk_copyGreen.state ) do ( col_RGB.y = 1 )
		if ( true == rol.chk_copyBlue.state ) do ( col_RGB.z = 1 )
		
		--	��ȡnode_obj�������嵱ǰѡ���Ӧ�Ķ��㡣
		case subobjectLevel of
		(
			( 1 ):
			(
				bary_selVerts = node_obj.EditablePoly.GetSelection #Vertex
			)
			( 2 ):
			(
				bary_selVerts = node_obj.EditablePoly.GetSelection #edge
				bary_selVerts = polyop.getVertsUsingEdge node_obj bary_selVerts
			)
			( 3 ):
			(
				bary_selVerts = node_obj.EditablePoly.GetSelection #edge
				bary_selVerts = polyop.getVertsUsingEdge node_obj bary_selVerts
			)
			( 4 ):
			(
				bary_selVerts = node_obj.EditablePoly.GetSelection #face
				bary_selVerts = polyop.getVertsUsingface node_obj bary_selVerts
			)
			( 5 ):
			(
				bary_selVerts = node_obj.EditablePoly.GetSelection #face
				bary_selVerts = polyop.getVertsUsingface node_obj bary_selVerts
			)
			default:( bary_selVerts = #{1..node_obj.verts.count} )
		)
		bary_selVerts = bary_selVerts-(bary_selVerts-#{1..copyedColorInfo.vertColor.count})
		--	copyedColorInfo = vertsInfo (vertPos,vertColor,colorList,sameColor,vertIllumination,illuminationList,sameIllumination,vertAlpha,alphaList,sameAlpha)
		if ( true == rol.chk_copyColor.state ) do
		(
			local bary_targetColor = #{}
			
			int_channel = 0
			polyop.setMapSupport node_obj int_channel true
			for n = 1 to copyedColorInfo.colorList.count do
			(
				local ary_color = #()
				local ary_list = #()
				local i_color = ( copyedColorInfo.colorList[n]*col_RGB ) as color
				local bary_paste = bary_selVerts-( bary_selVerts-copyedColorInfo.sameColor[n] )
				
			--	format "------	copyedColorInfo.colorList.[%] = %	------\n" n copyedColorInfo.colorList[n]
				--	����RGB����ͨ���Ƿ�ճ������ճ���򱣳�ԭͨ����ֵ��
				if ( [1,1,1] == col_RGB ) then
				(
					polyop.setVertColor node_obj int_channel bary_paste i_color
				--	format "SetVertColor block [%] color = %,\n" n rol.copyedColorInfo.colorList[n]
				)
				else
				(
					for int_v in bary_paste do
					(
						local int_n = 0
						local color_v = ( polyop.getMapVert node_obj int_channel int_v )*255
						
						color_v *= [1,1,1]-col_RGB 
						color_v += i_color
						color_v = color_v as color
						int_n = findItem ary_color color_v
						if ( 0 == int_n ) then
						(
							append ary_color color_v
							append ary_list #{int_v}
						)
						else
						(
							ary_list[int_n] += #{int_v}
						)
					)
					
					for m = 1 to ary_list.count do
					(
					--	format "SetVertColor subBlock [%] color = %,VertsList = %\n" m ary_color[m] ary_list[m]
						polyop.setVertColor node_obj int_channel ary_list[m] ary_color[m]
					)
				)
			)
		)
		if ( true == rol.chk_copyIllumination.state ) do
		(
			int_channel = -1
			polyop.setMapSupport node_obj int_channel true
			for n = 1 to copyedColorInfo.illuminationList.count do
			(
				local ary_color = #()
				local ary_list = #()
				local i_color = ( copyedColorInfo.illuminationList[n]*col_RGB ) as color
				local bary_paste = bary_selVerts-( bary_selVerts-copyedColorInfo.sameIllumination[n] )
				
				--	����RGB����ͨ���Ƿ�ճ������ճ���򱣳�ԭͨ����ֵ��
				if ( [1,1,1] == col_RGB ) then
				(
					polyop.setVertColor node_obj int_channel bary_paste i_color
				)
				else
				(
					for int_v in bary_paste do
					(
						local int_n = 0
						local color_v = ( polyop.getMapVert node_obj int_channel int_v )*255
						
						color_v *= [1,1,1]-col_RGB 
						color_v += i_color
						color_v = color_v as color
						int_n = findItem ary_color color_v
						if ( 0 == int_n ) then
						(
							append ary_color color_v
							append ary_list #{int_v}
						)
						else
						(
							ary_list[int_n] += #{int_v}
						)
					)
					
					for m = 1 to ary_list.count do
					(
						polyop.setVertColor node_obj int_channel ary_list[m] ary_color[m]
					)
				)
			)
		)
		if ( true == rol.chk_copyAlpha.state ) do
		(
			int_channel = -2
			polyop.setMapSupport node_obj int_channel true
			for n = 1 to copyedColorInfo.alphaList.count do
			(
				local ary_color = #()
				local ary_list = #()
				local i_color = ( copyedColorInfo.alphaList[n]*col_RGB ) as color
				local bary_paste = bary_selVerts-( bary_selVerts-copyedColorInfo.sameAlpha[n] )
				
				--	����RGB����ͨ���Ƿ�ճ������ճ���򱣳�ԭͨ����ֵ��
				if ( [1,1,1] == col_RGB ) then
				(
					polyop.setVertColor node_obj int_channel bary_paste i_color
				)
				else
				(
					for int_v in bary_paste do
					(
						local int_n = 0
						local color_v = ( polyop.getMapVert node_obj int_channel int_v )*255
						
						color_v *= [1,1,1]-col_RGB 
						color_v += i_color
						color_v = color_v as color
						int_n = findItem ary_color color_v
						if ( 0 == int_n ) then
						(
							append ary_color color_v
							append ary_list #{int_v}
						)
						else
						(
							ary_list[int_n] += #{int_v}
						)
					)
					
					for m = 1 to ary_list.count do
					(
						polyop.setVertColor node_obj int_channel ary_list[m] ary_color[m]
					)
				)
			)
		)
		update node_obj
	)
	
	--	ȥ����baseobject�е�KG3D_FlexVertexColor����ɫ���á�
	fn fn_removeFlexVertexColor node_obj =
	(
		local ary_attribs = #()
		
		thePainterInterface.endPaintSession()
		
		--	ȥ����modifiers�е�KG3D_FlexVertexColor
		for n = node_obj.modifiers.count to 1 by -1 do
		(
			if ( "KG3D_FlexVertexColor" == node_obj.modifiers[n].name ) do
			(
				deleteModifier node_obj n
			)
		)
		--	ȥ����baseobject�е�KG3D_FlexVertexColor
		for n = ( custAttributes.count node_obj ) to 1 by -1 do
		(
			local i_attrib = custAttributes.get node_obj n
			
			if ( "KG3D_FlexVertexColor" == i_attrib.name ) do
			(
				removeRollout node_obj.rol_paintMode
				removeRollout node_obj.rol_paintVertexes
				removeRollout node_obj.rol_about
				custAttributes.delete node_obj n
			)
		)
		select node_obj
	)
	
	/*------------------------------------------------------------------------------------------------*/
	
	GroupBox 'grp_skin' "Skin On Top Modifier" pos:[8,8] width:240 height:312 align:#left
	button 'btn_addSkin' "Add Temp Skin (None Bone)" pos:[16,24] width:224 height:24 align:#left
	button 'btn_splitSkin' "Split Skin (Selected Face)" pos:[16,56] width:224 height:32 align:#left
	button 'btn_mergeSkin' "Merge Skin (Selected Obj)" pos:[16,96] width:160 height:32 align:#left
	button 'btn_repasteWeight' "Repaste" pos:[184,96] width:56 height:32 align:#left
	checkbox 'chk_weldSkinVert' "Weld Vertex,Threshold" pos:[40,136] width:128 height:16 checked:false align:#left
	spinner 'spn_weldSkinVert' "" pos:[168,136] width:40 height:16 range:[0.01,9.99,0.01] scale:0.01 align:#left
	
	button 'btn_copySkinWeight' "Copy Weight" pos:[16,160] width:72 height:48 align:#left
	button 'btn_pasteSkinWeight' "Paste Weight" pos:[96,160] width:72 height:48 align:#left
	button 'btn_deformWeight' "Deform All" pos:[176,184] width:64 height:24 align:#left
	button 'btn_deformSelWeight' "Deform Sel" pos:[176,160] width:64 height:24 align:#left
	button 'btn_CopyDQWeight' "Copy DQ Weight" pos:[16,220] width:224 height:24 align:#left
	button 'btn_PasteDQWeight' "Paste DQ" pos:[16,248] width:88 height:24 align:#left
	button 'btn_DeformSelDQ' "Deform Sel" pos:[112,248] width:64 height:24 align:#left
	button 'btn_DeformAllDQ' "Deform All" pos:[176,248] width:64 height:24 align:#left
	button 'btn_removeZero' "Remove 0-Weight Bone" pos:[16,284] width:224 height:24 align:#left
	
	GroupBox 'grp_color' "Selected Object Vertex color" pos:[8,328] width:240 height:112 align:#left
	button 'btn_copyColor' "Copy" pos:[16,352] width:64 height:56 align:#left
	button 'btn_pasteByIndex' "Paste Selected Vert #Index" pos:[88,352] width:152 height:24 enabled:false align:#left
	button 'btn_pasteByPos' "Paste Selected Vert #Position" pos:[88,384] width:152 height:24 enabled:false align:#left
	checkbox 'chk_copyColor' "Color" pos:[16,416] width:42 height:16 checked:true align:#left
	checkbox 'chk_copyIllumination' "Illumination" pos:[56,416] width:72 height:16 checked:true align:#left
	checkbox 'chk_copyAlpha' "Alpha" pos:[128,416] width:44 height:16 checked:true align:#left
	checkbox 'chk_copyRed' "R" pos:[171,416] width:24 height:16 checked:true align:#left
	checkbox 'chk_copyGreen' "G" pos:[192,416] width:24 height:16 checked:true align:#left
	checkbox 'chk_copyBlue' "B" pos:[219,416] width:24 height:16 checked:true align:#left
	
	button 'btn_addFlexColorPlugin' "+ Add Flex Color Plugin to Selected Poly +" pos:[8,452] width:240 height:40 align:#left
	button 'btn_removeFlexColorPlugin' "Clear Flex Color Plugin From Selected Ploy" pos:[8,496] width:240 height:32 align:#left
	
	HyperLink 'Hyp_copyright' "\xa9"
	HyperLink 'Hyp_copyrightYear' "2019"
	HyperLink 'Hyp_copyrightOwner' "SeasunGame"
	HyperLink 'Hyp_textVer' "Ver:"
	HyperLink 'Hyp_version' "2000.00.00"
	HyperLink 'Hyp_textBy' "by"
	HyperLink 'Hyp_editor' "Ou Jion"
	/*-------------------------------------------------------------------------------------------------------------------------------------------*/
	
	on rol_flexSkinTool open do
	(
		btn_splitSkin.tooltip = "1.��Editable Poly��ѡ����Ҫ��ֵ��棻\n2.�����˰�ť����ѡ�е��������µ�Skin���塣"
		btn_mergeSkin.tooltip = "1.ѡ��N�����壻\n2.�����˰�ť����ѡ�е�Skin����ϲ���һ��Skin���塣"
		btn_copySkinWeight.tooltip = "1.ѡ��1��Skin���壻\n2.�����˰�ť�����Ƹ������Skin����Ȩ�ص������塣"
		btn_deformWeight.tooltip = "1.ѡ��N�����壻\n2.�����˰�ť������������Skin����Ȩ��ƥ�䵽ѡ�е�����Skin�����ϡ�"
		btn_deformSelWeight.tooltip = "1.ѡ�������Skin Vertices��\n2.�����˰�ť������������Skin����Ȩ��ƥ�䵽ѡ�е�Skin Vertices�ϡ�"
		btn_removeZero.tooltip = "��ѡ�е�Skin�����У���δ�����κζ���Ȩ�صĹ�����skin���Ƴ���"
		btn_copyColor.tooltip = "���Ƶ�ǰѡ�еġ�Poly���塿����ɫ��"
		btn_pasteByIndex.tooltip = "�������������ճ������ɫ��\nע���� [������] ʱ�ɽ�ճ��ѡ�е������岿�֡�"
		btn_pasteByPos.tooltip = "�������������ճ������ɫ��\nע���� [������] ʱ�ɽ�ճ��ѡ�е������岿�֡�"
		
		fn_setCopyrightInfo rol "2026.05.13.a"
	)
	on rol_flexSkinTool close do
	(
		rol_flexSkinTool = undefined
	)
	on btn_addSkin pressed do
	(
		for obj in selection where (superClassOf obj == GeometryClass) do
		(
			if (obj.modifiers[#skin] == undefined) do
			(
				addModifier obj (skin() )
				obj.modifiers[#Skin].bone_Limit = 4
			)
		)
	)
	on btn_splitSkin pressed do
	(
		for obj in selection where (classof obj.modifiers[1] == Skin) do
		(
			fn_splitSkinObj obj
		)
	)
	on btn_mergeSkin pressed do
	(
		local aryMergeObjs = for obj in selection where (obj.modifiers[#skin] != undefined) collect obj
		
		if (aryMergeObjs.count > 1) do 
		(
			local weldThreshold
			
			if (true == rol.chk_weldSkinVert.state) then
			(
				weldThreshold = rol.spn_weldSkinVert.value
			)
			else
			(
				weldThreshold = 0
			)
			ary_mergeSkinWeight = fn_mergeSkin aryMergeObjs weldThreshold
		)
	)
	on btn_repasteWeight pressed do
	(
		local i_skin = $.modifiers[#Skin]
		local aryVertWeightBone = ary_mergeSkinWeight[1]
		local aryVertWeight = ary_mergeSkinWeight[2]
		
		modPanel.setCurrentObject i_skin
		for n = 1 to $.verts.count where (undefined != i_skin and 0<ary_mergeSkinWeight.count) do
		(
			skinOps.ReplaceVertexWeights i_skin n aryVertWeightBone[n] aryVertWeight[n]
		)
	)
	on btn_copySkinWeight pressed do
	(
		if (selection.count == 1 and $.modifiers[#skin] != undefined) do (stuc_skinWeight = fn_copySkinWeight $)
	)
	on btn_pasteSkinWeight pressed do
	(
		local ary_skinObj = for obj in selection where (obj.modifiers[#skin] != undefined) collect obj
		
		for obj in ary_skinObj do
		(
			fn_pasteSkinWeight obj stuc_skinWeight false
		)
	)
	on btn_deformWeight pressed do
	(
		local ary_skinObj = for obj in selection where (obj.modifiers[#skin] != undefined) collect obj
		
		for obj in ary_skinObj do
		(
			fn_deformSkinWeight obj stuc_skinWeight false false
		)
	)
	on btn_deformSelWeight pressed do
	(
		local ary_skinObj = for obj in selection where (obj.modifiers[#skin] != undefined) collect obj
		
		for obj in ary_skinObj do
		(
			fn_deformSkinWeight obj stuc_skinWeight true false
		)
	)
	on btn_CopyDQWeight pressed do
	(
		if ( 1 == selection.count and undefined != $.modifiers[#skin] ) do ( stuc_skinWeight = fn_copySkinWeight $ )
	)
	on btn_PasteDQWeight pressed do
	(
		local ary_skinObj = for obj in selection where ( obj.modifiers[#skin] != undefined ) collect obj
		
		for obj in ary_skinObj do
		(
			for v = 1 to stuc_skinWeight.DQWeight.count do
			(
				skinOps.setVertexDQWeight obj.modifiers[#skin] v stuc_skinWeight.DQWeight[v]
			)
		)
	)
	on btn_DeformSelDQ pressed do
	(
		local ary_skinObj = for obj in selection where (obj.modifiers[#skin] != undefined) collect obj
		
		for obj in ary_skinObj do
		(
			fn_deformSkinWeight obj stuc_skinWeight true true
		)
	)
	on btn_DeformAllDQ pressed do
	(
		local ary_skinObj = for obj in selection where (obj.modifiers[#skin] != undefined) collect obj
		
		for obj in ary_skinObj do
		(
			fn_deformSkinWeight obj stuc_skinWeight false true
		)
	)
	on btn_removeZero pressed do
	(
		local ary_skinObj = for obj in selection where (obj.modifiers[#skin] != undefined) collect obj
		
		for obj in ary_skinObj do
		(
			fn_removeZeroWeightBone obj
		)
	)
	on btn_copyColor pressed do
	(
		local ary_meshObj = for obj in selection where (classOf obj == PolyMeshObject or classOf obj == Editable_Poly) collect obj
		
		fn fn_getSameColor node_current int_mapChannel colorList sameColor =
		(
			setWaitCursor()
			bary_allIndex = #{1..node_current.verts.count}
			polyop.setMapSupport node_current int_mapChannel true
			
			while ( 0<bary_allIndex.numberSet ) do
			(
				local int_color = (bary_allIndex as array)[1]
				
				node_current.EditablePoly.SetSelection #Vertex #{int_color}
				pt3_vertColor = ( node_current.EditablePoly.GetVertexColor int_mapChannel ) as point3
				append colorList pt3_vertColor
				
				bary_sames = polyop.getVertsByColor node_current ( pt3_vertColor as color ) 0.11 0.11 0.11 channel:int_mapChannel
				append sameColor bary_sames
				
				bary_allIndex -= bary_sames
			)
			if ( 11 == i_debug ) do
			(
				format "vertexMapChannel = %; Same color count = %\nSame color list = %\n" int_mapChannel colorList.count colorList
			)
			setArrowCursor()
		)
		
		if ( 1 == ary_meshObj.count ) do
		(
			local node_current = ary_meshObj[1]
			local bary_hiddenVerts = polyop.getHiddenVerts node_current
			local int_mapChannel,bary_allIndex,pt3_vertColor,bary_sames
			local bary_selVerts = node_current.EditablePoly.GetSelection #Vertex
			
			node_current.EditablePoly.unhideAll #Vertex
			node_current.deleteIsoVerts()
			--	vertsInfo vertPos,vertColor,colorList,sameColor,vertIllumination,illuminationList,sameIllumination,vertAlpha,alphaList,sameAlpha
			--	copyedColorInfo = rol_flexSkinTool.vertsInfo vertPos:#() vertColor:#() colorList:#() sameColor:#() vertIllumination:#() illuminationList:#() sameIllumination:#() vertAlpha:#() alphaList:#() sameAlpha:#()
			copyedColorInfo = vertsInfo vertPos:#() \
										vertColor:#() colorList:#() sameColor:#() \
										vertIllumination:#() illuminationList:#() sameIllumination:#() \
										vertAlpha:#() alphaList:#() sameAlpha:#()
			
			copyedColorInfo.vertPos = for n = 1 to node_current.verts.count collect ( in coordSys local (node_current.verts[n].pos) )
			copyedColorInfo.vertColor = fn_copyVertexColor node_current 0
			copyedColorInfo.vertIllumination = fn_copyVertexColor node_current -1
			copyedColorInfo.vertAlpha = fn_copyVertexColor node_current -2
			
			/*2024.01.26��������*/
			fn_getSameColor node_current  0 copyedColorInfo.colorList copyedColorInfo.sameColor
			fn_getSameColor node_current -1 copyedColorInfo.illuminationList copyedColorInfo.sameIllumination
			fn_getSameColor node_current -2 copyedColorInfo.alphaList copyedColorInfo.sameAlpha
			
			polyop.setHiddenVerts node_current bary_hiddenVerts
			node_current.EditablePoly.SetSelection #Vertex bary_selVerts
		)
		
		btn_pasteByIndex.enabled = btn_pasteByPos.enabled = not( undefined == copyedColorInfo )
	)
	on btn_pasteByIndex pressed do with undo "Flex Tool:Paste Color" on
	(
		local ary_tagetObj = for obj in selection where (classOf obj == PolyMeshObject or classOf obj == Editable_Poly) collect obj
		
		if ( 0<ary_tagetObj.count ) do
		(
			for node_current in ary_tagetObj do
			(
				local int_subLevel = subobjectLevel
				
				--	ͬ���������ѡ�񼯶��㡣
				fn_syncSubobjectSelection node_current
				
				subobjectLevel = int_subLevel
				--	ճ����ɫ��
				fn_pasteVertexColor node_current
			)
		)
	)
	on btn_pasteByPos pressed do with undo "Flex Tool:Paste Color" on
	(
		local ary_tagetObj = for obj in selection where (classOf obj == PolyMeshObject or classOf obj == Editable_Poly) collect obj
		
		fn fn_setColorByPosition obj ary_deform col_RGB int_channel =
		(
			local int_find = 0
			local ary_color = #()
			local ary_list = #()
			
			for n = 1 to ary_deform.count do
			(
				local i_color = copyedColorInfo.vertColor[ary_deform[n].y]*col_RGB
				
				int_find = findItem ary_color i_color
				if ( 0 == int_find ) then
				(
					append ary_color i_color
					append ary_list #{ary_deform[n].x}
				)
				else
				(
					ary_list[int_find] += #{ary_deform[n].x}
				)
			)
			
			for m = 1 to ary_list.count do
			(
				polyop.setVertColor obj int_channel ary_list[m] ( ary_color[m] as color )
			--	format "ary_list[m] = %; ary_color[m] = %\n" ary_list[m] ary_color[m]
			)
		)
		
		setWaitCursor()
		max modify mode
		if ( 0<ary_tagetObj.count ) do
		(
			for node_current in ary_tagetObj do
			(
				local ary_color = #()
				local ary_list = #()
				local col_RGB = [0,0,0]
				local int_channel = 0
				local ary_deform = #()
				local bary_selVerts = #{}
				local int_subLevel = subobjectLevel
				
				--	ͬ���������ѡ�񼯶��㡣
				fn_syncSubobjectSelection node_current
				subobjectLevel = int_subLevel
				--	��ȡnode_current�������嵱ǰѡ���Ӧ�Ķ��㡣
				case subobjectLevel of
				(
					( 1 ):
					(
						bary_selVerts = node_current.EditablePoly.GetSelection #Vertex
					)
					( 2 ):
					(
						bary_selVerts = node_current.EditablePoly.GetSelection #edge
						bary_selVerts = polyop.getVertsUsingEdge node_current bary_selVerts
					)
					( 3 ):
					(
						bary_selVerts = node_current.EditablePoly.GetSelection #edge
						bary_selVerts = polyop.getVertsUsingEdge node_current bary_selVerts
					)
					( 4 ):
					(
						bary_selVerts = node_current.EditablePoly.GetSelection #face
						bary_selVerts = polyop.getVertsUsingface node_current bary_selVerts
					)
					( 5 ):
					(
						bary_selVerts = node_current.EditablePoly.GetSelection #face
						bary_selVerts = polyop.getVertsUsingface node_current bary_selVerts
					)
					default:( bary_selVerts = #{1..node_current.verts.count} )
				)
				
				--	������ɫ��
				if ( true == rol.chk_copyRed.state ) do ( col_RGB.x = 1 )
				if ( true == rol.chk_copyGreen.state ) do ( col_RGB.y = 1 )
				if ( true == rol.chk_copyBlue.state ) do ( col_RGB.z = 1 )
				
				format "Processing start %, " localtime
				start = timeStamp()
				for v in bary_selVerts do
				(
					local int_deform = 1
					local flt_min = 65535
					local pt3_vPos = in coordSys local ( node_current.verts[v].pos )
					
					for n = 1 to copyedColorInfo.vertPos.count do
					(
						local flt_dist = distance pt3_vPos copyedColorInfo.vertPos[n]
						
						if (flt_min > flt_dist) do
						(
							flt_min = flt_dist
							int_deform = n
						)
						if (flt_min<0.01) do exit
					)
					append ary_deform [v,int_deform]
				)
				end = timeStamp()
				format "took % seconds.\n" ((end-start)/1000.0)
				
				if ( true == rol.chk_copyColor.state ) do
				(
					fn_setColorByPosition node_current ary_deform col_RGB 0
				)
				if ( true == rol.chk_copyIllumination.state ) do
				(
					fn_setColorByPosition node_current ary_deform col_RGB -1
				)
				if ( true == rol.chk_copyAlpha.state ) do
				(
					fn_setColorByPosition node_current ary_deform col_RGB -2
				)
			)
		)
		setArrowCursor()
	)
	
	on btn_addFlexColorPlugin pressed do
	(
		setWaitCursor()
		for obj in selection where ( true == validModifier obj ( Poly_Select() ) ) do
		(
			local bol_polyObj = ( Editable_Poly == classOf obj.baseObject )
			
			clearlistener()
			--	ת�������������ΪEditable_Poly��
			if ( false == bol_polyObj and true == validModifier obj ( edit_poly() ) ) do
			(
				if ( queryBox ( "KG3D Flex vertexes color:\nConvert "+obj.name+"'s base-object class to 'Editable_Poly'?" ) title:"KG3D_FlexVertexColor" ) do
				(
					addmodifier obj ( edit_poly() ) before:obj.modifiers.count
					bol_polyObj = maxOps.CollapseNodeTo obj obj.modifiers.count on
				)
			)
			
			if ( true == bol_polyObj ) do
			(
				
				fn_removeFlexVertexColor obj
				addmodifier obj ( Poly_Select name:"KG3D_FlexVertexColor" )
				custAttributes.add obj.modifiers[#KG3D_FlexVertexColor] Attribute_FlexVertexColor
			)
		)
		setArrowCursor()
	)
	
	on btn_removeFlexColorPlugin pressed do
	(
		for obj in selection do ( fn_removeFlexVertexColor obj )
	)
	
)

createDialog rol_flexSkinTool
--	update:>Attribute_FlexVertexColor:>About rollout:>version info...
--	if ( 0<selection.count ) do ( select $ )
clearListener()




/*










