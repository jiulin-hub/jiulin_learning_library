try
(destroyDialog rol_Constraint)
catch()
clearlistener()

rollout rol_Constraint "APEXConstraint Tool" width:200 height:168
(
	local rol = rol_Constraint
	local ary_constraint = for obj in objects where (findString obj.name "Constraint" != undefined) collect obj
	
	fn fn_expConstraint =
	(
		local txt = ""
		local aryCons = for obj in objects where (findString obj.name "Constraint" != undefined) collect obj
		local iPoint = point name:"capsuleTemp"
		
		txt += "[simulations]"+"\n"
		txt += "count="+aryCons.count as string+"\n"
		txt += "unit=inch"+"\n"
		txt += "inCoordSys=Bip01"+"\n"
		txt += "\n"
		
		for n = 1 to aryCons.count do
		(
			local i = aryCons[n]
			local iPos = [0,0,0]
			
			txt += "[constraint"+n as string+"]"+"\n"
			txt += "type="+(classOf i) as string+"\n"
			txt += "parent="+i.parent.name+"\n"
			case (classOf i) of
			(
				Capsule:
				(
					in coordSys i (iPoint.pos = [0,0,i.radius])
					iPos = in coordSys i.parent iPoint.pos
					iPos.x = ((iPos.x*1000) as integer)/1000.0
					iPos.y = ((iPos.y*1000) as integer)/1000.0
					iPos.z = ((iPos.z*1000) as integer)/1000.0
					txt += "pos1="+iPos.x as string+","+iPos.y as string+","+iPos.z as string+"\n"
					
					iPoint = point name:"capsuleTemp01"
					in coordSys i (iPoint.pos = [0,0,(i.height-i.radius)])
					iPos = in coordSys i.parent iPoint.pos
					iPos.x = ((iPos.x*1000) as integer)/1000.0
					iPos.y = ((iPos.y*1000) as integer)/1000.0
					iPos.z = ((iPos.z*1000) as integer)/1000.0
					txt += "pos2="+iPos.x as string+","+iPos.y as string+","+iPos.z as string+"\n"
					
					txt += "radius="+i.radius as string+"\n"
				)
				Box:
				(
					iPoint.transform = i.transform
					iPoint.pos = i.center
					iPos = in coordSys i.parent iPoint.pos
					iPos.x = ((iPos.x*1000) as integer)/1000.0
					iPos.y = ((iPos.y*1000) as integer)/1000.0
					iPos.z = ((iPos.z*1000) as integer)/1000.0
					txt += "center="+iPos.x as string+","+iPos.y as string+","+iPos.z as string+"\n"
					
					iPos = in coordSys i.parent iPoint.dir
					iPos.x = ((iPos.x*1000) as integer)/1000.0
					iPos.y = ((iPos.y*1000) as integer)/1000.0
					iPos.z = ((iPos.z*1000) as integer)/1000.0
					txt += "dir="+iPos.x as string+","+iPos.y as string+","+iPos.z as string+"\n"
					
					txt += "length="+i.length as string+"\n"
					txt += "width="+i.width as string+"\n"
					txt += "height="+i.height as string+"\n"
				)
				default:()
			)
			
			txt += "\n"
		)
		delete iPoint
		
		setclipboardText txt
		
		return txt
	)

	button 'btn_create' "Create Constraint" pos:[8,8] width:184 height:32 align:#left
	button 'btn_check' "Check Constraint" pos:[8,48] width:184 height:24 align:#left
	button 'btn_export' "Export Constraint" pos:[8,88] width:184 height:48 align:#left
	
	HyperLink 'copyright' "Copyright SeasunGame.v2017.07.24" pos:[12,144] width:184 height:16 color:(color 0 0 0) visitedcolor:(color 0 0 0) address:"http://www.xishanju.com/" align:#left
	-----------------------------
	on btn_create pressed do
	(
		local i = Capsule name:"Constraint" heighttype:0
		
		select i
		append ary_constraint i
		i.name += ary_constraint.count as string
	)
	on btn_check pressed do
	(
		for i in ary_constraint where (isValidObj i) do
		(
			if (i.parent == undefined) do
			(
				select i
				messageBox "This Constraint has NO parent." title:"APEXConstraint"
				exit
			)
		)
	)
	on btn_export pressed do
	(
		local str_fileName = getSaveFileName caption:"Save Constraint File:" filename:"" types:"Ini File(*.ini)|*.ini|All|*.*|"
		
		if (str_fileName != undefined) do
		(
			local iFile = createFile str_fileName
			
			format (fn_expConstraint() ) to:iFile
			close iFile
			messageBox ("Constraint File Exported to:\n"+str_fileName) title:"APEXConstraint"
		)
		
	)
)

createDialog rol_Constraint
/*
[simulations]
count=4
unit=inch
inCoordSys=Bip01

[Constraint1]
type=capsule
parent=Bip01 Spine2
pos1=-0.866489,-2.13939,19.7698
pos2=-0.866489,-2.13939,0.969769
radius=5.0

[Constraint2]
type=capsule
parent=Bip01 Spine2
pos1=-0.866489,2.13939,19.7698
pos2=-0.866489,2.13939,0.969769
radius=5.0

[Constraint3]
type=capsule
parent=Bip01 R Thigh
pos1=-0.185804,-3.90564,-4.97074
pos2=-2.41903,-6.25361,-34.7952
radius=5.0

[Constraint4]
type=capsule
parent=Bip01 L Thigh
pos1=-0.185804,3.90564,-4.97074
pos2=-2.41903,6.25361,-34.7952
radius=5