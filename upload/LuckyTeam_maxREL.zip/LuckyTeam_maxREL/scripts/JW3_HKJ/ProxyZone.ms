global DTS_ProxyZone 

install__ = false
if globalvars.isglobal #gmxs64__ do
(
	ini_file = (getdir #plugcfg) + "\\seasun_tools.ini"
	tool_id = #proxy_zone
	status = iniops.check ini_file #seasun_dts_tools tool_id default:(str_ (MAX_VERSION_ > 22)) 
	install__ = executestring status
	format "(MAX LOADING:%) % >> % = install:%\n" THE_MAX_LOADING_ tool_id status install__
)

if install__ do
(
	struct ProxyZoneStruct
	(
	private
		tool_name = #DTS_ProxyZone,
		proxy_tag = tag_ tool_name "_tag" low:on,
		system_name = str_ #PROXY ":",
		
	private
		version = "v3.8",
		setprops = 
		#(
			#current_tool, #use_works_pivot, #backface_cull, #vertex_ticks, #vertex_numbers, #auto_edit,
			#source_type, #use_verts, #direction_type, #project_type, #length_segs, #width_segs, #project_target, #per_element, #reorient, #aligned_box, #use_axis,
			#sync_samples, #conform_points, #tension, #tesselations, #orient_ratio, #tuning, #oriented, #capped, #flatten, #shape_type, #optimized, #optimize_type, #optimize_percent, 
			#hull2D_type, #hull3D_type, #enlarge, #scaling, #refine_type, #flip_surface, #smooth_surface, #trim_loft, #axis_constrain,
			#debug_mode, #debug_proxy_dummys, #debug_proxy_points 
		),
		winprops = 
		#(
			#pos, #size, #rect, #placement
		),			
	public

		ini_file = (getdir #plugcfg) + "\\dts_tools.ini", 
		title = str_ "PROXY ZONE " version,
		fn toolname = (tool_name),
		fn proxytag = (proxy_tag),

		opened = off,
		parent_hwnd = unsupplied,
		
		debug_mode = false,
		debug_proxy_dummys = false, 
		debug_proxy_points = false, 
		
		props_store = 
		#(
			#use_verts, #use_works_pivot, #auto_edit, #project_target, 
			#recent_shape, #recent_hull, #recent_bbox, #recent_proxy, #recent_proxy_ref, #recent_shape_ref
		),

		current_tool = 0,
		use_works_pivot = false,
		
		backface_cull = false, 
		vertex_ticks = true,
		vertex_numbers = true,
		
		recent_proxy_ref = undefined, 
		recent_shape_ref = undefined, 
		
		use_axis = [1,1,1],
		use_verts = false,
		auto_edit = false,
		length_segs = 4,
		width_segs = 4,
		sync_samples = true,
		conform_points = 6,
		tension = 0.1,
		tesselations = 0,
		refine_type = 1,
		orient_ratio = 0,
		tuning = 0.5,
		oriented = false,
		capped = true, 
		flatten = true,
		flip_surface = false,
		smooth_surface = false,
		trim_loft = false,
		shape_type = 1, 
		optimized = false, 
		optimize_type = 1,
		optimize_percent = 0.50,
		enlarge = 0.1,
		scaling = 1.0,
		axis_constrain = false,
		
		per_element = false,
		reorient = false,
		aligned_box = false,
		source_type = 2,
		direction_type = 3,
		project_type = 1,
		project_target = undefined,
		recent_shape = undefined,
		recent_hull = undefined,
		recent_bbox = undefined,
		recent_proxy = undefined,
		
		recent_ffddmod = undefined,
		recent_extrude = undefined,
		recent_normspl = undefined,
		recent_optispl = undefined,

		hull2D_type = 1,
		hull3D_type = 1,
		
		fn destroy =
		(
			local d = globalvars.getvalue #DTS_ProxyZone prop:#dialog
			if defined d do rolloutops.destroydialog d
		),
		dialog_pos = 
		(
			if (iniops.has ini_file #dts_proxy_zone #pos) then execute (iniops.get ini_file #dts_proxy_zone #pos) else [400,120]
		),
		dialog_size = 
		(
			if (iniops.has ini_file #dts_proxy_zone #size) then execute (iniops.get ini_file #dts_proxy_zone #size) else [191,502]
		),
		dialog_rect = 
		(
			if (iniops.has ini_file #dts_proxy_zone #rect) then execute (iniops.get ini_file #dts_proxy_zone #rect) else [400,120,191,502]
		),

		fn cleanINISettings file: = 
		(
			if file == unsupplied do file = ini_file
			
			config_props = vset_ (winprops + setprops) info:off
			stored_props = iniops.find ini_file #dts_proxy_zone
			unused_props = vset_ \
			(
				for x in stored_props where not isset config_props[x] collect 
				(
					iniops.delete ini_file #dts_proxy_zone x
					x
				)
			)
		),

		fn loadINISettings file: = 
		(
			if file == unsupplied do file = ini_file
			for p in setprops where (iniops.has file #dts_proxy_zone p) do
			(
				v = prop_ this p
				s = iniops.get file #dts_proxy_zone p
				v = try_ execute s return:(choice (isstring v) s v)
				if v != undefined do 
				(
					if isstruct v do
					(
						for i in (getpropnames v) do if (getproperty v i) == undefined do setproperty v i (getproperty str i) 
					)
					setpropvalue this p v
				)
			)
		),
		fn saveINISettings file: = 
		(
			if file == unsupplied do file = ini_file
			iniops.flush file
			for p in setprops do iniops.set file #dts_proxy_zone p (sprop_ this p)
		),
		
		pivot_cb = undefined, 	
		fn getSubObjectAxis = if istruenode (n = selectednode) do  
		(
			project = (getnodelocalbbox n).transform
			if iffd.isValid (obj = cureditobject) then
			(
				--sel = iffd.selected obj
				pp = iffd.getPointPositions obj points:#selected absolute:on node:node
				bestCloudAxis pp project:n space:#3d
			)
			else if isgeometry n then 
			(	
				vv = getmeshvertsusing n #selected level:-1
				pp = getPointPositions n verts:vv type:#pos
				--xformat_ pp
				bestCloudAxis pp project:n space:#3d --verts:#all
			)
			else if isshape n then 
			(	
				pp = getPointPositions n verts:#selected type:#pos
				pp = subtab pp [1,2,3,-1]

				--xformat_ pp
				if pp.count > 2 and false then 
					findBoundingBox3d pp epsilon:0 --verts:#all
				else
				(
					--bestCloudAxis pp project:n space:#3d --verts:#all
					bx = bestCloudBBox pp
					choice bx bx.transform (Matrix3 1)
				)
			)
			else
			(
				getnodelocalbbox3 n
			)
		),		
		fn workspaceCallback event handles nodes: force:off =   
		(
			bx = getSubObjectAxis()
			tm = if isbbox3 bx then bx.transform else bx 
			if ismatrix3 tm do with redraw off
			(
				workingpivot.settm tm
				commandmode.reset()
				--toolmode.commandmode = toolmode.commandmode
				--workingpivot.SetPinWorkingPivot on

				--ensure_redraw_
				--notifydependents selectednode partid:#display
			)
			--xformat_ xtime_ event tm
		),	

		fn disablePivotCallbacks = 
		(
			inodeevents.deletecallback pivot_cb	
		),
		fn enablePivotCallbacks = 
		(
			disablePivotCallbacks()
			pivot_cb = NodeEventCallback callbackBegin:workspaceCallback delay:0 --geometryChanged:workspaceCallback mouseUp:on	
		),
		
		
		fn findNodeByPrint str nodes: = 
		(
			if nodes == unsupplied do nodes = objects
			token = " @ "
			ss = splitstring str space:token
			first = undefined
			for node in nodes where spass ss[1] (splitstring (node as string) token)[1] do exit with first = node 
			first
		),	

		mapped fn tagNode node id: = if istrueobject node do
		(
			if id == unsupplied do id = tool_name
			_id = crc16 id 
			appdata.setint64 node _id id:_id undo:thehold_holding_
		),	
		mapped fn untagNode node id: = if istrueobject node do
		(
			if id == unsupplied do id = tool_name
			_id = crc16 id 
			appdata.removedata node id:_id
		),	
		fn findNodesByTag nodes: id: = 
		(
			if nodes == unsupplied do nodes = objects
			if id == unsupplied do id = tool_name
			_id = crc16 id
			for node in nodes where appdata.getint64 node id:_id == _id collect node
		),	

		mapped fn setProxyTag proxy node id: = if istrueobject proxy and istruenode node do
		(
			if id == unsupplied do id = proxy_tag
			appdata.setint64 proxy (inodehandle_ node) id:id undo:thehold_holding_
		),	
		fn getProxyTag proxy id: = if istrueobject proxy do
		(
			if id == unsupplied do id = proxy_tag
			if isset (handle = appdata.getint64 proxy id:id) do inodehandle_ handle
		),	
		mapped fn removeProxyTag proxy id: = if istrueobject proxy do
		(
			if id == unsupplied do id = proxy_tag
			appdata.removedata proxy id:id
		),	
		fn isTaggedProxy proxy id: = istruenode proxy and
		(
			if id == unsupplied do id = proxy_tag
			isset (appdata.getint64 proxy id:id)
		),
		fn findProxysByProxyTag nodes: id: = 
		(
			if nodes == unsupplied do nodes = objects
			if id == unsupplied do id = proxy_tag
			for proxy in nodes where isset (appdata.getint64 proxy id:id) collect proxy
		),
		fn findNodesByProxyTag nodes: id: = 
		(
			if nodes == unsupplied do nodes = objects
			if id == unsupplied do id = proxy_tag
			for proxy in nodes where isset (handle = appdata.getint64 proxy id:id) collect 
			(
				node = inodehandle_ handle
				choice (istruenode node) node dontcollect
			)
		),	
		
		fn tryFindNodeReference prop = 
		(
			-- prop = #project_target
			
			x = iniops.get ini_file #dts_proxy_zone prop
			node = findnodebyprint x
			if istruenode node do prop_ this prop node 
		),
		
		top_menu = 
		(
			rcmenu top_menu
			(
				local owner = if owner != undefined do owner
				local d = if defined d do d
										
				fn enable0 = off
				fn enable1 = off

				fn validTarget = istruenode (prop_ owner #project_target)
				
				submenu "File"
				(
					menuitem load_presets "Load Presets..." enabled:off
					separator sp_0
					menuitem cancel "Exit"
				)

				submenu "Edit" 
				(
					menuitem select_skin_bones "Select Skinnable Bones" enabled:off
				)
				submenu "Tools"
				(
					menuitem align_target_plane "Align Target" enabled:(validTarget()) 
					menuitem align_view_xy_plane "Align View XY\t- Z(+CTRL)" enabled:(validTarget()) 
					menuitem align_view_yx_plane "Align View YX\t- Z(+CTRL)" enabled:(validTarget()) 
					separator sp_02
					submenu "Proxy Ref Controls"
					(
						menuitem tag_proxy_temps "Set Tag" enabled:on
						menuitem untag_proxy_temps "Clear Tag" enabled:on
						menuitem sel_proxy_temps "Select" enabled:on
						menuitem del_proxy_temps "Delete" enabled:on
						separator sp_21
						menuitem debug_proxy_dummys "Enable Debug Dummys" checked:(prop_ owner #debug_proxy_dummys)
						menuitem debug_proxy_points "Enable Debug Points" checked:(prop_ owner #debug_proxy_points)
					)
				)
				submenu "Settings" 
				(
					menuitem vertex_ticks "Show Vertex Ticks" checked:owner.vertex_ticks
					menuitem vertex_numbers "Show Vertex Numbers" checked:owner.vertex_numbers
					menuitem backface_cull "Backface Cull" checked:owner.backface_cull
					separator sp_03
					menuitem debug_mode "Debug Mode" checked:(prop_ owner #debug_mode)
					menuitem debug_temp "Debug Objects" checked:(any_ true owner.debug_proxy_dummys owner.debug_proxy_points)
				)
				
				on align_target_plane picked do undo "Align Target" on
				(
					d.alignTarget alt:shift_
				)
				on align_view_xy_plane picked do undo "Align View" on
				(
					d.alignView flip:false
				)
				on align_view_yx_plane picked do undo "Align View" on
				(
					d.alignView flip:true
				)
				
				on vertex_ticks picked do toggle_ &owner.vertex_ticks
				on vertex_numvers picked do toggle_ &owner.vertex_numbers
				on backface_cull picked do toggle_ &owner.backface_cull
				
				on debug_temp picked do 
				(
					state = any_ true owner.debug_proxy_dummys owner.debug_proxy_points
					owner.debug_proxy_dummys = owner.debug_proxy_points = toggle_ &state
					d.proxy_controls_bt.state = state
				)
				
				on tag_proxy_temps picked do undo "Tag PROXY temps" on 
				(
					owner.tagnode selectednodes
				)
				on untag_proxy_temps picked do undo "UnTag PROXY temps" on 
				(
					owner.untagnode selectednodes
				)
				on sel_proxy_temps picked do undo "Select PROXY temps" on 
				(
					setnodeselection (owner.findnodesbytag())
				)
				on del_proxy_temps picked do undo "Delete PROXY temps" on 
				(
					delete (owner.findnodesbytag())
				)

				on debug_mode picked do toggle_ &owner.debug_mode
				on debug_proxy_dummys picked do 
				(
					toggle_ &owner.debug_proxy_dummys
					state = any_ true owner.debug_proxy_dummys owner.debug_proxy_points
					d.proxy_controls_bt.state = state
				)
				on debug_proxy_points picked do 
				(
					toggle_ &owner.debug_proxy_points
					state = any_ true owner.debug_proxy_dummys owner.debug_proxy_points
					d.proxy_controls_bt.state = state
				)
				
				on load_presets picked do
				(
				)
				
				on cancel picked do if defined owner do owner.destroy()
			)
		),
		
		fn createSplineShape pp name: transform: knot:#corner type:#line wirecolor: = 
		(
			spline = splineShape name:name wirecolor:wirecolor transform:transform
			addnewsplineshape spline pp close:on single:on type:knot
			updateShape spline
			
			spline
		),
		fn cutSplineShape sp params shape:1 = 
		(
			knots = point4tab()
			for p in params do  
			(
				x = findSplineShapeSegment sp p shape:shape interpolate:on
				k = refineSplineShapeSegment sp x[1] shape:shape index:x[2] interpolate:on update:on
				append knots (aspoint4 x k)	
			)
			breakSplineShape sp knots.b shape:shape update:on
		),
		
		/*
		(type ==-1) ? init_hull3D(pts, hull) :
		(type == 0) ? init_hull3D_compact(pts, hull) : 
		(type == 1) ? NewtonApple_Delaunay(pts, hull, false) : 
		NewtonApple_hull_3D(pts, hull);
		*/		
		fn makeConvexHull pp node: name:#CONVEX_HULL points:#all type:-1 check:on =
		(
			if type == -1 then
			(
				hull_mesh = computeQHull pp numverts:&vv numfaces:&ff check:check
			)
			else
			(
				DelaunayHull3D pp mesh:&hull_mesh type:type check:check
			)
			
			basepolyobject mesh:hull_mesh copy:off node:on name:name
		),			
			
		dialog =
		(
			rollout dialog "" width:191 autoLayoutOnResize:on
			(
				local owner = owner
				local cui_tool = #(#cui_dock_left, #cui_dock_right, #cui_floatable, #cui_handles)
				
				local dlg_color = colorrefs.getmaxcolor #dialog

				local rd_ = uiscale_ 2.6
				local sz_ = uiscale_ 2.0
				
				local sp_w = 44
				local lb_w = 60
				local dd_w = 114
				
				local use_verts_bm = @":/CommandPanel/Modify/ModifierStack/VertexStack"
				local use_faces_bm = @":/CommandPanel/Modify/ModifierStack/FaceStack"
				
				local work_pivot_bm = @":/MainUI/PlaceWPivotInView" --:/MainUI/PlaceWPivotInViewAndAlign" -- :/MainUI/ExposeTransform :/MainUI/PlaceWPivotOnSurfaceAndAlign
				local auto_adjust_bm = @":/RenderFrameWindow/AutoRegionSelected"
				local pin_adjust_bm = @":/CommandPanel/Modify/PinStack"
				local proxy_controls_bm = @":/BlendedBoxMap/BoundingBox" 
				local aligned_box_bm = @":/SnapsControls/SnapToPivotToggle" -- :/StateSets/DisplayAsBox_24.png
				local align_target_bm = @":/MainUI/PlaceWPivotOnSurfaceAndAlign"
				local align_pivot_bm = @":/MainUI/CenterPivotToObject" 
				local project_target_bm = @":/MainUI/ExposeTransform" -- :/MainUI/MovePivotToOrigin -- :/MainUI/CenterPivotToObject -- :/MainUI/UseWorking(W)Pivot_24.png
				
				local align_view_bm = @":/MainUI/AlignToView" -- :/MainUI/CaptureCurrentTransforms_24.png
				local convex_hull_bm = @":/MainUI/Hedra" -- :/StateSets/EdgesOnly" :/MainUI/Box_24" --:/MainUI/ChamferBox" -- :/MainUI/Box_24.png
				local bound_box_bm = @":/StateSets/DisplayAsBox"
				
				local auto_edit_bm = @":/TrackView/Controllers/AssignControllers" --":/TrackView/Tools/ControllerProperties" --":/SnapsControls/SpinnerSnapToggle"
				local isolate_obj_bm = @":/StatusBar/StatusPanel/IsolateSelection"
				
				local use_borders_bm = @":/MainUI/EditBorders"
				local use_edges_bm = @":/MainUI/EditEdges"
				
				local absolute_bm = @":/EditUVW/AbsoluteTypeIn"
				local relatuve_bm = @":/EditUVW/AbsoluteTypeIn_on"
				
				local axis_x_bm = @":/AxisConstraints/ConstraintX"
				local axis_y_bm = @":/AxisConstraints/ConstraintY"
				local axis_z_bm = @":/AxisConstraints/ConstraintZ"				
				
				
				button tooltip_target_bt width:0 height:0 offset:[0,-RO_ROW_SPACING_] toolTip:"" visible:off enabled:off

				checkbutton low_labs_bt "LOW LABS" highlightColor:olivedrab width:88 height:32 align:#left offset:[-7,0] across:2 \
					checked:(owner.current_tool == 0) tip:0 description:"Experiment Zone"
				checkbutton proxy_park_bt "PROXY PARK" highlightColor:dullcyan width:88 height:32 align:#right offset:[9,0] \
					checked:(owner.current_tool == 1) tip:0 description:"Production Zone"
				
				timer sync_timer active:off interval:500
				
				label emp_00 height:0 offset:[0,0]
				gridcontrol gk offsets:#(28,28,28,28,-1,28,28,28) offset:[-2,0] width:-1 height:-RO_ROW_SPACING_
				

				group "Source: "
				(
					checkbutton use_verts_cb iconname:use_verts_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[1].y, emp_00.pos.y+24]
						tip:0 description:"Use Vertex Selection" checked:owner.use_verts

					checkbutton use_faces_cb iconname:use_faces_bm iconsize:[18,18] width:24 height:24 align:#right pos:[gk.grid[2].y, emp_00.pos.y+24]
						tip:0 description:"Use Face Selection" checked:(not owner.use_verts)

					radiobuttons source_type_rb labels:#("All", "Visible", "Selected") default:owner.source_type columns:1 state:1 align:#left offset:[dialog.width-92,-32] 
						offsets:#([0,0],[0,2],[0,4])
					checkbox per_element_ch " Per Element" checked:owner.per_element offset:[0,-20] enabled:off
				)

				group "Plane: "
				(
					label emp_10 height:-RO_ROW_SPACING_ offset:[0,0]

					checkbox reorient_ch " Swap Axis" checked:owner.reorient offset:[0,0]
						tip:0 description:"Switch between forward-facing and side-facing orientation"
					--checkbutton aligned_box_bt iconname:aligned_box_bm iconsize:[16,16] width:24 height:24 align:#right offset:[RO_SIDE_MARGIN_ - 28, -24]
						--highlightcolor:fadeblue checked:owner.aligned_box enabled:on
						--tip:0 description:"Using Centroid Method" visible:off

					button align_target_bt iconname:align_target_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[6].y - 2, emp_10.pos.y-4]
						highlightcolor:dullorange enabled:on
						tip:0 description:"Align Target To Source\n    RC\t- Flip Main Direction"

					button align_view_bt iconname:align_view_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[7].y - 2, emp_10.pos.y-4]
						highlightcolor:paleorange enabled:on
						tip:0 description:"Align View To Target\n +CTRL\t- Swap Front and Side\n    RC\t- Flip Side Direction"

					checkbutton work_pivot_bt iconname:work_pivot_bm iconsize:[16,16] width:24 height:24 pos:[gk.grid[8].y + 4, emp_10.pos.y-4]
						highlightcolor:pinkblush checked:owner.use_works_pivot enabled:on
						tip:0 description:"Use Oriented Workpivot"
						
					radiobuttons direction_type_rb labels:#("X", "Y", "Z") columns:1 default:owner.direction_type align:#left offset:[0,8] 
						offsets:#([0,0],[34,-15],[68,-30]) --enabled:(none_ owner.project_type 3 4)
					dropdownlist project_type_dd items:#("World", "Local", "Orient", "Project", "View", "Target") width:62 selection:owner.project_type align:#right offset:[4,-21] 
					-- Axis Mode: Orient -- Automatically aligns axes based on the object's geometry using the best-fit bounding box.
					

						
					pickbutton pick_project_target_bt "Pick Target ..." width:(dialog.width - RO_SIDES_PADDING_ - 30) align:#left offset:[-RO_SIDE_MARGIN_ + 30,2] 
						autoDisplay:on highlightcolor:dimorange --enabled:(owner.project_type == 6)
						tip:0 description:"Pick Project Target for Coordinate System\n   RC\t- Align Project Target"
					framecontrol pick_project_target_fr color:grey checkedColor:darkwhite state:off \
						radius:rd_ size:sz_ target:pick_project_target_bt enabled:pick_project_target_bt.enabled 

					button project_target_bt iconname:project_target_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[1].y, pick_project_target_bt.pos.y-1]
						tip:0 description:"Create Coordinate Target"  --highlightcolor:tangerine 
				)

				group "Bounding: "
				(
					label emp_11 height:-RO_ROW_SPACING_ offset:[0,0]
					
					checkbox oriented_ch checked:owner.oriented width:12 offset:[0,0]
					emptycontrol oriented_em " Oriented" align:#left pivot:#left width:60 pos:(oriented_ch.pos + [15,1])
						label:(choice owner.oriented lime gainsboro) checkcolor:lime state:owner.oriented 

					button create_hull_bt iconname:convex_hull_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[6].y - 2, emp_11.pos.y-4]
						highlightcolor:dullorange enabled:on
						tip:0 description:"Create Convex Hull\n   RC\t- Select Recent"

					button bounding_box_bt iconname:bound_box_bm iconsize:[18,18] width:24 height:24 align:#right pos:[gk.grid[7].y - 2, emp_11.pos.y-4]
						highlightcolor:paleorange enabled:on
						tip:0 description:"Create Bounding Box\n   RC\t- Select Recent"

					checkbutton proxy_controls_bt iconname:proxy_controls_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[8].y + 4, emp_11.pos.y-4]
						highlightcolor:warmcyan checked:(any_ true owner.debug_proxy_dummys owner.debug_proxy_points) enabled:on
						tip:0 description:"Toggle Proxy Controls\n   RC\t- Select Proxy Controls\n   RC+ALT\t- Delete Proxy Controls"
							
					emptycontrol tuning_lb text:"Searching Range:" caption:"Searching Range:" label:darkwhite width:100 align:#right pivot:#right offset:[-55,8] \ 
						tip:0 description:"Searching Range (1 == 180)\n   RC\t- Reset" enabled:owner.oriented
					spinner tuning_sp range:[0,1,owner.tuning] default:0.5 type:#float scale:0.01 fieldwidth:sp_w align:#right offset:[4,-19] \ 
						tip:0 description:"Clearance about Axis" enabled:owner.oriented
					checkbox axis_constrain_ch " Constrain" checked:owner.axis_constrain width:64 offset:[0,0] enabled:owner.oriented
					spinner orient_ratio_sp "Ratio: " range:[0,2,owner.orient_ratio] default:0 type:#float scale:0.1 fieldwidth:sp_w align:#right offset:[4,-19] \ 
						tip:0 description:"Orientaion Ratio" enabled:(owner.oriented and owner.axis_constrain)
					
					/*					
					button create_hull_bt "Convex Hull" width:(dialog.width/2 - RO_SIDES_MARGIN_ - 2) align:#left offset:[-RO_SIDE_MARGIN_,4]
						tip:0 description:"Bake Springs\n   RC\t- Active Baked Channel\n   RC+ALT\t- Active Spring Channel"
					button bounding_box_bt "Bound Box" width:(dialog.width/2 - RO_SIDES_MARGIN_ - 2) align:#right offset:[RO_SIDE_MARGIN_,-create_hull_bt.height - RO_ROW_SPACING_]
						tip:0 description:"Create Contour Line\n +ALT\t- Contour Curve"
					*/
					label end_00 height:-RO_ROW_SPACING_ offset:[0,2]
				)

				label emp_01 height:-RO_ROW_SPACING_ offset:[0,0]
				group "Base: "
				(
					checkbutton isolate_proxy_cb iconname:isolate_obj_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[1].y, emp_01.pos.y+20]
						tip:0 description:"Isolate Recent Proxy\n    RC\t- Toggle Source/Proxy Selection" checked:owner.auto_edit --highlightcolor:tangerine 
					checkbutton auto_edit_cb iconname:auto_edit_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[2].y, emp_01.pos.y+20]
						tip:0 description:"Auto Edit Segments" checked:owner.auto_edit --highlightcolor:tangerine 
		
					spinner extrude_segs_sp "U Segs: " range:[1,200,owner.length_segs] default:4 type:#integer fieldwidth:sp_w align:#right offset:[4,-34] \ 
						tip:0 description:"Proxy Height segments (along Curve)"
					spinner width_segs_sp "V Segs: " range:[1,200,owner.width_segs] default:4 type:#integer fieldwidth:sp_w align:#right offset:[4,0] \ 
						tip:0 description:"Flat Proxy width segments (across Curve)"
					label end_01 height:-RO_ROW_SPACING_ offset:[0,2]
				)
				group "Contour: "
				(
					checkbox adaptive_ch " Adaptive" align:#left offset:[0,0] tip:0 description:"Adaptive Shape" enabled:off
					radiobuttons shape_type_rb labels:#("Smooth", "Linear") default:owner.shape_type columns:1 offsets:#([0,0],[0,2]) align:#left offset:[dialog.width-92,-20] 
						tip:0 description:"Shape Type"

					checkbox optimized_ch " Optimize" checked:owner.optimized offset:[0,5]
					spinner optimize_percent_sp "Value: " range:[0,1,owner.optimize_percent] default:0.5 scale:0.01 type:#float fieldwidth:sp_w align:#right offset:[4,-19] \ 
						tip:0 description:"Optimize Spline Percent" enabled:owner.optimized
					
					button create_contour_shape_bt "Shape" width:(dialog.width/2 - RO_SIDES_MARGIN_ - 2) align:#left offset:[-RO_SIDE_MARGIN_,4] 
						tip:0 description:"Create Contour Spline\n Default\t- Use UP axis\n +CTRL\t- Swap Front and Side\n +ALT\t- Delete Recent Contour Curve"
						--tip:0 description:"<b>Create Contour Spline</b><br>
						--<b><pre> Default      </pre></b>Use UP axis<br>
						--<b><pre> +CTRL        </pre></b>Swap Front and Side<br>
						--<b><pre> +ALT         </pre></b>Delete Recent Contour Curve"

					button apply_crv_border_bt "CRV Border" width:(dialog.width/2 - RO_SIDES_MARGIN_ - 2) align:#right offset:[RO_SIDE_MARGIN_,-create_contour_shape_bt.height - RO_ROW_SPACING_]
						tip:0 description:"Apply CRV Border Modifier"

					--button use_borders_bt iconname:use_borders_bm iconsize:[16,16] width:24 height:24 align:#right pos:[gk.grid[1].y, create_contour_shape_bt.pos.y+24]
						--tip:0 description:"Snapshot Countour Shape" --highlightcolor:tangerine 
					button snap_border_shape_bt "Snapshot Border Shape" width:(dialog.width - RO_SIDES_PADDING_) align:#left offset:[-RO_SIDE_MARGIN_,2] 
						tip:0 description:"Create Border Shape\n +SHIFT\t- Find And Select Contour Edges\n +CTRL\t- Auto Find Contour Edges\n    RC\t- Select Contour"				
				)
				group "Proxy Mesh: "
				(
					checkbox flip_surface_ch " Flip" checked:owner.flip_surface width:40 offset:[0,0] visible:off
					checkbox smooth_surface_ch " Smooth" checked:owner.smooth_surface width:60 pos:flip_surface_ch.pos
						tip:0 description:"Smooth Proxy Mesh"
					emptycontrol refine_lb text:"Refine:" caption:"Refine:" label:darkwhite width:sp_w align:#right pivot:#right offset:[-63,-19] \ 
						tip:0 description:"Pre-Tessellate Mesh"
					dropdownlist refine_type_dd items:#("None", "Single", "Double") width:62 selection:owner.refine_type align:#right offset:[4,-21] 

					--checkbox flatten_ch " Flatten" checked:owner.flatten offset:[0,1] visible:off
					checkbutton axis_x_em iconname:axis_x_bm iconsize:[12,12] width:20 height:20 pivot:#middle align:#left offset:[-4,-2]
						highlightcolor:redwood checkedcolor:midgray state:(bool owner.use_axis.x) 
					checkbutton axis_y_em iconname:axis_y_bm iconsize:[12,12] width:20 height:20 pivot:#middle align:#left pos:(axis_x_em.pos + [22,0])
						highlightcolor:fern checkedcolor:midgray state:(bool owner.use_axis.y) 
					checkbutton axis_z_em iconname:axis_z_bm iconsize:[12,12] width:20 height:20 pivot:#middle align:#left pos:(axis_x_em.pos + [44,0])
						highlightcolor:airforce checkedcolor:midgray state:(bool owner.use_axis.z) 

					spinner enlarge_sp "Enlarge: " range:[-10,10,owner.enlarge] default:0 type:#float scale:(universeScale 0.01) fieldwidth:sp_w align:#right offset:[4,-21] \ 
						tip:0 description:"Proxy Height segments"					
					spinner scaling_sp "Scale: " range:[0,2,owner.scaling] default:1.0 type:#float scale:0.01 fieldwidth:sp_w align:#right offset:[4,0] \ 
						tip:0 description:"Proxy Height segments"
					
					checkbox trim_loft_ch " Trim" checked:owner.trim_loft width:40 offset:[0,-2]
						tip:0 description:"Exclude exact Boundaries to avoid zero-volume degeneracy"
					spinner tension_sp "Tension: " range:[0,1,owner.tension] default:0.0 type:#float scale:0.1 fieldwidth:sp_w align:#right offset:[4,-18] \ 
						tip:0 description:"Conform Tension"

					checkbox capped_ch " Caps" checked:owner.capped width:50 offset:[0,3]
						tip:0 description:"Add Start and End Caps"
					emptycontrol num_conforms_lb text:"Segments:" caption:"Segments:" width:lb_w height:20 align:#right pivot:#caption offset:[-55,-22] 
						label:(choice owner.sync_samples tangerine gainsboro) checkcolor:tangerine state:owner.sync_samples
						tip:0 description:"How many points to check Conform\n(more points - more accurate result)"
					spinner num_conforms_sp range:[2,100,owner.conform_points] default:10 type:#integer fieldwidth:sp_w align:#right offset:[4,-22] 
					
					button proxy_surface_bt "Surface" width:(dialog.width/2 - RO_SIDES_MARGIN_ - 2) 
						align:#left offset:[-RO_SIDE_MARGIN_,4] highlightcolor:dimorange
						tip:0 description:"Make Surface\n +ALT\t- Delete Recent Proxy\n   RC\t- Select Recent Proxy"
					button proxy_volume_bt "Volume" width:(dialog.width/2 - RO_SIDES_MARGIN_ - 2) 
						align:#right  offset:[RO_SIDE_MARGIN_,-proxy_surface_bt.height - RO_ROW_SPACING_]
						tip:0 description:"Make Solid Mesh\n +ALT\t- Delete Recent Proxy\n   RC\t- Select Recent Proxy"
				)
				
				label emp_03 height:-RO_ROW_SPACING_ offset:[0,-4] --pos:emp_02.pos

				emptycontrol info_line_lb text:"prompt..." offsets:[4,2,0,0] height:18 align:#left offset:[-RO_SIDE_PADDING_,4] width:(dialog.width - RO_SIDES_MARGIN_) \ 
					color:blackonyx label:midgray frame:dimgray highlightcolor:beige rightclick:on double:on keyboard:off visible:on \
					toolTip:"Info Line\n   RC\t- Set Clipboard"					
				label emp_04 height:-RO_ROW_SPACING_ offset:[0,2]

				label emp_02 height:-RO_ROW_SPACING_ pos:emp_01.pos
				group "Voxelize: "
				(
					label sep_02 height:20
					
					button create_boxel_bt "Boxel Mesh" width:(dialog.width/2 - RO_SIDES_MARGIN_ - 2) align:#left offset:[-RO_SIDE_MARGIN_,0] 
						tip:0 description:"Create Contour Line\n +ALT\t- Contour Curve" enabled:off
					button marching_bt "Marching" width:(dialog.width/2 - RO_SIDES_MARGIN_ - 2) align:#right offset:[RO_SIDE_MARGIN_,-create_boxel_bt.height - RO_ROW_SPACING_]
						tip:0 description:"Create Contour Line\n +ALT\t- Contour Curve" enabled:off
				)
				group "Skin: "
				(
					label sep_00 height:11
				)
				group "Cloth: "
				(
					label sep_01 height:11
				)
				label emp_06 height:-RO_ROW_SPACING_ offset:[0,-4] --pos:emp_02.pos
				group ""
				(
					pickbutton convert_proxy_bt "Convert" width:172 align:#right offset:[4,-6] highlightcolor:marengo
						tip:0 description:"Convert Cloth Simulation\n   RC\t- Active Baked Channel\n   RC+ALT\t- Active Spring Channel"
					framecontrol convert_proxy_fr color:gray checkedColor:litegray state:on \
						radius:rd_ size:sz_ target:convert_proxy_bt enabled:convert_proxy_bt.enabled 

					progressbar sim_progress_pb width:(dialog.width - RO_SIDES_MARGIN_*2 - 3) height:8 color:cadetblue align:#left offset:[-RO_SIDE_MARGIN_,2] radius:0 size:2 scale:on
					framecontrol sim_progress_fr color:dimgray target:sim_progress_pb smooth:on enabled:sim_progress_pb.enabled
				)
				
				fn getWorkingPoints node = 
				(
					case owner.source_type of
					(
						1: #all
						2: getMeshHiddenVerts selectednode invert:on
						3: if not owner.use_verts then
						(
							getmeshvertsusing node.mesh #selected level:#faces 
						)
						else 
						(
							#selected
						)
				  default: #all
					)
				)					
				
				on use_verts_cb changed state do 
				(
					this_control_.state = owner.use_verts = true
					use_faces_cb.state = false
				)
				on use_faces_cb changed state do 
				(
					use_verts_cb.state = owner.use_verts = false
					this_control_.state = true
				)
				
				fn getProjectTM node: alt:false = 
				(
					tm = undefined
					dir = owner.direction_type
					
					if owner.project_type == 1 then
					(
						tm = case dir of 
						(
							1: matrix3_ x_axis
							2: matrix3_ y_axis
							3: matrix3_ z_axis
						)
					)
					else
					(
						tm = case owner.project_type of 
						(
							2: -- LOCAL 
							(
								if node == unsupplied do node = selectednode
								if istruenode node do
								(
									matrix3_ (getnodebbox3 node align:on).transform	
								)
							)
							3: -- ORIENT
							(							
								if node == unsupplied do node = selectednode
								if istruenode node do
								(
									points = getWorkingPoints node
									pp = getpointpositions node points type:#point3
									if isset pp then
									(
										lock = choice owner.oriented [0,0,0] [1,1,1]	
										bx = bestCloudbbox pp lock:lock align:on scale:off project:project --order:#x --order:(dir - 1)
										bx.transform = prerotatexyz bx.transform 180 0 0 order:#xyz 
									)
									else matrix3_ (getnodebbox3 node align:on).transform	
								)
							)
							4: -- PROJECT
							(							
								if node == unsupplied do node = selectednode
								if istruenode node do
								(
									points = getWorkingPoints node
									pp = getpointpositions node points type:#point3
									if isset pp and pp.count > 2 then
									(
										bx = findBoundingBox3d pp epsilon:0
										reorientBBox3 bx order:#z
										bx.transform --= prerotatexyz bx.transform 0 90 0 order:#xyz

									)
									else matrix3_ (getnodebbox3 node align:on).transform	
								)
							)
							5: -- VIEW
							(
								--dir = 2
								VIEW_INV_TM_ --VIEW_DIR_
							)
							6: -- TARGET
							(
								--dir = 3
								prop_ owner.project_target #transform
							)
						)
						tm = choice tm (Matrix3 1)
						
						if  owner.project_type > 2 do case dir of
						(
							1: tm = prerotatexyz tm 0 0 90 order:#xyz
							2: tm = prerotatexyz tm 0 180 0 order:#xyz
							3: tm = prerotatexyz tm -90 0 0 order:#xyz
						)
					)
					tm
				)


				local axis_cc = #(axis_x_em, axis_y_em, axis_z_em)
				
				fn updateAxisUI id: state: quary:off all:false = 
				(
					if not ispoint3 owner.use_axis do owner.use_axis = [1,1,1]
					if ispoint3 state do owner.use_axis = state
					if unset id then
					(
						map_ updateAxisUI id:#{1..3} maparg:#id
					)
					else	
					(
						bt = axis_cc[id]
						if (state == #toggle) do state = owner.use_axis[id] = choice owner.use_axis[id] 0 1
						if all then
						(
							owner.use_axis = aspoint3 state
							map_ updateAxisUI id:#{1..3} maparg:#id
						)
						else 
							ensure_ bt #state (bool owner.use_axis[id])  
					)
				)

				fn makeAxisState state = 
				(
					choice ctrl_ #toggle (choice alt_ [0,0,0] state)
				)
				
				on axis_x_em changed state do updateAxisUI id:(choice ctrl_ 1 0) state:(makeAxisState [1,0,0])
				on axis_y_em changed state do updateAxisUI id:(choice ctrl_ 2 0) state:(makeAxisState [0,1,0])
				on axis_z_em changed state do updateAxisUI id:(choice ctrl_ 3 0) state:(makeAxisState [0,0,1])

				on axis_x_em rightclick do updateAxisUI state:[0,0,0]
				on axis_y_em rightclick do updateAxisUI state:[0,0,0]
				on axis_z_em rightclick do updateAxisUI state:[0,0,0]

				
				fn alignTarget alt:false flip:false = if istruenode (t = owner.project_target) do 
				(
					node = selectednode
					
					project = getProjectTM alt:alt
					if ctrl_ do prerotatez project 90 -- change Y to X
					if flip do prerotatex project 180 -- flip z

					--project.pos = node.center
					t.transform = project
				)
				fn alignView flip:false = if istruenode (t = owner.project_target) do
				(
					tm = prerotatexyz t 0 0 0
					if alt_ 	do prerotatez tm 90
					if shift_ 	do prerotatex tm 90
					if ctrl_ 	do prerotatey tm 90

					if flip 	do prerotatez tm 180
				
					tm = inverse tm
					
					iview.undoBegin undoable:on
					if viewport.getType() != #view_iso_user do 
					(
						iview.undoBegin undoable:on
						viewport.setType #view_iso_user
						iview.undoAccept()
					)
					setViewportTM tm
					iview.undoAccept()
				)

				on align_target_bt click arg do press_this_
				on align_target_bt clicked arg do undo "Align Target" on
				(
					alignTarget alt:shift_ flip:(arg == #right)
					ensure_redraw_
					release_this_
				)
				on align_view_bt click arg do press_this_
				on align_view_bt clicked arg do undo "Align View" on
				(
					if (arg == #right) then
					(
						alignView flip:on
						--choice alt_ (max view redo) (max views undo)
					)
					else
					(
						alignView flip:off
					)
					ensure_redraw_
					release_this_
				)
				
				local hull2D_methods = #(QuickHull2D.QuickHull, QuickHull2D.GrahamScan, QuickHull2D.GiftWrap, QuickHull2D.MonotoneChain) 
				
				on aligned_box_bt changed state do 
				(
					owner.aligned_box = state
				)
				on proxy_controls_bt changed state do 
				(
					owner.debug_proxy_dummys = owner.debug_proxy_points = state
				)
				on proxy_controls_bt rightclick do undo "Act PROXY temps" on 
				(
					proxy_cc = owner.findnodesbytag()
					if isset proxy_cc do 
					(
						(choice alt_ delete select) proxy_cc
						ensure_redraw_
					)						
				)
				
					
				on per_element_ch changed state do toggle_ &owner.per_element
				on reorient_ch changed state do toggle_ &owner.reorient
				
					
				fn slicePointCloud pp samples:3 project:true safe:false = 
				(
					num = samples + 1
					
					tm = asmatrix3 project			
					cc = pp as point3tab * inverse tm
					
					mn = cc.min
					mx = cc.max
					sz = (mx.z - mn.z)
					vv = #()
					
					--if not owner.trim_loft do num -= 2
						
					for p in cc do 
					(
						k = (p.z - mn.z) * num / sz + 0.5
						k = round k
						k = min_ num (max_ 1 k)
						--append xx k
						if isnotset vv[k] do vv[k] = point3tab()
						append vv[k] p
					)
					
					z0 = mn.z
					z1 = mx.z
					
					vv = uset_ vv
					for v in vv where isset v do 
					(
						z = v.center.z
						--if owner.flatten do 
						QuickHull2D.QuickHull v value:v
						v.z = z
						--vv[vv.n] = (v *= tm)
					)

					if not owner.trim_loft do
					(
						vv[1].z = mn.z
						vv[-1].z = mx.z
					)

					/*
					if not owner.trim_loft do
					(
						vv0 = copy vv[1]
						vv0.z = mn.z
						
						vv1 = copy vv[-1]
						vv1.z = mx.z
						
						insertitem vv0 vv.value 1 
						append vv.value vv1
					)
					*/
					
					
					for v in vv where isset v do vv[vv.n] = (v *= tm)
								
					vv
				)
		
				fn orderShape sp ratio:0 reorient:off = in #place 
				(
					knots = point4tab (getsplineshapeknots sp single:on local:off)
					
					proj = asmatrix3 sp
					--prerotateX proj 90					
					
					if owner.aligned_box and false then 
						bx = findBoundingBox3d knots.xyz
					else
						bx = bestCloudbbox knots.xyz lock:[0,0,0] align:off scale:off ratio:-1 project:proj
					
					pp = if reorient then
					(
						vlerp bx.verts[#{1,3,5,7}] bx.verts[#{2,4,6,8}]
					)
					else 
					(
						vlerp bx.verts[#{1..4}] bx.verts[#{5..8}]
					)
					pp +=  proj.pos - bx.transform.pos
						
					if owner.debug_proxy_points do
					(
						pts = for p in pp collect point pos:p wirecolor:orenge
						owner.tagnode pts
					)
						
					sort knots pos:pp[1]
					makesplineshapefirst sp index:knots[1].w shape:1
					updatesplineshape sp
					
					knots = point4tab (getsplineshapeknots sp single:on local:off)
					if owner.debug_proxy_dummys do 
					(
						d = dummy boxsize:bx.scale transform:bx.transform
						owner.tagnode d
					)
					
					tags = point4tab() 
					for p in pp do 
					(
						sort knots pos:p start:pp.n
						append tags knots[pp.n]	
					)
					sort tags index:#w
					
					for k = tags[1].w to tags[2].w - 1 do setMaterialID sp 1 k 1 
					for k = tags[2].w to tags[3].w - 1 do setMaterialID sp 1 k 2 
					for k = tags[3].w to tags[4].w - 1 do setMaterialID sp 1 k 3 
					for k = tags[4].w to knots.count-0 do setMaterialID sp 1 k 4 
						
					updatesplineshape sp
					tags
				)
				
				on shape_type_rb changed state do owner.shape_type = state
				on optimized_ch changed state do optimize_percent_sp.enabled = owner.optimized = state
				on optimize_percent_sp changed val do 
				(
					owner.optimize_percent = val
					prop_ owner.recent_optispl #percent (val*100)
				)
				on oriented_ch changed state do 
				(
					oriented_em.state = oriented_ch.state = owner.oriented = state
					oriented_em.label = choice owner.oriented lime gainsboro
					axis_constrain_ch.enabled = tuning_lb.enabled = tuning_sp.enabled = state
					orient_ratio_sp.enabled = state and owner.axis_constrain
				)
				on oriented_em clicked arg do oriented_ch.changed (toggle_ &owner.oriented)
				on capped_ch changed state do owner.capped = state 
				on axis_constrain_ch changed state do 
				(
					orient_ratio_sp.enabled = (owner.axis_constrain = state) and owner.oriented 
				)
				on trim_loft_ch changed state do owner.trim_loft = state 
				on flatten_ch changed state do owner.flatten = state 
				on flip_surface_ch changed state do owner.flip_surface = state 
				on smooth_surface_ch changed state do owner.smooth_surface = state 
									
				on direction_type_rb changed state do 
				(
					owner.direction_type = state 
				)
				fn updatePlaneInfo = 
				(
					info_line_lb.text = case owner.project_type of
					(
						5: "VIEW|Z-DIR"
						6: "TARGET|Z-UP, Y-FRONT"
				  default: "Use X,Y,Z for Axis"	
					)
				)
				on project_type_dd selected sel do 
				(
					owner.project_type = sel 
					--ensure_ pick_project_target_bt #enabled (sel == 4)
					--ensure_ direction_type_rb #enabled (none_ sel 3 4) 
					
					updatePlaneInfo()
				)
				
				on pick_project_target_bt picked node do if istruenode node do owner.project_target = node
				on pick_project_target_bt rightclick do undo "Select" on xtry_ (select owner.project_target)
				
				on source_type_rb changed state do owner.source_type = state

				on extrude_segs_sp changed val do 
				(
					owner.length_segs = val
					if owner.sync_samples do num_conforms_sp.value = owner.conform_points = val
					clear_mouse_release_
				)
				on width_segs_sp changed val do 
				(
					owner.width_segs = val
					clear_mouse_release_
				)

				fn updateIsolateProxyUI init:off = 
				(
					if not IsolateSelection.IsolateSelectionModeActive() do 
					(
						ensure_ &isolate_proxy_cb.state false
					)
				)
				
				local pick_target_str = "Pick Target ..."
				fn updateProjectTargetUI init:off = 
				(
					--if init do pick_project_target_fr.state = istruenode pick_project_target_bt.object
						
					if not istruenode (node = pick_project_target_bt.object) then
					(
						ensure_ &pick_project_target_bt.text pick_target_str
						ensure_ &pick_project_target_fr.state off
					)
					else
					(
						ensure_ &pick_project_target_bt.text (asname node)
						ensure_ &pick_project_target_fr.state on
					)
				)
				
				on work_pivot_bt changed state ui:off do if isstruct_ (d = owner) do
				(
					d.disablePivotCallbacks()
					d.use_works_pivot = state
					WorkingPivot.UseMode = state
					if state do
					(
						d.enablePivotCallbacks()
						d.workspaceCallback #update undefined
					)
					if ui do work_pivot_bt.state = state
						
					iniops.set d.ini_file #dts_proxy_zone #use_works_pivot (d.use_works_pivot as string)
				)				
				on work_pivot_bt rightclick do 
				(
				)
				
				fn updateWorkingPivotUI init:off = 
				(
					if not WorkingPivot.UseMode do
					(	
						if owner.use_works_pivot do
						(
							work_pivot_bt.changed false ui:on
						)
					)
				)
				
				on sync_timer tick do
				(
					updateIsolateProxyUI()
					updateProjectTargetUI()
					updateWorkingPivotUI()
				)					
				
				on isolate_proxy_cb changed state do undo "Iso Proxy" on 
				(
					if not state then 
					(
						IsolateSelection.ExitIsolateSelectionMode()
					)
					else 
					(
						if owner.isTaggedProxy selectednode do owner.recent_proxy_ref.node = selectednode
						proxy = owner.recent_proxy_ref.node
						
						if istruenode proxy do select proxy
						IsolateSelection.EnterIsolateSelectionMode()					
					)
					ensure_redraw_
				)
				on isolate_proxy_cb rightclick do undo "Toggle Proxy" on 
				(
					local node = selectednode
					if owner.isTaggedProxy node then
					(
						selectnodes (owner.getProxyTag node) 
					)
					else
					(
						selectnodes owner.recent_proxy_ref.node 
					)
					ensure_redraw_
				)
				
				on auto_edit_cb changed state do undo "Bind Segments" on 
				(
					owner.auto_edit = state
					if owner.isTaggedProxy selectednode do owner.recent_proxy_ref.node = selectednode

					proxy = owner.recent_proxy_ref.node -- cureditnode
					if istruenode proxy do
					(
						extr = getnodemodifier proxy class:Extrude
						base = getbaseobject proxy
						
						if state then
						(
							if defined extr do 
							(
								c = extrude_segs_sp.controller = subAnimOps.applySubAnimController extr[#segments] (linear_float())
							)
							if defined base do 
							(
								segs = subAnimOps.getSubAnim base[#segments]
								sids = subAnimOps.getSubAnim base[#sides]
								
								if defined segs do width_segs_sp.controller = subAnimOps.applySubAnimController segs (linear_float()) 
								if defined sids do width_segs_sp.controller = subAnimOps.applySubAnimController sids (linear_float()) 
							)
						)
						else
						(
							if defined extr do subAnimOps.removeSubAnimController extr[#segments] 
							if defined base do 
							(
								subAnimOps.removeSubAnimController base[#segments] 
								subAnimOps.removeSubAnimController base[#sides] 
							)
							
							extrude_segs_sp.controller = undefined
							width_segs_sp.controller = undefined
						)
					)
				)
				
				on num_conforms_lb clicked arg do
				(
					c = this_control_
					if (arg == #right) then
					(
						num_conforms_sp.value = owner.conform_points = owner.length_segs
					)
					else
					(
						c.state = state = toggle_ &owner.sync_samples
						c.label = choice state tangerine gainsboro
						if state do num_conforms_sp.value = owner.conform_points = owner.length_segs
					)
				)
				on num_conforms_sp changed val do 
				(
					owner.conform_points = val
					if owner.sync_samples do extrude_segs_sp.value = owner.length_segs = val
				)
				on tension_sp changed val do owner.tension = val
				on refine_type_dd selected sel do owner.refine_type = sel
				on enlarge_sp changed val do owner.enlarge = val
				on scaling_sp changed val do owner.scaling = val
				on orient_ratio_sp changed val do owner.orient_ratio = val
				on tuning_sp changed val do owner.tuning = val
				on tuning_lb clicked arg do 
				(
					tuning_sp.value = owner.tuning = choice (arg == #right) 0.0 0.95
				)
				on proxy_surface_bt click arg do press_this_
				on proxy_volume_bt click arg do press_this_

				
				fn swapBBox bb axis:#xy dir:1 = --in #place 
				(
					bb *= RotateZMatrix (90*dir)
					bb.transform = prerotatez bb.transform (-90*dir) 
					bb
				)
				fn flipBBox bb axis:#xy dir:1 = --in #place 
				(
					bb *= RotateZMatrix (180*dir)
					bb.transform = prerotatez bb.transform (-180*dir)
					bb
				)
				
				fn isMeshBackfaced node = if ismeshnode node do
				(
					ff = getmeshfaceselection node #all
					back = 0
					for f in ff where (dot (getmeshfacenormal node f) VIEW_DIR_ < 0) do back += 1
					back > ff.count/2 	
				)					
				
				fn conformShape vv modi:cureditobject node:cureditnode project:z_axis lock:[1,1,0] flat:off reorient:on = 
				(
					t0 = timestamp()
					h0 = heapfree
					
					xxx = point3tab()
					xx = point3tab 4
					
					_enlarge = owner.use_axis * owner.enlarge
					_scaling = owner.scaling --unpacknormal (owner.use_axis * packnormal (owner.scaling - 1)) + 1 
					_method = ibool owner.axis_constrain
	
					prev = bbox3 project

					for v in vv where isset v do in #place
					(
						target = prev						
						bx = bestCloudbbox v lock:lock align:off scale:off ratio:owner.orient_ratio project:project target:target method:_method --order:#x --result:&res--align:on
						if defined bx do
						(	
							ang_x = angleVectors prev.transform[1] bx.transform[1] exact:off axis:prev.transform[3]	
							ang_z = angleMatrix3 prev.transform bx.transform axis:#xy	
							--if owner.debug_mode do xformat_ vv.i ang_x ang_z 

							if abs ang_z > 90 do 
							(
								flipBBox3 bx dir:ang_z
								ang_z = angleMatrix3 prev.transform bx.transform axis:#xy	
							)
							if abs ang_z > 45 do 
							(
								swapBBox3 bx dir:ang_z
							)
							
							prev = bx
							
							scaleBBox3 bx _scaling
							bx = bx ^ _enlarge
							--enlargeBBox3 bx owner.enlarge
							
							bp = bx.verts
							--xformat_ #points vv.i bp

							shift = project.pos - bx.transform.pos
	
							for k=1 to 4 do 
							(
								xx[k] = vlerp bp[k] bp[k+4] vv.u + shift
							)
							
							if flat do
							(
								if reorient then
								(
									xx[#{1,3}] = vlerp xx[1] xx[3]
									xx[#{2,4}] = vlerp xx[2] xx[4]
								)
								else
								(
									xx[#{1,2}] = vlerp xx[1] xx[2]
									xx[#{3,4}] = vlerp xx[3] xx[4]
								)
							)
							
							if owner.debug_proxy_dummys do
							(
								d = dummy boxsize:bx.scale transform:bx.transform
								owner.tagnode d
							)							
							if owner.debug_proxy_points do 
							(
								pts = for x in xx collect point size:2 pos:x wirecolor:orenge
								owner.tagnode pts
							)
							append xxx xx 
						)
					)

					t1 = timestamp()
					h1 = heapfree
					
					if iffd.isValid modi do
					(
						dim = iffd.getDimensions modi
						if (dim != [2,2,xxx.count/4]) do iffd.setDimensions modi [2,2,xxx.count/4] --update:on
						iffd.setPointPositions modi xxx absolute:on node:node
					)											
						
					t2 = timestamp()
					h2 = heapfree
					
					if owner.debug_mode do xformat_ "time...." (t1 - t0) (t2 - t1) #heap (h0 - h1) (h1 - h2)
					
					xxx
				)
				
				fn createBBoxes vv lock: ratio: project: = 
				(
					dms = for v in vv collect
					(
						b = bestCloudbbox v lock:lock align:off scale:off ratio:ratio project:project --$point001
						if isbbox3 b then dummy boxsize:b.scale transform:b.transform else dontcollect
					)
					owner.tagnode dms
				)

				fn tessellateSourceMesh node points:#all iterations:1 method:#edge value: = 
				(
					mesh = getnodemesh node
					verts = getmeshvertselection mesh verts:points
					num0 = verts.numberset
					faces = getmeshfacesusingvert mesh points
					numf_0 = getnumfaces mesh  
					tessellateMeshProgressive mesh faces:faces iterations:iterations method:method size:-1 escape:on result:&res
					
					pp = if isset res do 
					(
						numf_1 = getnumfaces mesh
						--xformat_ #verts verts #faces numf_0 numf_1
						
						new_faces = makebits numf_1 - makebits numf_0 + faces   
						new_verts = getmeshvertsusing mesh new_faces level:#faces
						
						points = getmeshvertselection mesh verts:new_verts
					
						getmeshverts mesh verts:points value:value
					)
					num1 = pp.count
					info_line_lb.text = stringformat "verts|%(%)" num1 num0
					
					freemesh mesh
					pp
				)
				
				fn createLoftObject node: type:#body flat:off create:on =   --with_suspend_except #(#undo, #message) \
				(
					local base = undefined
					local body = undefined
					
					project = getProjectTM()
					if owner.project_type == 5 do project = prerotatex VIEW_INV_TM_ 90

					_alt = ctrl_					
					
					points = getWorkingPoints node
					pp = point3tab()
					vv = getpointselection node verts:points  
					iterations = owner.refine_type - 1
					pp = if isset iterations then
					(
						faces = getmeshfacesusingvert node verts:points only:on
						getmeshfaces node faces:faces local:off value:pp 
						tesselateFaceTab pp tessellate:iterations value:pp
						--tessellateSourceMesh node points:points iterations:iterations value:pp
					)
					else
					(
						getpointpositions node points type:point3 value:pp
					)

					if isset pp do
					(
						info_line_lb.text = stringformat "points|% (%)" pp.count vv.numberset
						
						center = pp.center
						lock = choice owner.oriented [1,1,1 - owner.tuning] [1,1,1]
						
						if owner.aligned_box and false then 
							bx = findBoundingBox3 pp epsilon:0
						else
							bx = bestCloudBBox (getpointpositions node verts:points type:point3) align:off scale:off lock:[1,1,1] project:project 
						
						shift = project.pos - bx.transform.pos
						
						c0 = average (subtab bx.verts [0,4]) + shift
						c1 = average (subtab bx.verts [4,-1]) + shift
						
						ffd_segs = (choice owner.sync_samples owner.length_segs owner.conform_points)
						vv = slicePointCloud pp samples:ffd_segs project:project
						
						if owner.reorient then
						(
							v0 = average bx.verts[1] bx.verts[3] + shift
							v1 = average bx.verts[2] bx.verts[4] + shift
						)
						else
						(
							v0 = average bx.verts[1] bx.verts[2] + shift
							v1 = average bx.verts[3] bx.verts[4] + shift
						)
						
						solid = (type == #body)
						
						--setCommandPanelRedraw off parent:on undo:on
						(
							--lockCommandPanelUpdate undo:on redraw:on
							if create do
							(
								--suspendediting()
								if solid then 
								(
									body = NGon name:(uniquename #PROXY_) transform:bx.transform pos:c0 \
										nsides:owner.width_segs radius:(magnitude bx.scale.x bx.scale.y / 2) scribe:1  

									ext = Extrude capEnd:owner.capped capStart:owner.capped output:1 smooth:owner.smooth_surface amount:bx.scale.z segs:owner.length_segs
									applymodifier body ext	
									base = body
								)
								else
								(
									len = distance v0 v1 
									dir = choice owner.reorient 1 2
									base = LineVector name:(uniquename #PROXY_) transform:bx.transform pos:c0 segments:owner.width_segs dir_axis:dir length:len origin:0.5
									ext = Extrude capEnd:0 capStart:0 output:1 smooth:owner.smooth_surface amount:bx.scale.z segs:owner.length_segs
									applymodifier base ext								
						
									body = base --NGon name:(uniquename #TEMP_BODY) transform:bx.transform pos:c0 nsides:4 radius:(distance v0 v1 / 2) scribe:1  

									if (base != body) do
									(
										temp_ext = Extrude capEnd:0 capStart:0 output:1 smooth:off amount:bx.scale.z segs:1
										applymodifier body temp_ext
									)
								)

								_tension = (choice solid owner.tension 0.5)/0.02
								
								ffd = FFDBox deformType:1 tension:_tension
								applymodifier body ffd redraw:off exact:off

								/*
								cbox = getModContextBBox body ffd 
								cmat = getModContextTM body ffd 

								if (base != body) and false do
								(
									applymodifier base ffd
									setModContextBBox base ffd cbox.min cbox.max 
									setModContextTM base ffd cmat 
								)
								*/
								
								owner.recent_extrude = getnodemodifier base class:Extrude
								owner.recent_ffddmod = getnodemodifier base class:FFDBox
								owner.recent_proxy = base
								owner.recent_proxy_ref.node = base 

								--resumeediting()
								updateAnimated()
							)

							xxx = conformShape vv modi:ffd node:body lock:lock project:project flat:flat reorient:owner.reorient
			
							if create and not solid and (base != body) do
							(
								applymodifier base ffd
								delete body
							)
							
							--unlockCommandPanelUpdate undo:on redraw:on
						)
					)
					base
				)
				
				fn deleteRecentProxy = 
				(
					proxy_cc = owner.findnodesbytag()
					if isset proxy_cc do 
					(
						(choice alt_ delete select) proxy_cc
					)
					if istruenode (proxy = owner.recent_proxy_ref.node) do delete proxy					
					ensure_redraw_
				)
				on proxy_volume_bt clicked arg do undo "Proxy Volume" on if isgeometry (node = selectednode) do 
				(
					MXS_ESCAPABLE_ = off

					with redraw off
					(
						if (arg == #left) and ismeshnode node do --with_suspend_except #(#undo, #message) \
						(	
							if alt_ do deleteRecentProxy() 
							base = createLoftObject node:node type:#body flat:off
							owner.setProxyTag base node
						)	
						
						if (arg == #right) do undo "Recent Proxy" on if istruenode (proxy = owner.recent_proxy_ref.node) do 
						(
							if alt_ then delete proxy
							else 
							(
								max modify mode
								selectednode = proxy
							)
						)
					)	

					MXS_ESCAPABLE_ = on

					ensure_redraw_
					release_this_
				)
				
				on proxy_surface_bt clicked arg do undo "Proxy Surface" on if isgeometry (node = selectednode) do 
				(
					if alt_ do deleteRecentProxy() 

					MXS_ESCAPABLE_ = off

					with redraw off
					(
						if (arg == #left) and ismeshnode node do --with_suspend_except #(#undo, #message) \
						(	
							flip = ctrl_
							base = createLoftObject node:node type:#surface flat:on
							owner.setProxyTag base node
							
							if ismeshnode base do
							(
								if isset (xor_ (isMeshBackfaced base) flip) do xtry_ (base.baseobject.reversed = on)
							)
						)	
						
						if (arg == #right) do undo "Recent Proxy" on if istruenode (proxy = owner.recent_proxy_ref.node) do 
						(
							if alt_ then delete proxy
							else 
							(
								max modify mode
								selectednode = proxy
							)
						)
					)
					
					MXS_ESCAPABLE_ = on

					ensure_redraw_
					release_this_
				)				

				on hull2D_type_dd selected sel do owner.hull2D_type = sel
				on hull3D_type_dd selected sel do owner.hull3D_type = sel

				fn createContourShape node: name: project:VIEW_TM_ align:true knot:#corner type:#line wirecolor:orenge = 
				(
					if node == unsupplied do node = selectednode
					if isgeometry node do in #place
					(
						points = getWorkingPoints node
						pp = getpointpositions node verts:points type:point3
						bx = bestCloudBBox pp align:off scale:off lock:[1,1,1] project:project
						
						--project = asmatrix3 project inverse:on

						swapxz = (none_ owner.project_type 4 5)
						center = pp.center
						xtm = choice swapXZ (rotateymatrix 90) (matrix3 1) 
						tm = xtm * bx.transform 
						pp *= inverse tm
						
						xx = case owner.hull2D_type of 
						(
							1: QuickHull2D.QuickHull pp
							2: QuickHull2D.GrahamScan pp
							3: QuickHull2D.GiftWrap pp
							4: QuickHull2D.MonotoneChain pp
						)

						xx *= xtm

						if isset xx do
						(
							sp = owner.createSplineShape xx name:name transform:bx.transform knot:knot type:type wirecolor:wirecolor
							centerpivot sp
							--alignnodepivot $[1] $[2]
							
							if align do
							(
								d = center * inverse tm
								s = choice swapXZ [1,0,0] [0,0,1]
								in coordsys local move sp (d*s)
							)
							sp
						)
					)					
				)
				
				fn alignSplineShape sp = 
				(
					project = getProjectTM()
					
					pp = getsplineshapeknots sp single:on local:off
					bx = bestCloudBBox pp align:off scale:off lock:[1,1,1] project:project
					alignnodepivot sp bx.transform 
					sp.transform
				)
				
				fn optimizeShape sp corner:off = 
				(
					num = max_ 4 (numsplineshapeknots sp * owner.optimize_percent)
					opt = Normalize_Spline2 NormalizeType:1 numKnots:num SimpleInterpolation:1 UseStraightSegments:corner
					applymodifier sp opt
					convertToSplineShape sp
				)
				
				on create_contour_shape_bt click arg do press_this_
				on create_contour_shape_bt clicked arg do 
				(
					with redraw off
					(
						if (arg == #left) do undo "Contour Shape" on
						(
							node = selectednode
							knot = choice (owner.shape_type == 2) #corner #bezier 
							type = #curve
							
							project = getProjectTM()
							project = prerotatexyz project 0 90 0 order:#xyz
														
							case owner.project_type of
							(
								3: project = prerotatexyz project -90 0 0 order:#xyz
								4: project = prerotatexyz project 0 -90 0 order:#xyz
								5: project = prerotatexyz project -90 0 0 order:#xyz
								6: project = prerotatexyz project 0 90 -90 order:#xyz
							)							
							
							if ctrl_ do prerotatey project 90 -- change Y to X
							
							local sp = undefined 
							local sps = #()
							
							sp = createContourShape node:node name:(uniquename #CONTOUR_) project:project align:on knot:knot type:type
							owner.setProxyTag sp node
							
							if owner.optimized do 
							(
								optimizeShape sp corner:(owner.shape_type == 2)
							)
							sps = #(sp)
							
							for sp in sps where isshape sp do 
							(
								alignSplineShape sp 
								tags = orderShape sp reorient:(owner.reorient or shift_)
								
								owner.recent_shape = sp
								owner.recent_proxy_ref.node = sp
								
								sp.vertexTicks = owner.vertex_ticks
								sp.backFaceCull = owner.backface_cull
								showSplineShapeVertNumbers sp owner.vertex_numbers
							)						
						)
					)

					if (arg == #right) do undo "Recent Shape" on if istruenode (node = owner.recent_shape) do 
					(
						if alt_ then delete node
						else selectednode = node
					)
					ensure_redraw_
					release_this_
				)
				on snap_border_shape_bt click arg do press_this_
				on snap_border_shape_bt clicked arg do 
				(
					with redraw off
					(
						if (arg == #left) do undo "Contour Shape" on
						(
							node = selectednode
							knot = choice (owner.shape_type == 2) #corner #bezier 
							type = #curve
							
							project = getProjectTM()

							local sp = undefined 
							local sps = #()
							
							faces = case owner.source_type of
							(
								2: #visible
								3: #selected
						  default: #all
							)

							if shift_ then
							(
								ee = getPolyContourEdges node faces:faces
								setpolyselection node.baseobject ee level:#edge
							)
							else if ctrl_ then
							(
								faces = case owner.source_type of
								(
									2: #visible
									3: #selected
							  default: #all
								)

								ee = getPolyContourEdges node faces:faces
								--borders = getPolyEdgeLoops node edges:ee

								--borders = getPolyBorder node								
								--ee = bitarray()
								--for b in borders do join ee b.b
								
								sp = createpolyshape node edge:ee name:(uniquename #CONTOUR_) smooth:(owner.shape_type != 2)
							)
							else
							(
								sp = createpolyshape node name:(uniquename #CONTOUR_) smooth:(owner.shape_type != 2)
							)
							if isset sp do
							(
								owner.setProxyTag sp node
								
								if owner.optimized do 
								(
									optimizeShape sp corner:(owner.shape_type == 2)
								)

								sps = choice (isArray sp) sp #(sp)
								pp = point3tab()
								for sp in sp do 
								(
									append pp (getsplineshapeknots sp single:on local:off)
								)
								bx = bestCloudBBox pp align:off scale:off lock:[1,1,1] project:project
								alignnodepivot sps bx.transform
							)

							for sp in sps where isshape sp do 
							(
								--alignSplineShape sp 
								--tags = orderShape sp reorient:(owner.reorient or shift_)
								
								owner.recent_shape = sp
								owner.recent_proxy_ref.node = sp
								
								sp.vertexTicks = owner.vertex_ticks
								sp.backFaceCull = owner.backface_cull
								showSplineShapeVertNumbers sp owner.vertex_numbers
							)						
						)
					)

					if (arg == #right) do undo "Recent Shape" on if istruenode (node = owner.recent_shape) do 
					(
						if alt_ then delete node
						else selectednode = node
					)
					ensure_redraw_
					release_this_
				)
				
				on apply_crv_border_bt clicked arg do 
				(
					local sp = undefined
					if (arg == #left) do undo "CRV Border" on
					(
						sp = choice ctrl_ owner.recent_shape selectednode
						if isshapenode sp do
						(
							--tags = orderShape sp reorient:(owner.reorient or shift_) 

							owner.recent_shape = sp
							sp.vertexTicks = owner.vertex_ticks
							sp.backFaceCull = owner.backface_cull
							showSplineShapeVertNumbers sp owner.vertex_numbers
							
							owner.recent_optispl = getnodemodifier sp class:Normalize_Spline2
							
							crv_class = choice (ismxsclass CurveBorderMod) CurveBorderMod (exec_ #CurveBorderMod)
							crv = getnodemodifier sp class:crv_class
							if notdefined crv do
							(
								max modify mode
								--modPanel.addModToSelection (CurveBorderMod ()) ui:on
								
								crv = crv_class lengthsegs:owner.length_segs widthsegs:owner.width_segs 
								applymodifier sp crv
							)
							
							if noalt_ and not isnodeselected sp do select sp

							complete_redraw_
						)
					)
					if (arg == #right) do undo "Recent Shape" on if istruenode (node = owner.recent_shape) do 
					(
						if alt_ then delete node
						else selectednode = node
						
						ensure_redraw_
					)
				)
				
				on create_hull_bt click arg do press_this_
				on create_hull_bt clicked arg do 
				(
					if (arg == #left) do undo "Create Hull" on, redraw off 
					(
						node = selectednode
						type = -1

						points = getWorkingPoints node
						pp = getpointpositions node points local:on type:#point3
						if isset pp do
						(
							center = pp.center
							owner.recent_hull = owner.makeConvexHull pp name:(uniquename #CONVEX_HULL_) type:type check:on
							owner.recent_hull.transform *= node.transform
						)
					)
					if (arg == #right) do undo "Recent Hull" on if istruenode (node = owner.recent_hull) do 
					(
						if alt_ then delete node
						else selectednode = node
						
					)
					ensure_redraw_
					release_this_
				)
				
				on project_target_bt click arg do press_this_
				on project_target_bt clicked arg do 
				(
					if (arg == #left) do undo "Create Coord Target" on
					(
						if istruenode (node = selectednode) do
						(
							project = getProjectTM()
							if shift_ do prerotatez project 90 -- change Y to X

							
							points = getWorkingPoints node
							pp = getpointpositions node points type:#point3
							if isset pp do
							(
								center = pp.center
								if owner.aligned_box and false then
								(
									bx = findBoundingBox3 pp epsilon:0
								)
								else
								(
									lock = choice owner.oriented [0,0,0] [1,1,1]
									bx = bestCloudbbox pp lock:lock align:off scale:off ratio:owner.orient_ratio project:project
								)
								obj = owner.project_target = point name:(uniquename #PROJECT_) size:(maxcomponent bx.scale) transform:bx.transform \
									axistripod:on cross:on wirecolor:(random gray white)
								owner.setProxyTag obj node
								pick_project_target_bt.object = owner.recent_proxy_ref.node = obj
								pick_project_target_fr.state = on
							)
						)
					)
					if (arg == #right) do undo "Align Target" on 
					(
						handler = rolloutops.getControlHandler align_target_bt #clicked
						handler #left
					)
					ensure_redraw_
					release_this_
				)
				
				on bounding_box_bt click arg do press_this_
				on bounding_box_bt clicked arg do 
				(
					if (arg == #left) do undo "Create Bound Box" on
					(
						if istruenode (node = selectednode) do
						(
							project = getProjectTM()
							if shift_ do prerotatez project 90 -- change Y to X

							
							points = getWorkingPoints node
							pp = getpointpositions node points type:#point3
							if isset pp do
							(
								center = pp.center
								if owner.aligned_box and false then
								(
									bx = findBoundingBox3 pp epsilon:0
								)
								else
								(
									lock = choice owner.oriented [0,0,0] [1,1,1]
									bx = bestCloudbbox pp lock:lock align:off scale:off ratio:owner.orient_ratio project:project
								)
								owner.recent_bbox = dummy name:(uniquename #BBOX_) boxsize:bx.scale transform:bx.transform
								--owner.recent_bpnt = point name:(uniquename #BPOINT_) tripodaxis:on transform:bx.transform wirecolor:green
								owner.tagnode owner.recent_bbox
							)
						)
					)
					if (arg == #right) do undo "Recent BBox" on if istruenode (node = owner.recent_bbox) do 
					(
						if alt_ then delete node
						else selectednode = node
					)
					ensure_redraw_
					release_this_
				)


				
				on convert_proxy_bt pressed do undo "Proxy Ops" on
				(
					if istruenode (proxy = owner.recent_proxy_ref.node) do 
					(
						selectednode = proxy
						ensure_redraw_
					)
				)
			
				local tool_controls = #(low_labs_bt, proxy_park_bt)
				local tool_rollouts = #(#{1..6}, #{1..3,7..10})
				
				fn setCurrentTool id: =
				(
					if id == unsupplied then id = owner.current_tool else owner.current_tool = id
					owner.current_tool = id = if isnumber id then (clamp id min:0 max:1) else 0 

					rolbits = clearbits (rolloutOps.numGroups owner.dialog)		
					
					for k=1 to tool_controls.count do
					(
						act = ((k-1) == id)
						ICustButton.setCheck tool_controls[k] act exact:off
						if act do rolbits += tool_rollouts[k]
					)
					for k=1 to rolbits.count do
					(
						cc = rolloutOps.getGroup owner.dialog k
						cc = filter_ cc fn:(fn _ c = prop_ c #visible def:true)
						hwnds = fmap_ getcontrolhwnds cc setreturn:on
						fmap_ winapi.showwindow hwnds rolbits[k]
					)
					
					setfocus emp_00	
				)

				on low_labs_bt changed state do setCurrentTool id:0
				on proxy_park_bt changed state do setCurrentTool id:1
				
				fn isDockable = winapi.isdockabledialog this_dialog
				fn toggleDockable =
				(
					local dockable = isDockable()
					local hwnd = owner.dialog
					--xformat_ hwnd dockable
					
					if not dockable then
					(
						hwnd = icui.registerdialog owner.dialog style:dialog.cui_tool
						winapi.hookWindowSize hwnd fixed:on
					)
					else
					(
						icui.unregisterdialog owner.dialog
						hwnd = owner.dialog
					)
					hwnd 
				)
				fn pickSysMenu sender id = 
				(
					if (id == wcrc32 "Dockable") do
					(
						local hwnd = toggleDockable()
						if (winapi.hasSystemMenu hwnd) do
						(
							if not (winapi.hasSystemMenuItem hwnd id) do winapi.insertSystemMenuItem hwnd "Dockable" pos:0 separator:1 id:&id
							winapi.checkSystemMenuItem hwnd id state:(isDockable())
						)
						winapi.hookWindowSysMenu hwnd action:owner.dialog.pickSysMenu
					)
				)
					
				local unregisterRC = 
				(
					rcmenu unregisterRC 
					(
						local dialog = dialog
						fn unregistred = winapi.isdialogwindow dialog

						menuitem doregister_i "Register Dialog" caption:"Register Dialog" enabled:(unregistred())
						menuitem unregister_i "Unregister Dialog" caption:"Unregister Dialog" enabled:(not unregistred())
						separator sep0
						menuitem locale_mode_ch "Locale Mode\t中文" enabled:on
									
						on locale_mode_ch picked do
						(
							if isstruct (rules = globalvars.getvalue #SEASUN_ToolsRules) do
							(
								rules.changeToolLocale owner menu:#(owner.top_menu, this_owner) locale:-1
							)
						)						
						on doregister_i picked do dialog.toggleDockable()
						on unregister_i picked do dialog.toggleDockable() --cui.unRegisterDialogBar dialog
						on unregisterRC open do 
						(
							if isstruct (rules = globalvars.getvalue #SEASUN_ToolsRules) do
							(
								locale_mode_ch.checked = rules.getToolLocale owner
							)
						)
					)
				)
				
				on dialog rbuttonup pos do
				(
					unregisterRC.dialog = this_rollout
					popupmenu unregisterRC
				)				
				
				on dialog close do undo off
				(
					sync_timer.active = off
					easyRedrawCB.unregistercallback id:#iso_select_monitor
					
					winapi.hidewindow owner.dialog
					icui.unregisterdialog owner.dialog
					owner.parent_hwnd = unsupplied

					owner.dialog_pos = getdialogpos owner.dialog
					iniops.set owner.ini_file #dts_proxy_zone #pos (owner.dialog_pos as string)
					owner.dialog_size = getdialogsize owner.dialog
					iniops.set owner.ini_file #dts_proxy_zone #size (owner.dialog_size as string)
					owner.dialog_rect = rolloutops.getdialogrect owner.dialog
					iniops.set owner.ini_file #dts_proxy_zone #rect (owner.dialog_rect as string)
					owner.saveINISettings()

					checkmaxmessages()
					owner.opened = off

					validateMacroButtons()
				)
				
				on dialog resized sz do
				(
					--rolloutops.redrawcontrol frs
				)
				
				local handle_buttons = #()
				
				on dialog open do
				(
					dialog.title = owner.title
					local cc = this_controlset
					res = winproc.custTooltip cc target:tooltip_target_bt param:#tip

					if isstruct (rules = globalvars.getvalue #SEASUN_ToolsRules) do
					(
						rules.changeToolLocale owner menu:#(unregisterRC, owner.top_menu) tool:owner.tool_name locale:#current
					)
					owner.opened = on

					setSpinnerReset cc[spinnercontrol] 
					cbs = cc[CheckButtonControl]
					winproc.noFocus cbs
					addControlCustHandlers (cbs + handle_buttons)

					cbs = cc[comboboxcontrol]
					winproc.invalidateComboBox cbs --color:#button rect:[1,0,-1,0] --color:#button

					bts = cc[buttoncontrol]
					addControlCustHandlers bts					
					
					--for k=1 to 3 do setwindowtooltip optimize_type_rb.hwnd[k] (param_ optimize_type_rb #tooltips)[k]
					
					
					fbs = cc[isuicontroltarget] - #(copy_spring_bt)
					setcontrolround fbs radius:rd_ size:sz_ 
					setcontrolround #(sim_progress_pb, progress_pb) 
					hidewindows #(sim_progress_fr, progress_fr)
					--winapi.repaintwindow #(sim_progress_fr, progress_fr) update:on
					
					(rolloutOps.getGroup this_rollout_ index:08).enabled = off
					(rolloutOps.getGroup this_rollout_ index:09).enabled = off
					(rolloutOps.getGroup this_rollout_ index:10).enabled = off

					setCurrentTool()
					updateAxisUI()
					updateIsolateProxyUI()
					updateProjectTargetUI init:on
					updateWorkingPivotUI()
					
					if not istruenode owner.project_target do
					(
						owner.tryFindNodeReference #project_target
					)
					pick_project_target_bt.object = prop_ owner #project_target

					sync_timer.active = on
					
					validateMacroButtons()
					resumeWindowRedraw dialog
				)
			)		
		),
		fn isOpened = 
		(
			opened and (choice dialog (bool (winapi.iswindowopen dialog)) off)
		),
		fn create = 
		(
			destroy()

			local hwnd = dialog
			local dockable = off --shift_

			loadINISettings()
			dialog.owner = this
			top_menu.owner = this 
			top_menu.d = dialog 
			
			winapi.registerHiddenDialog winproc.noshow id:&id
			createdialog_ dialog pos:(choice (esc_ or ctrl_) unsupplied dialog_pos) menu:top_menu parent:parent_hwnd
			winapi.unregisterWindowsHook id:id
			winproc.noshow dialog cancel:on
			
			winapi.setwindowicon dialog icon:#dts
			winapi.insertSystemMenuItem dialog "Dockable" pos:0 separator:1 id:&id checked:off
				
			if dockable do
			(
				hwnd = icui.registerdialog dialog style:dialog.cui_tool
				winapi.hookWindowSize hwnd fixed:on
				winapi.insertSystemMenuItem hwnd "Dockable" pos:0 separator:1 id:&id checked:on
			)
			winapi.hookWindowSysMenu hwnd action:dialog.pickSysMenu

			ok
		),	
		
		dialog_action =
		(
			macroScript DTS_ProxyZone
				category:"DTS"
				buttonText:"PROXY ZONE"
				toolTip:"Proxy Zone (Lowres Modeling)"
				autoUndoEnabled:off
				silentErrors:off
			(
				local tool_name = #DTS_ProxyZone
				local d
				
				fn enabled = 
				(
					defined (d = getglobal #DTS_ProxyZone)
				)
				on isEnabled do (enabled())
				on isChecked do (enabled() and d.isopened())
					
				on execute parent: do if enabled() do
				(
					if not d.isopened() then 
					(
						d.parent_hwnd = parent
						d.create() 
					)
					else d.destroy()
					validateMacroButtons()
				)
			)			
		),
		
		on create do
		(
			destroy()
		)
	)
	
	local stored = undefined
	if defined (d = getglobal #DTS_ProxyZone) do 
	(
		xtry_ (stored = getpropvalues d d.props_store)
	)

	global _pz = DTS_ProxyZone = ProxyZoneStruct()
	
	if isstruct (d = DTS_ProxyZone) do 
	(
		xtry_ (setpropvalues d stored)
		if not isNodeMonitor d.recent_proxy_ref do d.recent_proxy_ref = NodeMonitor()
		if not isNodeMonitor d.recent_shape_ref do d.recent_shape_ref = NodeMonitor()
	)
	
	validateMacroButtons()
	ok
)


