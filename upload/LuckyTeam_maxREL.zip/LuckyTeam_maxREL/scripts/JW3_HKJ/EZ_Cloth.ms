global SEASUN_PhysXOps

install__ = false
if globalvars.isglobal #gmxs64__ do
(
	ini_file = (getdir #plugcfg) + "\\seasun_tools.ini"
	tool_id = #ez_cloth
	status = iniops.check ini_file #seasun_dts_tools tool_id default:"false" 
	install__ = executestring status
	format "(MAX LOADING:%) % >> % = install:%\n" THE_MAX_LOADING_ tool_id status install__
)
if install__ do
	
(
/*	
	local cloth_xchange_data
	local last_cloth_action
	
	local current_mode = off
	if isstruct (d = globalvars.getvalue #SEASUN_PhysXOps) do
	(
		--try (d.deleteCallbacks()) catch()
		d.deleteCallbacks()	
		current_mode = d.protect_mode
		last_cloth_action = d.last_cloth_action
		cloth_xchange_data = d.cloth_xchange_data
	)
	enablerefmessages on
*/
	
	struct SEASUN_PhysXOps_struct
	(
	private
		version = "v3.9",
		setprops = 
		#(
			#current_tool,
			#mesh_smooth_type, #face_source_type, #min_distance,
			#protect_auto_startup, #protect_use_mesh, #protect_current_channel, #use_skin_selection,
			#backstop_type, #backstop_radius_factor, #backstop_offset_distance,
			#use_long_edge, #face_long_edge,
			#ss_use_edgedist, #ss_edge_its, #ss_ignore_back, #ss_ignore_zero, #ss_falloff, #ss_pinch, #ss_bubble, #ss_value,
			#wrap_source_type, #wrap_select_missing, #wrap_distance, #wrap_exact, #wrap_power, #wrap_count, #wrap_skin, #wrap_cloth, #wrap_channels, #wrap_initial_mesh,
			#mirror_use_target, #mirror_use_normal, #mirror_hat_mode, #mirror_plane
		),
		default_cloth =
		#(
			#(#boneRootTranslation, #Bip01, #node),
			#(#friction, 0.9, #float), 
			#(#thickness, (decodeUnitValue "0.2cm"), #float), 
			#(#selfcollision, on, #bool), 
			#(#selfcollisionthickness, (decodeUnitValue "0.2cm"), #float)
		),

	public
		ini_file = (getdir #plugcfg) + "\\seasun_tools.ini", 
		title = "EZ CLOTH " + version,

		opened = off,
		parent_hwnd = unsupplied,

		fn destroy =
		(
			local d = getglobal #SEASUN_PhysXOps prop:#dialog
			if defined d do rolloutops.destroydialog d
			--try(destroydialog ::SEASUN_PhysXOps.dialog) catch()
		),
		dialog_pos = 
		(
			if (iniops.has ini_file #PhysXOps #pos) then execute (iniops.get ini_file #PhysXOps #pos) else [400,120]
		),
		dialog_size = 
		(
			if (iniops.has ini_file #PhysXOps #size) then execute (iniops.get ini_file #PhysXOps #size) else [191,502]
		),
		dialog_rect = 
		(
			if (iniops.has ini_file #PhysXOps #rect) then execute (iniops.get ini_file #PhysXOps #rect) else [400,120,191,502]
		),

		
		fn loadINISettings file: = 
		(
			if file == unsupplied do file = ini_file
			for p in setprops where (iniops.has file #PhysXOps p) do
			(
				v = execute (iniops.get file #PhysXOps p)
				if v != undefined do 
				(
					if isstruct v do
					(
						for i in (getpropnames v) do if (getproperty v i) == undefined do setproperty v i (getproperty str i) 
					)
					setpropvalue this p v
				)
			)
		),
		fn saveINISettings file: = 
		(
			if file == unsupplied do file = ini_file
			iniops.flush file
			for p in setprops do iniops.set file #PhysXOps p (tostring (getproperty this p))
		),
		
		script_root_path = splitFilepath (getThisScriptFilename()) index:-3,
		script_icon_path = script_root_path + @"\ui\icons\new\",	
		dialog_icon_file = script_icon_path + @"dts_logo_64x64.ico",
		
		TOPO_CH = 5,
		
		current_tool = 0,
			
		pre_tessellation = off,
		mesh_smooth_type = 1,
		face_source_type = 3,
		min_distance = universescale 0.1,
		
		use_long_edge = off,
		face_long_edge = 0,
		
		use_skin_selection = on,
			
		protect_auto_startup = on,
		protect_use_mesh = off,
		protect_current_channel = off,
		
		backstop_type = 1,
		backstop_radius_factor = 0.8,
		backstop_offset_distance = -1.0,
		
		ss_paint_mode = off,
		
		ss_use_edgedist = on,
		ss_edge_its = 1,
		ss_ignore_back = off,
		ss_ignore_zero = off,
		ss_falloff = 0,
		ss_pinch = 0,
		ss_bubble = 0,
		ss_value = 0,
		
		wrap_source_type = 1,
		wrap_select_missing = on,
		wrap_distance = universescale 0.1,
		wrap_exact = on,
		wrap_power = 1,
		wrap_count = 1,
		wrap_skin = off,
		wrap_cloth = on,
		wrap_channels = 31, 	
		wrap_initial_mesh = off,
		
		mirror_use_target = off,
		mirror_use_normal = on,
		mirror_hat_mode = off,
		mirror_plane = 1,
		
		cloth_data,
		bone_transforms,

		protect_mode = off,
		callbackContainer, 

		current_node,
		
		PhysXParams =
		(
			struct PhysXParams
			(
				node,
				physx,
				verts,
				count,
				maxdistance = floattab(),
				backstopoffset = floattab(),
				backstopradius = floattab(),
				latchnearest = floattab(),
				latchgroup = floattab()
			)
		),
		
		physx_data = PhysXParams(),
		testparam = floattab(),
		last_cloth_action,
		
		XChangeData =
		(
			struct XChangeData 
			(
				node, name, verts, sk, sk_data, px, px_data, kd3, kd3_ini
			)
		),
		cloth_xchange_data = #(),
		
		fn sortClothData = if cloth_xchange_data != undefined do
		(
			--fn sortByName d1 d2 = stricmp d1.name d2.name
			--qsort cloth_xchange_data sortByName
			nsort cloth_xchange_data
		),
		
		physx_param_names = 
		#(
			#maxdistance,
			#backstopoffset,
			#backstopradius,
			#latchnearest,
			#latchgroup
		),
		physx_param_defs = 
		#(
			0.0,
			FLT_MAX,
			0.0,
			1.0,
			0.0
		),
		physx_param_defaults = qhashtable physx_param_names physx_param_defs,
		
		fn getClothCurrentChannels px = if not iskindof px PhysX_Clothing then #{} else 
		(
			case px.channel of 
			(
				0: #{1}
				1: #{2}
				2: #{4,5}
				3: #{3}
		  default: #{1..5}
			)
		),
		
		fn get_cloth node = (findnodemodifier node class:PhysX_Clothing), --(getnodemodifiers node class:PhysX_Clothing first:on),
		fn get_skin node = (findnodemodifier node class:Skin), --(getnodemodifiers node class:Skin first:on),
		
		fn getPhysXCount node = 
		(
			if (physx = getPhysX node) != undefined then physx.maxdistance.count else -1
		),
		fn getSkinCount node = 
		(
			if (sk = getSkin node) != undefined then getskinnumverts node sk else -1
		),
		fn getVertCount node = 
		(
			numpoints node
		),

		mapped fn setDefaultClothParams px = if iskindof px PhysX_Clothing do
		(
			node = getmodifiernodes px first:on
			modi = choice (getnodeskin node) px 
			for b in (findnodesbyname name:default_cloth[1][2]) where refs.isDependent modi b do setproperty px default_cloth[1][1] b
			for k=2 to default_cloth.count do 
			(
				d = default_cloth[k]
				setproperty px d[1] d[2]
			)
			pblock2.callBlockSets px 0
			ok
		),
		mapped fn applyClothMaterial px &index: = if iskindof px PhysX_Clothing do
		(
			if ispolyobject (node = getmodifiernodes px first:on) do
			(
				ids = getpolymatids node id:&id
				if (id != numbits ids) do id = collapsepolymatids node
				if (id > 1) then
				(
					mat = node.material
					if not (iskindof mat MultiMaterial) do
					(
						mat = node.material = MultiMaterial name:(node.name + "_mat") numsubs:1
					)
					mat.numsubs = id
					for k in iterator id do 
					(
						mat.materialIDList[k] = k
						id = toname k
						mat.names[k] = "#" + id
						if not (iskindof mat.materialList[k] Material) do mat.materialList[k] = Standard() 
						mat.materialList[k].name = node.name + "_sub" + id
					)
				)
				else if (id == 1) do
				(
					mat = node.material
					if not (iskindof mat Standard) do
					(
						mat = node.material = Standard name:(node.name + "_mat")
					)
				)

				if ismaterial mat and isnumber index do
				(
					meditmaterials[index] = mat
					index += 1
				)
			)
			ok
		),
		
		cloth_hidden_verts = #{},
		fn isProtectModeEnabled node = 
		(
			ispolyobject node and isclothdataenabled (getnodemodifier node class:PhysX_Clothing)
		),
		fn getProtectedVerts node selected:off =
		(
			if protect_use_mesh then
			(
				if selected then 
					getpolyvertsusing node #selected level:#faces invert:on value:cloth_hidden_verts
				else 
					getpolyhidden node level:#verts value:cloth_hidden_verts
			)
			else
			(
				getskinselection node invert:on value:cloth_hidden_verts
			)
		),
		fn processCallbacks event handles nodes: owner: = 
		(	
			if owner == unsupplied do owner = globalvars.getvalue #SEASUN_PhysXOps
			
			--format ">> %\n" (valOps.dump_local_vars_and_externals())
			
			--format ">> %\n" event
			case event of
			(
				#geometryChanged: with undo off
				(
					--owner.callbackContainer.enabled = off
					--enablerefmessages off
					for handle in handles where ispolyobject (node = GetAnimByHandle handle) and isclothdataenabled (px = getnodemodifier node class:PhysX_Clothing) do
					(
						--getpolyhidden node level:#verts value:owner.cloth_hidden_verts
						owner.getProtectedVerts node
						--format ">>>>>>>>>>> %\n" owner.cloth_hidden_verts
						d = resetclothdata px filter:owner.cloth_hidden_verts --notifyAfterAccept:off
					)
					--owner.callbackContainer.enabled = on
					--enablerefmessages on
				)
				#selectionChanged:
				(
				)
				#deleted:
				(
				)
			)
			owner.dialog.confirmProtectMode()
		), 
		
		fn deleteCallbacks = 
		(
			if inodeevents.isValidCallback callbackContainer do 
			(
				inodeevents.deleteCallback callbackContainer delete:off
				--callbackContainer = undefined
			)
		),
		fn createCallbacks = 
		(
			callbackContainer = NodeEventCallback geometryChanged:processCallbacks selectionChanged:processCallbacks deleted:processCallbacks mouseUp:on
				--modelOtherEvent:processCallbacks \
				--all:processCallbacks 
				--topologyChanged:processCallbacks \
				--selectionChanged:processCallbacks \
			--callbackContainer.enabled = on --getProtectMode()
		),


		fn isSkinnedBone bone = getdependents bone class:Skin any:on,
		fn findSkinnedBones nodes: = 
		(
			if nodes == unsupplied do nodes = objects as array
			filterArray nodes apply:isSkinnedBone	
		),
		fn findScrewedBones nodes: tolerance: normal:off data:on =
		(
			bones = findSkinnedBones nodes:nodes
			for bone in bones collect
			(
				inparent_tm = getInParentNodeTM bone
				
				if not (d = orthogonalMatrix3 inparent_tm normal:normal tolerance:tolerance value:&v) then
				(
					if data then #(bone, v, inparent_tm) else bone
				)
				else dontcollect
			)
		),
		fn fixSkinnedSkewedBones bones:  tolerance:0.0000001 normal:off position:on rotation:off scale:on initTime:0f = 
		(
			if bones == unsupplied do bones = findScrewedBones data:off tolerance:tolerance normal:normal
			bones = filterarray bones apply:isbipednode invert:on
			hierarchysort bones dir:1
			
			at time initTime
			(
				for bone in bones do
				(
					if iskindof bone.controller prs do bone.controller = prs()
					
					inparent_tm = getNodeTransform bone local:on time:initTime

					sk = getdependents bone class:Skin first:on
					node = getskinnode sk
					
					skininit_tm = getSkinBoneInitTM node sk bone local:on
					
					decompmatrix3 inparent_tm &p1 &r1 &s1
					decompmatrix3 skininit_tm &p0 &r0 &s0

					
					if position do 
					(
						deletekeys bone.position.controller 
						p1 = p0
					)
					if rotation do 
					(
						deletekeys bone.rotation.controller 
						r1 = r0
					)
					if scale do 
					(
						deletekeys bone.scale.controller 
						s1 = s0
					)
					
					
					tm = buildmatrix3 pos:p1 rotation:r1 scale:s1
					
					setnodetransform bone tm local:on
				)
			)
			bones
		),
		fn convertSkinSelection node: type: level: verts: = 
		(
			skin_hidden = on
				
			if node == unsupplied do node = selectedskinnode
			if hasskinmodifier node do
			(
				if type == #poly do
				(
					if not defined verts do verts = 
					(
						getskinselection node
					)
					ss = getPolyUsingOnlyVerts node verts level:level
					setpolyselection node ss level:level
				)
				if type == #skin do
				(
					if not defined verts do verts = 
					(
						ss = getpolyselection node level:level
						getpolyvertsusing node ss level:level
					)
					setskinselection node verts hidden:skin_hidden
				)
			)
		),

		dialog =
		(
			rollout dialog "" width:191
			(	
				local owner = if owner != undefined do owner
				local cuiUpdater = (dotnetClass "ManagedServices.CuiUpdater").GetInstance()
				local cui_tool = #(#cui_dock_left, #cui_dock_right, #cui_floatable, #cui_handles)
				
				local max_back_color = colorRefs.getMaxColor #background
				
				local red_color = color 205 20 20
				local darkred_color = color 185 10 10
				local darkdim_color = color 112 112 112
				local red_bmp = bitmap 1 1 color:(color 160 10 10)

				local orange_color = color 190 100 50
				local orange_bmp = bitmap 1 1 color:(color 140 70 20)
				local yellow_bmp = bitmap 1 1 color:(color 140 140 20)
				local green_bmp = bitmap 1 1 color:(color 20 130 25)
				local blue_bmp = bitmap 1 1 color:(color 20 80 125)
				local gray_color = (colorMan.getColor #background as point4) as color
				local gray_bmp = bitmap 1 1 color:(color 14 14 14)
				local toolback_color = color 120 120 120
				
				local rd_ = 3
				local sz_ = 1.4
				
				fn isTrueAttachTarget node =
				(
					ispolyobject node and node != selectednode
				)
				
				checkbutton ez_physx_bt "EZ PHYSX" highlightColor:(saturate violet 0.2) width:90 height:30 align:#left offset:[-9,0] across:2 \
					checked:(owner.current_tool == 0) tooltip:"EZ PhysX Tool"
				checkbutton cloth_wrap_bt "CLOTH WRAP" highlightColor:(saturate teal 0.2) width:91 height:30 align:#right offset:[10,0] \
					checked:(owner.current_tool == 1) tooltip:"Cloth Wrap"

				label emp_10 offset:[0,-10]
								
				group "Cloth Tessellation: "
				(
					label mesh_smooth_type_lb "Type:" align:#left offset:[4,0] across:2
					radiobuttons mesh_smooth_type_rb labels:#("Tessellate", "MSmooth") default:owner.mesh_smooth_type columns:1 align:#left offset:[-46,0] offsets:#([0,0], [0,0])

					label face_source_type_lb "Faces:" align:#left offset:[0,2] across:2
					radiobuttons face_source_type_rb labels:#("All", "Selected", "Distance") default:owner.face_source_type columns:1 align:#left offset:[-46,2] offsets:#([0,0], [0,0], [0,0])

					spinner min_distance_sp "" type:#worldunits range:[0,FLT_MAX,owner.min_distance] scale:(universescale 0.1) fieldwidth:56 align:#right offset:[4,-20] \
						enabled:(owner.face_source_type == 3) tooltip:"Cloth: Minimum Distance"
					
					checkbox use_long_edge_ch "Use Edge Length" checked:owner.use_long_edge offset:[0,-2] enabled:(owner.face_source_type == 3) across:2
					spinner face_long_edge_sp "" type:#worldunits range:[0,FLT_MAX,owner.face_long_edge] scale:(universescale 0.1) fieldwidth:56 align:#right offset:[5,-2] \
						enabled:(owner.face_source_type == 3 and owner.use_long_edge) tooltip:"Minimum Edge Length for tessellation"
										
					button mesh_smooth_bt "Tessellate" width:173 align:#left offset:[-4,0] \
						tooltip:"Smooth(Tessellate) Faces with PhysX"
					framecontrol mesh_smooth_fr color:buff target:mesh_smooth_bt radius:rd_ size:sz_ enabled:mesh_smooth_bt.enabled
				)
				/*
				group "Edit Elements: "
				(
					button detach_skin_bt "Detach" width:85 align:#left offset:[-4,0] across:2 \
						tooltip:"Detach Selected Elements"
					pickbutton attach_skin_bt "Attach" filter:isTrueAttachTarget width:86 align:#right offset:[5,0] \
						tooltip:"Pick a Geometry to Attach"
				)
				*/
				group "Edit Mesh: "
				(
					checkbox use_skin_selection_ch "Use Skin Selection" checked:owner.use_skin_selection align:#left offset:[0,2] 
					
					button detach_faces_bt "Detach" width:85 align:#left offset:[-4,2] across:2 \
						tooltip:"Detach Selected Faces\n +Ctrl\t- Selected Elements\n  +Atl\t- Use Skin Selection\n"
					pickbutton attach_faces_bt "Attach" filter:isTrueAttachTarget width:86 align:#right offset:[5,2] \
						tooltip:"Pick a Geometry to Attach\n +Ctrl\t- Weld attached"

					button delete_faces_bt "Delete Faces" width:86 align:#left offset:[-4,0] across:2 \
						tooltip:"Delete Selected Faces\n  +Alt\t- Use Skin Selection"
					button delete_iso_verts_bt "Delete Verts" width:86 align:#right offset:[5,0] \
						tooltip:"Delete Isolated Verts"
				)
				
				on use_skin_selection_ch changed state do owner.use_skin_selection = state 
				
				--label emp_11 offset:[0,-10]
				group "Paint Protect: "
				(
					checkbox protect_auto_startup_ch "Auto Startup" checked:owner.protect_auto_startup offset:[0,2] \
						tooltip:"Auto Startup and Cancel Protect Mode if Dialog is opened"
					checkbox protect_use_mesh_ch "Protect Hidden Mesh" checked:owner.protect_use_mesh offset:[0,2] \
						tooltip:"Protect Hidden Vertices\n\n     RC\t- Convert Poly to Skin Selection"
					
					checkbutton protect_mode_bt "Cloth Paint Protect" width:173 highlightColor:darkred_color align:#left offset:[-4,0] \
						tooltip:"Toggle Paint Protect Mode\n\n     RC\t- Store Cloth Data"
					framecontrol protect_mode_fr color:(litecolor scarlet) target:protect_mode_bt radius:rd_ size:sz_ enabled:protect_mode_bt.enabled

					button element_skin_grow_bt "Select Skin To Elements" width:173 align:#right offset:[4,2] \
						tooltip:"Grow Skin selection to elements\n  +Alt\t- Shirk To Elements\n\n    RC\t- Invert Skin Selection"

					button hide_selected_bt "Hide" width:85 align:#left offset:[-4,0] across:2 \
						tooltip:"Hide Protected\n  +Alt\t- Hide Invert"
					button unhide_all_bt "Unhide All" width:86 align:#right offset:[5,0] \
						tooltip:"Unhide All"

					button restore_current_channel_bt "Restore Protected" width:173 align:#right offset:[4,4] enabled:(not owner.protect_mode) \
						tooltip:"Restore Current Cloth Channel\n\n  +Alt\t- Use Face Selection\n  +Ctrl\t- All Channels"	
				)
				--label emp_12 offset:[0,-10]

				group "Max Distance To Backstop: "
				(
					--radiobuttons backstop_type_rb labels:#("All", "Radius ", "Offset ") default:owner.backstop_type columns:1 align:#left offset:[36,0] offsets:#([0,0], [0,6], [0,12])

					checkbox backstop_radius_factor_ch "Radius" checked:(getibit owner.backstop_type 1) across:2
					spinner backstop_radius_factor_sp "" type:#float range:[0,1,owner.backstop_radius_factor] scale:0.01 fieldwidth:56 align:#right offset:[4,0] \
						enabled:(getibit owner.backstop_type 1) tooltip:"Backstop Radius Factor"

					checkbox backstop_offset_distance_ch "Offset" checked:(getibit owner.backstop_type 2) offset:[0,-2] across:2 
					spinner backstop_offset_distance_sp "" type:#float range:[-2,0,owner.backstop_offset_distance] scale:0.01 fieldwidth:56 align:#right offset:[4,-2] \
						enabled:(getibit owner.backstop_type 2) tooltip:"Backstop Offset Distance"

					button distance_convert_bt "Convert" width:173 align:#left offset:[-4,2] enabled:(bool owner.backstop_type) \
						tooltip:"Convert Cloth Max Distance to Backstop Radius and Offset"
				)				
				group "Soft Cloth Paint: "
				(
					checkbutton pick_distance_bt width:20 align:#left offset:[-4,0] highlightColor:(color 220 40 30) across:3 \
						--images:#("bip_picknode_i.bmp", undefined, 2, 1, 1, 1, 1, on) \
						tooltip:"Pick Cloth Max Distance"
					label pick_distance_lb "Pick" align:#left offset:[-32,4]
					
					spinner ss_value_sp "Value: " type:#worldUnits range:[0,FLT_MAX,owner.ss_value] scale:(universescale 0.1) fieldwidth:56 align:#right offset:[4,4]

					checkbox ss_ignore_zero_ch "Ignore Unpainted" checked:owner.ss_ignore_zero offset:[0,4]
					--checkbox ss_ignore_back_ch "Ignore Backface" checked:owner.ss_ignore_back offset:[0,-22] visible:off
					checkbox ss_use_edgedist_ch "Edge Distance" checked:owner.ss_use_edgedist across:2
					spinner ss_edge_its_sp "" type:#integer range:[1,FLT_MAX,owner.ss_edge_its] scale:1 fieldwidth:56 align:#right offset:[5,0] enabled:(owner.ss_use_edgedist)
					
					spinner ss_falloff_sp "Falloff: " type:#worldUnits range:[0,FLT_MAX,owner.ss_falloff] scale:(universescale 0.1) fieldwidth:56 align:#right offset:[4,4]
					spinner ss_pinch_sp "Pinch: " type:#float range:[0,FLT_MAX,owner.ss_pinch] scale:0.01 fieldwidth:56 align:#right offset:[4,-2]
					spinner ss_bubble_sp "Bubble: " type:#float range:[0,FLT_MAX,owner.ss_bubble] scale:0.01 fieldwidth:56 align:#right offset:[4,-2]

					checkbutton ss_paint_mode_bt "Soft Paint" highlightColor:orange_color width:85 align:#left offset:[-4,4] across:2 \
						tooltip:"Cloth Paint Mode"
					button ss_apply_paint_bt "Apply" width:86 align:#right offset:[5,4] enabled:off \
						tooltip:"Apply Soft Paint"
				)

				label emp_18 height:0 offset:[0,0]
				
				button redo_cloth_bt "Redo Cloth" width:173 align:#right offset:[4,0] tooltip:"Redo Cloth after Geometry Change"
				framecontrol redo_cloth_fr color:litetitan target:redo_cloth_bt radius:rd_ size:sz_ enabled:redo_cloth_bt.enabled
				
				label emp_01 offset:[0,-16]

				button undo_redo_cloth_bt "Do Cloth Restore" width:173 align:#right offset:[4,0] tooltip:"Undo/Redo Cloth Restore"
				on undo_redo_cloth_bt pressed do
				(
					for node in selectednodes where ispolyobject node and ismodifier (px = getnodemodifier node class:PhysX_Clothing) do
					(
						restoreclothdata px id:20 undo:off --update:off
					)
				)				
				group "Helpers: "
				(
					checkbutton init_bones_bt "Set Skin Bones To Initial" width:173 align:#right offset:[4,0] \
						tooltip:"Set Skin Bones To Initial TM\n  +Shift\t\t Set Position\n  +Ctrl\t\t Exclude Biped\n\n   RC\t\t No Undo"
					framecontrol init_bones_fr color:palecyan target:init_bones_bt radius:rd_ size:sz_ enabled:init_bones_bt.enabled

					button fix_skewed_bones_bt "Fix Skin Bones Scale" width:173 align:#right offset:[4,4] \
						tooltip:"Fix Skin Bones Scale" --"\n\n  +Ctrl\t- Select Fixed Bones"
					framecontrol fix_skewed_bones_fr color:vividpink target:fix_skewed_bones_bt radius:rd_ size:sz_ enabled:fix_skewed_bones_bt.enabled

					button rescale_bones_bt "Rescale Skin Bones" width:173 align:#right offset:[4,2] \
						tooltip:"Rescale Skin Bones" --"\n\n  +Ctrl\t- Select Fixed Bones"
					framecontrol rescale_bones_fr color:lime target:rescale_bones_bt radius:rd_ size:sz_ enabled:rescale_bones_bt.enabled

					button confirm_cloth_bt "Confirm Cloth Parameters" width:173 align:#right offset:[4,8] \
						tooltip:"Set Default Cloth Parameters\n\n  +Ctrl\t- All Cloth Modifiers"

					--button reapply_cloth_bt "Reapply Cloth Modifiers" width:173 align:#right offset:[4,4] \
						--tooltip:"Reapply Cloth Modifiers\n\n  +Ctrl\t- All Cloth Modifiers"
				)


				label emp_20 pos:emp_10.pos
				group "Cloth Wrap: "
				(
					label wrap_source_type_lb "Use:" align:#left offset:[10,2] across:2
					radiobuttons wrap_source_type_rb labels:#("All Vertices", "Selected (Skin)") default:owner.wrap_source_type columns:1 align:#left offset:[-46,2] offsets:#([0,0], [0,0])

					checkbox wrap_select_missing_sp "Select Missing" checked:owner.wrap_select_missing offset:[0,2]

					checkbox wrap_exact_sp "Exact" checked:owner.wrap_exact offset:[0,5] across:2
					spinner wrap_distance_sp "Distance: " type:#worldUnits range:[0,FLT_MAX,owner.wrap_distance] scale:(universescale 0.1) fieldwidth:56 align:#right offset:[5,6] \
						tooltip:"Wrap Distance (Search Falloff)"
					spinner wrap_power_sp "Power: " type:#float range:[0,100,owner.wrap_power] scale:0.1 fieldwidth:56 align:#right offset:[4,0]
					spinner wrap_count_sp "Max Count: " type:#integer range:[1,1000,owner.wrap_count] fieldwidth:56 align:#right offset:[4,0]
					
					checkbox wrap_skin_sp "Skin" checked:owner.wrap_skin offset:[0,4] \
						tooltip:"Process Skin"	
					checkbox wrap_cloth_sp "Cloth (PhysX)" checked:owner.wrap_cloth offset:[0,2] across:3 \
						tooltip:"Process Cloth (PhysX Clothing)"	
					checkbutton track_cloth_data_bt width:20 align:#left offset:[48,-1] \
						tooltip:"Cloth Channels Data Tracking Mode"	
					label track_cloth_data_lb "Track" align:#left offset:[20,2]
					
					checkbox wrap_maxdistance_ch "Max Distance" checked:(getibit owner.wrap_channels 1) offset:[14,1] enabled:owner.wrap_cloth across:2
					spinner maxdistance_sp "" type:#worldunits range:[-FLT_MAX,FLT_MAX,0] fieldwidth:56 align:#right offset:[5,1]
					checkbox wrap_backstopoffset_ch "Back Offset" checked:(getibit owner.wrap_channels 2) offset:[14,-2] enabled:owner.wrap_cloth across:2
					spinner backstopoffset_sp "" type:#worldunits range:[-FLT_MAX,FLT_MAX,0] fieldwidth:56 align:#right offset:[5,-2]
					checkbox wrap_backstopradius_ch "Back Radius" checked:(getibit owner.wrap_channels 3) offset:[14,-2] enabled:owner.wrap_cloth across:2
					spinner backstopradius_sp "" type:#worldunits range:[-FLT_MAX,FLT_MAX,0] fieldwidth:56 align:#right offset:[5,-2]
					checkbox wrap_latchnearest_ch "Latch Nearest" checked:(getibit owner.wrap_channels 4) offset:[14,-2] enabled:owner.wrap_cloth across:2
					spinner latchnearest_sp "" range:[-FLT_MAX,FLT_MAX,0] fieldwidth:56 align:#right offset:[5,-2]
					checkbox wrap_latchgroup_ch "Latch Group" checked:(getibit owner.wrap_channels 5) offset:[14,-2] enabled:owner.wrap_cloth across:2
					spinner latchgroup_sp "" type:#integer range:[-INT_MIN,INT_MAX,0] fieldwidth:56 align:#right offset:[5,-2]
	
					button store_cloth_bt "Store" highlightColor:orange_color width:85 align:#left offset:[-4,4] across:2 \
						tooltip:"Store Cloth Data For Selection"
					button restore_cloth_bt "Restore" width:86 align:#right offset:[5,4] \
						tooltip:"Restore Cloth Data For Selection\n  +Ctrl\t- Unprotected\n  +Alt\t- Protected"	

					listbox cloth_targets_bx "  Targets: " width:176 height:7 align:#right offset:[6,4] tooltip:"Cloth Wrap Targets List"

					checkbox wrap_initial_mesh_ch "Use Initial Mesh" checked:owner.wrap_initial_mesh offset:[0,2]
					
					button copy_cloth_bt "Copy" highlightColor:orange_color width:85 align:#left offset:[-4,0] across:2 \
						tooltip:"Copy Cloth Data From Selection\n  +Ctrl\t- From All Geometry\n     RC\t- Find Source using list"
					button paste_cloth_bt "Paste" width:86 align:#right offset:[5,0] enabled:(isset owner.cloth_xchange_data) \
						tooltip:"Paste Cloth Data to Selected (Cloth Wrap)\n     RC\t- Find Target in list"					
				)
				label emp_06 offset:[0,-26]
				group ""
				(
					label mirror_plane_lb "Mirror Plane:" align:#left offset:[0,-4] across:2
					radiobuttons mirror_plane_rb labels:#("X - Default", "Z - Hat") default:owner.mirror_plane columns:1 align:#left offset:[-14,-5] offsets:#([0,0], [0,0])

					checkbox mirror_use_normal_sp "Use Normals" checked:owner.mirror_use_normal offset:[0,2] tooltip:"Ignoge Backface Targets"
					
					--checkbox mirror_hat_mode_sp "Hat Mode (Z - Mirror)" checked:owner.mirror_hat_mode offset:[0,0] tooltip:"Z - Mirror" visible:off
					--checkbox mirror_use_target_sp "Use Targets" checked:owner.mirror_use_target offset:[0,0] visible:off
					
					button mirror_x_cloth_bt "Mirror Selected Cloth" width:173 align:#right offset:[4,0] \
						tooltip:"X-Mirror Cloth for Selection\n     RC\t- Select Mirror Vertices"
				)
				label emp_07 offset:[0,-26]
				group ""
				(
					label process_lb "Processed:" align:#right offset:[-24,-6] across:2
					label process_ed "0" align:#left offset:[-20,-6] 
					
					label missing_lb "Missing:" align:#right offset:[-24,0] across:2
					label missing_ed "0" align:#left offset:[-20,0] 
								
					label emp_00 offset:[0,-16]
				)
				
				--label emp_08 offset:[0,-12]
				group "Cloth Data (Advanced): "
				(
					button bake_cloth_bt "Bake" highlightColor:orange_color width:85 align:#left offset:[-4,0] across:2 \
						tooltip:"Bake Cloth Data"
					button paint_cloth_bt "Paint" width:86 align:#right offset:[5,0] \
						tooltip:"Paint Cloth Data"	
					button select_lost_cloth_bt "Select Unpainted Cloth" width:173 align:#right offset:[4,0] \
						tooltip:"Select Lost Cloth Vertices (Geometry)\n  +Alt\t- Select Skin"
				)
				
				fn confirmProtectMode = 
				(
					protect_enabled = (selection.count > 0)
					for node in selectednodes while protect_enabled do
					(
						protect_enabled = owner.isProtectModeEnabled node
					)
					hcolor = if protect_enabled then darkred_color else darkdim_color
					setCheckButtonHighlightColor protect_mode_bt hcolor
				)
				
				on confirm_cloth_bt pressed do undo "Confirm Cloth" on
				(
					target = choice ctrl_ unsupplied selectednode
					pxs = getinstancesofclass class:PhysX_Clothing target:target
					owner.setDefaultClothParams pxs
					local index = 1
					owner.applyClothMaterial pxs index:&index
					
					--format ">> %\n" pxs
				)

				fn rescaleSkinBones = 
				(
					nodes = filterarray objects apply:hasskinmodifier
					need_reset = valueset()
					pattern = "*_HAT_BONE"
					
					for node in nodes do
					(
						bones = getskinbones node
						
						for bone in bones where not (isbipednode bone) do
						(
							if not (matchNodeName bone name:pattern) do
							(
								tm = getskinboneinittm node bone
								tm = rescalematrix3 tm
								setskinbonebindtm node bone transform:tm
								append need_reset bone
							)
						)
					)
					bones = need_reset as array
					hierarchysort bones
					resetscale bones
					bones.count
				)
				on rescale_bones_bt pressed do undo "Rescale Skin Bones" on, quiet on  
				(
					rescaleSkinBones()
					completeredraw()
				)

				on fix_skewed_bones_bt pressed do undo "Fix Scale" on, quiet on 
				(
					local bones = valueset()
					for k=1 to 10 do
					(
						append bones (owner.fixSkinnedSkewedBones tolerance:0.0000001)
					)
					if not alt_ do if isset bones then select (bones as array) else clearselection()
				)					
				
				on restore_current_channel_bt pressed do undo "Restore Cloth Channels" on 
				(
					if isclothdataenabled (px = cureditobject) and isset (channels = owner.getClothCurrentChannels px) do
					(
						node = getmodifiernodes px first:on
							
						if ctrl_ do channels = #{1..5}
						owner.getProtectedVerts node selected:alt_
						verts = owner.cloth_hidden_verts
						resetclothdata px channels:channels filter:verts undo:on
					)
				)
				
				on protect_mode_bt changed state do
				(
					if state do
					(
						any = off
						for node in selectednodes where ismodifier (px = getnodemodifier node class:PhysX_Clothing) do
						(
							storeclothdata px
							any = on
						)
						if any or true then
						(
							owner.deleteCallbacks()
							owner.protect_mode = on
							owner.createCallbacks()
							restore_current_channel_bt.enabled = off
							
							confirmProtectMode()
						)
						else state = off
					)
					if not state do
					(
						owner.deleteCallbacks()
						owner.protect_mode = off
						protect_mode_bt.state = off
						restore_current_channel_bt.enabled = on
					)
				)
				on protect_mode_bt rightclick do undo "Store Cloth" on
				(
					for node in selectednodes where ismodifier (px = getnodemodifier node class:PhysX_Clothing) do storeclothdata px undo:on
				)
				on element_skin_grow_bt pressed do undo "Select Skin" on 
				(
					if ispolyobject (node = selectednode) exact:on and (sk = getnodeskin node) != undefined do
					(
						verts = getskinvertexselection node
						faces = getusingpolyverts node verts level:#faces
						if alt_ then 
						(
							elems = getpolyelements node faces:faces unique:on
								
							desel = #{}
							for elem in elems do
							(
								vv = getpolyvertsusing node elem level:#faces
								bb = vv - verts
								
								if isset bb do join desel vv
							)
							setskinvertexselection node sk desel type:#clear
						)
						else
						(
							elems = getpolyelements node faces:faces unique:off
							verts = getpolyvertsusing node elems level:#faces
					
							setskinvertexselection node sk verts
						)
						redrawviews()
					)
				)
				on element_skin_grow_bt rightclick do if defined (node = selectedskinnode) do undo "Vert Skin Selection" on
				(
					pressthisbutton()
					ss = getskinselection node
					setskinselection node -ss
					releasethisbutton()
				)
						
				on hide_selected_bt pressed do undo "Hide" on 
				(
					for node in selectednodes where ispolyobject node exact:on do 
					(
						if (sk = getnodeskin node) != undefined do
						(	
							owner.getProtectedVerts node selected:on
							verts = owner.cloth_hidden_verts
							if alt_ do verts = -verts
							setpolyhidden node (getpolyusingverts node verts level:#faces) level:#faces
							if owner.protect_mode and ismodifier (px = getnodemodifier node class:PhysX_Clothing) do
							(
								storeclothdata px verts:verts
							)
						)
					)
				)
				on unhide_all_bt pressed do undo "Unhide" on 
				(
					for node in selectednodes where ispolyobject node do 
					(
						setpolyhidden node #none level:#faces
					)
				)
				
				
				fn updateFaceSelection = if ispolyobject (node = selectednode) and (px = findnodemodifier node class:PhysX_Clothing) != undefined do
				(
					if getpolyselectionlevel node == 3 and owner.face_source_type == 3 do undo off
					(
						maxdist = floattab px.maxdistance
						vv = contains maxdist [owner.min_distance, FLT_MAX]
						if isset vv do
						(
							edges = getusingonlypolyverts node vv level:#edge
							setpolyselection node edges level:#edge
							
							faces = getusingonlypolyverts node vv level:#faces
							
							if owner.use_long_edge do
							(
								ff = #{}
								for f in faces where (getpolyfaceedgelength node f index:#max) >= owner.face_long_edge do append ff f
								faces = ff
							)
							setpolyselection node faces level:#faces
						)
					)
				)
				on protect_auto_startup_ch changed state do owner.protect_auto_startup = state
				on protect_use_mesh_ch changed state do owner.protect_use_mesh = state
				on protect_use_mesh_ch rightclick do undo "Select Skin by Poly" on if ispolyobject (node = selectednode) and hasskinmodifier node do 
				(
					verts = getpolyvertsusing node #selected level:#faces invert:off
					setskinselection node verts
				)
					
				on mesh_smooth_type_rb changed state do owner.mesh_smooth_type = state
				on face_source_type_rb changed state do 
				(
					owner.face_source_type = state
					use_long_edge_ch.enabled = min_distance_sp.enabled = (state == 3)
					face_long_edge_sp.enabled = (owner.face_source_type == 3) and owner.use_long_edge
					updateFaceSelection()
				)
				on face_source_type_rb rightclick do if ispolyobject selectednode do
				(
					setpolyselectionlevel selectednode level:#faces
				)
				
				on min_distance_sp changed val do 
				(
					owner.min_distance = val
					updateFaceSelection()
				)
				on use_long_edge_ch changed state do
				(
					owner.use_long_edge = state
					face_long_edge_sp.enabled = (owner.face_source_type == 3) and owner.use_long_edge
					updateFaceSelection()
				)
				on use_long_edge_ch rightclick do
				(
					if ispolyobject (node = selectednode) do
					(
						faces = getpolyselection node level:#faces
						if isset faces do
						(
							lens = for f in faces collect (getpolyfaceedgelength node f index:#min)
							sort lens
							owner.face_long_edge = face_long_edge_sp.value = lens[1]
						)
					)
				)
				on face_long_edge_sp changed val do 
				(
					owner.face_long_edge = val
					updateFaceSelection()
				)
				
				on backstop_type_rb changed state do 
				(
					owner.backstop_type = state
					backstop_radius_factor_sp.enabled = (state != 3)
					backstop_offset_distance_sp.enabled = (state != 2)
				)
				
				on backstop_radius_factor_ch changed state do 
				(
					owner.backstop_type = setibit owner.backstop_type 1 state
					backstop_radius_factor_sp.enabled = state
					distance_convert_bt.enabled = bool owner.backstop_type
				)
				on backstop_offset_distance_ch changed state do 
				(
					owner.backstop_type = setibit owner.backstop_type 2 state
					backstop_offset_distance_sp.enabled = state
					distance_convert_bt.enabled = bool owner.backstop_type
				)

				on backstop_radius_factor_sp changed val do owner.backstop_radius_factor = val
				on backstop_offset_distance_sp changed val do owner.backstop_offset_distance = val
				
				on distance_convert_bt pressed do undo "Distance Convert" on
				(
					for node in selectednodes where (px = findnodemodifier node class:PhysX_Clothing) != undefined do
					(
						if getibit owner.backstop_type 1 do 
						(
							--px.backstopradius = ((floattab px.maxdistance) * owner.backstop_radius_factor).value
							tab = (floattab px.maxdistance) * owner.backstop_radius_factor
							pblock2.appendBlockFloatTabParam px #backstopradius tab undo:on
						)
						if getibit owner.backstop_type 2 do 
						(
							--px.backstopoffset = ((floattab px.maxdistance) * -owner.backstop_offset_distance).value
							tab = (floattab px.maxdistance) * -owner.backstop_offset_distance
							pblock2.appendBlockFloatTabParam px #backstopoffset tab undo:on
						)
					)
				)

				local channel_val_controls = 
				#(
					maxdistance_sp,
					backstopoffset_sp,
					backstopradius_sp,
					latchnearest_sp,
					latchgroup_sp
				)
				
				local physx_param_names = 
				#(
					#maxdistance,
					#backstopoffset,
					#backstopradius,
					#latchnearest,
					#latchgroup
				)
				fn storePhysX physx = 
				(
					for p in physx_param_names collect
					(
						param = getproperty physx p
						floattab param index:#all
					)
				)
				fn flushPhysX physx count:0 reset:off =
				(
					for k=1 to physx_param_names.count do
					(
						p = physx_param_names[k]
						pblock2.setblocktabparamsize physx p count reset:reset
					)
				)

				fn restorePhysX physx data comp: index: channels:#all reset:off quiet:on = 
				(
					if channels == #all do channels = makebits physx_param_names.count
					local nearest = off
					
					if channels[4] do channels[5] = on
					if channels[5] do channels[4] = on
				
					for k=1 to physx_param_names.count where channels[k] do
					(
						p = physx_param_names[k]
						prop = data[k]
						if isset comp do floattabcmp prop comp[k] reset:on invert:on
						if isbits prop.parameter then
						(
							verts = if isset index then index * prop.parameter else prop.parameter
						)
						else 
						(
							verts = makebits prop.count
						)
						
						pblock2.setblocktabparamsize physx p prop.count reset:reset
						--format "% >= % %\n" p prop.count prop.center
						if isset verts or nearest do
						(
							pblock2.appendBlockFloatTabParam physx p prop
							if k == 4 do nearest = on
								
							--pblock2.setBlockFloatTabParam physx p prop index:verts quiet:quiet
						)
					)
					for k=1 to physx_param_names.count where channels[k] do
					(
						p = physx_param_names[k]
						pblock2.callBlockParamSet physx p
					)
				)

				mapped fn bakeClothData2 node channel:50 = 
				(
					if (px = getnodemodifier node class:PhysX_Clothing) != undefined do
					(
						for k=1 to physx_param_names.count do
						(
							p = physx_param_names[k]
							prop = floattab (getproperty px p)
							--format "% <= % %\n" p prop.count prop.center
							setpolyvdata node prop channel:(channel + (k-1))
						)
					)
				)
				mapped fn paintClothData2 node channel:50 = 
				(
					if (px = getnodemodifier node class:PhysX_Clothing) != undefined do
					(
						if theHold.Holding() do holdclothdata px 
						data = for k=1 to physx_param_names.count collect
						(
							p = physx_param_names[k]
							getpolyvdata node channel:(channel + (k-1))
						)
						restorePhysX px data
						px.paitingstyle = 0
						
						if theHold.Holding() do acceptclothdata px
					)
				)

				mapped fn bakeClothData node channel:50 = 
				(
					if (px = getnodemodifier node class:PhysX_Clothing) != undefined do
					(
						xd = floattab (getproperty px physx_param_names[1])
						yd = floattab (getproperty px physx_param_names[2])
						zd = floattab (getproperty px physx_param_names[3])
						dd = point3tab xd yd zd
						setpolyvertcolor node color:dd channel:channel
						
						xv = floattab (getproperty px physx_param_names[4])
						yv = floattab (getproperty px physx_param_names[5])
						vv = point3tab xv yv
						setpolyvertcolor node color:vv channel:(channel + 1)
					)
				)
				mapped fn paintClothData node channel:50 = 
				(
					if (px = getnodemodifier node class:PhysX_Clothing) != undefined do
					(
						if theHold.Holding() do holdclothdata px 
						data = #()
						
						dd = getpolyvertcolor node channel:channel
						data[1] = convertto dd #x
						data[2] = convertto dd #y
						data[3] = convertto dd #z
						
						vv = getpolyvertcolor node channel:(channel + 1)
						data[4] = convertto vv #x
						data[5] = convertto vv #y
						
						numv = numpolyverts node
						
						if countclothdata px != source_numv do 
						(
							setcureditobject px 
							replacemodifier node px px							
							--initclothdata px count:numv notifyafteraccept:on
						)
								
						--undo off restorePhysX px data
						--px.paitingstyle = 0

						undo off setclothdata px data
						
						if theHold.Holding() do acceptclothdata px
					)
				)

				on bake_cloth_bt pressed do undo "Bake Cloth" on 
				(
					bakeClothData (filterarray selectednodes filter:ispolyobject)
				)
				on paint_cloth_bt pressed do undo "Paint Cloth" on 
				(
					setCommandPanelRedraw off parent:on
					sublevel = getsubobjectlevel()
					setsubobjectlevel sublevel undo:on							
					mode = setCommandPanelMode mode:2 level:&sublevel object:&obj
					
					paintClothData (filterarray selectednodes filter:ispolyobject)
					
					setCommandPanelMode mode:mode level:&sublevel object:&obj						
					setCommandPanelRedraw on parent:on	
				)
				on select_lost_cloth_bt pressed do undo "Select Lost Cloth" on
				(
					process_verts = 0
					missing_verts = 0
					alt = alt_
					for node in (filterarray selectednodes filter:ispolyobject) do
					(
						process_verts += numpolyverts node
						sel = getpolyvertsbycolor node channel:50
						sel = choice sel sel #all
						selectpolyverts node verts:sel
						lost = getpolyselection node level:#verts
						if alt and (sk = getnodeskin node) != undefined do setskinselection node sk lost  
						missing_verts += numbits lost
					)
					process_ed.text = tostring process_verts	
					missing_ed.text = tostring missing_verts					
					completeredraw()
				)
				
				fn getNodesTransformData nodes = 
				(
					tms = matrix3tab parameter:nodes
					for node in nodes do 
					(
						--if iskindof node.controller prs do node.controller = prs() 
						tm = getnodetransform node
						--tm = rescalematrix3 tm  
						append tms tm
					)
					tms
				)
				fn setNodesTransformData tms rescale:off = 
				( 
					for k=1 to tms.count where istruenode (node = tms.parameter[k]) do 
					(
						--if iskindof node.controller prs do node.controller = prs()
						tm = copy tms[k]
						if rescale do tm = rescalematrix3 tm
						setnodetransform node tm
						--if not (matrix3equals node.transform tms[k]) do format "% >> %\n" node.name (matrix3distance node.transform tms[k])
					)
				)
				fn setSkinBonesToInitTM node sk: bones: =
				( 
					if sk == unsupplied do sk = getnodeskin node
					if iskindof sk Skin then
					(
						if bones == unsupplied do bones = getskinbones node sk
							
						for bone in bones do
						( 
							bone.transform = getskinboneinittm node sk bone
						)
						bones.count
					)
					else -1
				)
				
				local epoly_params = 
				#(
					#(#tessTension, 0.0),
					#(#smoothness, 1,0),
					#(#separateBySmoothing, on),
					#(#separateByMaterial, on),
					#(#weldThreshold, 0.01)
				)
				fn storeEPolyParams node params:epoly_params =
				(
					for p in params collect #(p[1], getproperty node p[1])
				)
				fn restoreEPolyParams node params =
				(
					for p in params do setproperty node p[1] p[2]
				)
				fn setEPolyParams node params:epoly_params =
				(
					for p in params do setproperty node p[1] p[2]
				)
				fn smoothCloth source faces: = 
				(
					if faces == unsupplied do faces = getpolyselection source level:#faces
					verts = getpolyvertsonlyusing source faces level:#faces invert:on
						
					if (source_sk = getnodeskin source) != undefined then
					(
						source_num0 = numpolyverts source
						source_data = getpolyskindata source
						source_map = source_data.w
							
						source_px = findnodemodifier source class:PhysX_Clothing
						source_px_data = #()
						if source_px != undefined do 
						(
							source_px_data = storePhysX source_px
							owner.last_cloth_action = #(source, source_px, deepcopy source_px_data, source_px.boneRootTranslation)
							
							--_source_px = copy source_px
							
							deletemodifier source source_px
							--replaceinstances source_px _source_px
							--swap source_px _source_px
						)
						
						local vv = #{}
						case owner.face_source_type of
						(
							1: 
							(
								faces = #all
								vv = getpolyvertsusing source faces level:#faces
							)
							2: 
							(
								faces = #selection
								vv = getpolyvertsusing source faces level:#faces
							)
						  default: 
							(
								vv = contains source_px_data[1] [owner.min_distance, FLT_MAX]
								faces = getusingonlypolyverts source vv level:#faces
							)
						)
						local ee = getusingonlypolyverts source vv level:#edge
						
						setpolyvdata source #id channel:5
						if isskin cureditobject do skinOps.closeWeightTool cureditobject

						deletemodifier source source_sk
						addmodifier source source_sk

						setskindata source source_map undo:on
						
						local params = storeEPolyParams source
						setEPolyParams source
						if (owner.mesh_smooth_type == 1) then
						(
							--polyop.tessellateByEdge source ee
							polyop.tessellateByFace source faces
						)
						else
						(
							--polyop.meshSmoothByEdge source ee
							polyop.meshSmoothByFace source faces
						)
						restoreEPolyParams source params
						
						source_num1 = numpolyverts source
						old_verts = makebits source_num0
						new_verts = tobits (source_num0 + 1) source_num1
						
						source_vdata = getpolyvdata source channel:5
						vv = getpolyneighbors source verts:new_verts dataarray:on distance:1 mode:#faces clear:new_verts
							
						ii = source_vdata[old_verts]
						reset source_map type:#keys target:ii
						
						for v in new_verts do
						(
							source_map[v] = normalizeskinweights source_map[vv[v]]
						)
						
						setcureditobject source_sk 
						setskindata source source_map undo:on
						setpolyselection source new_verts level:#verts
						setskinselection source new_verts
						
						--format ">>> % % %\n" source_map.count source_map.min source_map.max

						if source_px != undefined do
						(							
							p0 = unitepoint3tab x:source_px_data[1] y:source_px_data[2] z:source_px_data[3] 
							p1 = unitepoint3tab x:source_px_data[4] y:source_px_data[5] 

							c0 = copy p0
							c1 = copy p1

							vv = getpolyneighbors source dataarray:on distance:2
							ss = #{}
							for v=1 to vv.count where new_verts[v] do
							(
								b = vv[v] - new_verts
								if isset b then
								(
									c0[v] = c0[b].center
									c1[v] = c1[b].center
								)
								else append ss v
							)

							splitpoint3tab c0 x:source_px_data[1] y:source_px_data[2] z:source_px_data[3] 
							splitpoint3tab c1 x:source_px_data[4] y:source_px_data[5]							
							
							bone_root_px = source_px.boneRootTranslation
							addmodifier source source_px
							source_px.boneRootTranslation = bone_root_px
							restorePhysX source_px source_px_data
						)
					)
				)

				on mesh_smooth_bt pressed do undo "Tessellate Cloth" on
				(
					if ispolyobject (node = selectednode) do
					(
						setCommandPanelRedraw off parent:on
						sublevel = getsubobjectlevel()
						setsubobjectlevel sublevel undo:on							
						mode = setCommandPanelMode mode:2 level:&sublevel object:&obj
						
						smoothCloth node faces:#selection
						
						setCommandPanelMode mode:mode level:&sublevel object:&obj						
						setCommandPanelRedraw on parent:on	
					)
				)
				on mesh_smooth_bt rightclick do undo "Redo Cloth" on 
				(
					redoLastCloth()
				)
				
				on pre_smooth_bt changed state do
				(
					if state then 
					(
						owner.pre_tessellation = on
							
						owner.cloth_data = owner.storePhysX()
						
						mode = setCommandPanelMode mode:2
						setcureditobject (getreferencetarget selectednode)
					)
					else undo "Post Tessellate" on if not alt_ and not shift_ do
					(
						if isstruct (d0 = owner.cloth_data) and (node = selectednode) == d0.node do
						(
							vv = contains d0.maxdistance [0.01, FLT_MAX]
							ee = getusingonlypolyverts node vv level:#edge
							polyop.tessellateByEdge node ee
							
							p0 = unitepoint3tab x:d0.maxdistance y:d0.backstopoffset z:d0.backstopradius
							p1 = unitepoint3tab x:d0.latchnearest y:d0.latchgroup

							c0 = copy p0
							c1 = copy p1

							new_verts = tobits (d0.count+1) (numpolyverts node)

							vv = getpolyneighbors node dataarray:on distance:3
							ss = #{}
							for v=1 to vv.count where new_verts[v] do
							(
								b = vv[v] - new_verts
								if isset b then
								(
									c0[v] = c0[b].center
									c1[v] = c1[b].center
								)
								else append ss v
							)

							splitpoint3tab c0 x:d0.maxdistance y:d0.backstopoffset z:d0.backstopradius
							splitpoint3tab c1 x:d0.latchnearest y:d0.latchgroup

							--owner.fullClothReset owner.cloth_data node:node index:#all
						)
						owner.pre_tessellation = off
					)
					validateMacroButtons()
				)

				on missing_skin_bt pressed do undo "Select Unskinned" on
				(
					nodes = filterarray (getnodes selectednodes class:editable_poly) apply:hasskinmodifier
					count = 0
					for node in nodes do
					(
						local d = getpolyskindata node
						if isset (setskinselection node d.missing) do count += 1
					)
					[nodes.count, count]
				)

				fn deleteSkinVerts source verts:#selected = if ispolyobject source do
				(
					if isset (s_verts = getpolyvertsusing source verts level:#verts) do
					(
						setpolyvdata source #id channel:owner.TOPO_CH
							
						if (source_sk = getnodeskin source) != undefined then
						(
							v_num = numpolyverts source
							s_num = numskinverts source
							
							source_map = getskinmap source
							source_sel = getskinselection source

							source_px = findnodemodifier source class:physx_clothing
							source_apx = getApexClothAllChannels source_px

							holdskinweights source
							undoApexClothChannels source_px
							
							suspendModifyEditing undo:on
							deletePolyVerts source s_verts
							resumeModifyEditing undo:on
								
							vdata = getpolyvdata source channel:owner.TOPO_CH
							source_verts = makebits (numpolyverts source)
							target_verts = vdata[source_verts]
							result_map = copy source_map source:source_verts target:target_verts
							
							setskinmap source result_map undo:on
								
							result_sel = deletebits source_sel -s_verts
							setskinselection source result_sel undo:on

							if defined source_px do
							(
								result_apx = for ch in source_apx collect ch[target_verts]
								setApexClothAllChannels source_px result_apx 						
								redoApexClothChannels source_px
							)
						)
						else
						(
							deletePolyVerts source s_verts
						)
					)
				)
				
				on delete_faces_bt pressed do undo "Delete Faces" on if ispolyobject (source = selectednode) do with quiet on
				(
					if alt_ or owner.use_skin_selection do owner.convertSkinSelection node:source type:#poly level:#faces
					
					faces = getpolyselection source level:#faces
					if isset faces do
					(
						command_data = suspendCommandPanel enable:off parent:on mode:2 undo:on
						verts = getpolyvertsonlyusing source faces level:#faces
						deleteSkinVerts source verts:verts
						resumeCommandPanel enable:on parent:on mode:command_data[1] object:command_data[2] level:command_data[3] undo:on
					)
				)
				
				on delete_iso_verts_bt pressed do undo "Delete Iso Verts" on if ispolyobject (source = selectednode) do with quiet on
				(
					verts = meshop.getIsoVerts source.mesh
					if isset verts do
					(
						command_data = suspendCommandPanel enable:off parent:on mode:2 undo:on
						deleteSkinVerts source verts:verts				
						resumeCommandPanel enable:on parent:on mode:command_data[1] object:command_data[2] level:command_data[3] undo:on
					)
				)
				
				on detach_faces_bt pressed do undo "Detach Skin" on if ispolyobject (source = selectednode) do with quiet on
				(
					if alt_ or owner.use_skin_selection do owner.convertSkinSelection node:source type:#poly level:#faces
					
					faces = getpolyselection source level:#faces
					if isset faces do
					(
						command_data = suspendCommandPanel enable:off parent:on mode:2 undo:on
						name = source.name
						target = clonenodes source first:on
						target.wirecolor = darkcolor source.wirecolor 
						
						s_verts = getpolyvertsonlyusing source faces level:#faces
						deleteSkinVerts source verts:s_verts clean:off

						select target						
						t_verts = getpolyvertsonlyusing target -faces level:#faces
						deleteSkinVerts target verts:t_verts clean:on
						
						select source	
						resumeCommandPanel enable:on parent:on mode:command_data[1] object:command_data[2] level:command_data[3] undo:on
					)
				)
				
				fn attachSkinNode source target verts:#selected weld:off tolerance:0.001 = if ispolyobject source and ispolyobject target do
				(
					if isset (t_verts = getpolyverts target #all) do
					(
						setpolyvdata source #id channel:owner.TOPO_CH
						setpolyvdata target #id channel:owner.TOPO_CH offset:(numpolyverts source)
							
						if (source_sk = getnodeskin source) != undefined then
						(
							s_v_num = numpolyverts source
							s_s_num = numskinverts source
							
							t_v_num = numpolyverts target
							t_s_num = numskinverts target
							
							source_map = getskinmap source
							source_bones = getskinbones source set:on
							source_sel = getskinselection source

							target_map = getskinmap target
							target_bones = getskinbones target set:on
							target_sel = getskinselection target
														
							source_px = findnodemodifier source class:physx_clothing
							source_apx = getApexClothAllChannels source_px

							target_px = findnodemodifier target class:physx_clothing
							target_apx = if defined target_px then
							(
								getApexClothAllChannels target_px
							)
							else if defined source_px do
							(
								for ch in source_apx collect 
								(
									param = ch.parameter
									floattab t_s_num owner.physx_param_defaults[param] parameter:param
								)
							)
							
							holdskinweights source
							undoApexClothChannels source_px

							holdskinweights target
							undoApexClothChannels target_px


							all_bones = source_bones + target_bones
							if all_bones != source_bones do at time (getSkinRefFrame source)  
							(
								ordernodearray all_bones
								removeskinbone source #all
								addskinbone source all_bones update:on undo:off
								all_bones = getskinbones source
							)
							
							suspendModifyEditing undo:on
							attachpolynode source target
							if weld do weldpolyverts source border:on tolerance:tolerance
							resumeModifyEditing undo:on							
							
							source_remap = mapArrays all_bones source_bones
							reset source_map type:#remap target:source_remap
							target_remap = mapArrays all_bones target_bones
							reset target_map type:#remap target:target_remap					
							
							vdata = getpolyvdata source channel:owner.TOPO_CH
							source_verts = makebits s_v_num
							target_verts = makebits t_v_num
							
							source_verts = shiftbits target_verts (lastbit source_verts)
							result_map = source_map + copy target_map source:source_verts target:target_verts

							source_verts = makebits (numpolyverts source)
							target_verts = vdata[source_verts] --choice weld vdata[source_verts] source_verts
							
							--format ">>> % % = % >> %\n" s_v_num t_v_num (numpolyverts source) target_verts
							
							result_map = copy result_map source:source_verts target:target_verts
							setskinmap source result_map undo:on
							
							if defined source_px do
							(
								result_apx = for k=1 to source_apx.count collect 
								(
									ch = append (copy source_apx[k]) target_apx[k]
									ch[target_verts]
								)
								setApexClothAllChannels source_px result_apx
								storeclothdata source_px
								redoApexClothChannels source_px
							)
						)
						else
						(
							attachpolynode source target
							if weld do weldpolyverts source border:on tolerance:tolerance
						)
					)
				)
				
				fn resetSkinBonesTM node = if istruenode node and (sk = getnodeskin node) != undefined then
				(
					--sk_bones = getnodearray (filterarray (getskinbones node) apply:isbipednode invert:on) root:on
					sk_bones = getnodearray (getskinbones node) root:on
					hierarchySort sk_bones dir:1
					
					transforms = getNodesTransform sk_bones
					transforms.parameter = sk_bones
					setNodesTransform sk_bones (getskinbonesinittm node sk_bones)
					transforms
				)	
				fn setSkinBonesTM node transforms = if istruenode node and (sk = getnodeskin node) != undefined then
				(
					if ismatrix3tab transforms do setNodesTransform transforms.parameter transforms
				)					
				
				on attach_faces_bt picked target do undo "Attach" on, animate off, quiet on
				(
					if ispolyobject (source = selectednode) and ispolyobject target do
					(
						command_data = suspendCommandPanel enable:off parent:on mode:2 undo:on
							
						tms = resetSkinBonesTM source
						attachSkinNode source target weld:ctrl_ threshold:0.001
						setSkinBonesTM source tms
						
						resumeCommandPanel enable:on parent:on mode:command_data[1] object:command_data[2] level:command_data[3] undo:on
					)
				)

				local poly_base = undefined
				local ss_weights = floattab()
				local vs_weights = floattab()
				local current_px_data
				
				fn softClothPaint = if owner.ss_paint_mode do undo off
				(
					source = selectednode
					source_px = findnodemodifier source class:PhysX_Clothing
					--pblock2.enableNotifications source_px 1 off
					
					verts = getskinselection source
					--setpolyselection poly_base verts level:#verts
					bits = getPolyVSWeights poly_base verst:verts value:vs_weights \
						parameters:#(owner.ss_use_edgedist, owner.ss_edge_its, off, owner.ss_falloff, owner.ss_pinch, owner.ss_bubble) -- owner.ss_ignore_back (Ignore Backfacing) always OFF
					
					source_px_data = copy current_px_data[1]
					zeros = if owner.ss_ignore_zero then (contains source_px_data [0,0]) else #{}						
				
					vs_weights *= owner.ss_value
					
					k = 0					
					for b in bits where not zeros[b] do
					(
						k += 1
						source_px_data[b] = vs_weights[k]
					)
					
					--source_px.maxdistance = source_px_data.value
					pblock2.appendBlockFloatTabParam source_px #maxdistance source_px_data
					--pblock2.callBlockParamSet source_px #maxdistance
					source_px.paitingstyle = 0
					
					--pblock2.enableNotifications source_px 1 on
				)
				
				on ss_paint_mode_bt changed state do
				(
					if ispolyobject (source = selectednode) and (source_px = findnodemodifier source class:PhysX_Clothing) != undefined then
					(
						if state then
						(
							current_px_data = storePhysX source_px
							owner.last_cloth_action = #(source, source_px, deepcopy current_px_data, source_px.boneRootTranslation)

							owner.ss_paint_mode = state
							ss_apply_paint_bt.enabled = state
							poly_base = copy source.baseobject 
							verts = getskinselection source
							setpolyselectionlevel poly_base level:#verts
							setpolyselection poly_base verts level:#verts
							softClothPaint()
						)
						else 
						(
							mode = source_px.paintoperation + 1
							undo off 
							(
								px = owner.last_cloth_action[2]
								px_data = owner.last_cloth_action[3][1]
								--setproperty owner.last_cloth_action[2] #maxdistance owner.last_cloth_action[3][1].value
								pblock2.appendBlockFloatTabParam px #maxdistance px_data
								px.paitingstyle = 0
							)
							ss_apply_paint_bt.enabled = owner.ss_paint_mode = ss_paint_mode_bt.state = off
						)
					)
					else 
					(
						ss_apply_paint_bt.enabled = owner.ss_paint_mode = ss_paint_mode_bt.state = off
					)
				)
				on ss_apply_paint_bt pressed do undo "Apply Soft Paint" on
				(
					if ispolyobject (source = selectednode) and (source_px = findnodemodifier source class:PhysX_Clothing) != undefined then
					(
						mode = source_px.paintoperation + 1
						current_px_data = storePhysX source_px
						--undo off source_px.maxdistance = owner.last_cloth_action[3][1].value
						--source_px.maxdistance = current_px_data[1].value
						
						undo off pblock2.appendBlockFloatTabParam source_px #maxdistance owner.last_cloth_action[3][1] undo:off
						pblock2.appendBlockFloatTabParam source_px #maxdistance current_px_data[1] undo:on
						source_px.paitingstyle = 0
						
						owner.ss_paint_mode = ss_paint_mode_bt.state = off
						ss_apply_paint_bt.enabled = off
					)
				)
				
				fn isSelectedNode node = (node == selectednode)
					
				on pick_distance_bt changed state do
				(
					if state and ispolyobject (node = selectednode) and (px = findnodemodifier node class:PhysX_Clothing) != undefined then
					(
						if (pp = pickObject filter:isSelectedNode forceListenerFocus:off) == node do
						(
							wray = mapScreenToWorldRay mouse.pos
							
							face_hit = intersectMeshRayEx (snapshotasmesh node) wray dataArray:on
							if face_hit != undefined do
							(
								dd = (floattab px.maxdistance)[face_hit[6]]
								val = baryvalue dd face_hit[5]
								owner.ss_value = ss_value_sp.value = val
								softClothPaint()
								--format "% % % %\n" pp wray dd val
							)
						)
					)
					else
					(
						commandMode.clearPickMode()
					)
					pick_distance_bt.state = off
				)
				
				on ss_use_edgedist_ch changed state do 
				(
					owner.ss_use_edgedist = state
					ss_edge_its_sp.enabled = state
					softClothPaint()
				)
				on ss_edge_its_sp changed val do 
				(
					owner.ss_edge_its = val
					softClothPaint()
				)
				on ss_ignore_zero_ch changed state do 
				(
					owner.ss_ignore_zero = state
					softClothPaint()
				)
				on ss_ignore_back_ch changed state do 
				(
					owner.ss_ignore_back = state
					softClothPaint()
				)
				on ss_falloff_sp changed val do 
				(
					owner.ss_falloff = val
					softClothPaint()
				)
				on ss_pinch_sp changed val do 
				(
					owner.ss_pinch = val
					softClothPaint()
				)
				on ss_bubble_sp changed val do 
				(
					owner.ss_bubble = val
					softClothPaint()
				)
				on ss_value_sp changed val do 
				(
					owner.ss_value = val
					softClothPaint()
				)
				
				fn initBonesRightClick = 
				(
					if not owner.init_bone_mode then
					(
						node = selectednode
						
						if istruenode node and (sk = getnodeskin node) != undefined then
						(
							sk_bones = getnodearray (getskinbones node) root:on
							if ctrl_ do sk_bones = filterarray sk_bones filter:isbipednode invert:on
							
							hierarchySort sk_bones dir:1

							owner.bone_transforms = getNodesTransform sk_bones parameter:sk_bones
							setNodesTransform sk_bones (getskinbonesinittm node sk_bones) biped:on pos:off quiet:off
						)
					)
					else 
					(
						if ismatrix3tab owner.bone_transforms do setNodesTransform owner.bone_transforms biped:on pos:off quiet:off
						owner.init_bone_mode = off
					)
					reset_bone_fr.visible = owner.init_bone_mode
					completeredraw()
				)
				
				on init_bones_bt changed state do undo "Transform" on, quiet on	
				(
					quietUndo()	
					
					if state and not alt_ then
					(
						node = selectednode
						
						if istruenode node and (sk = getnodeskin node) != undefined then
						(
							sk_bones = getnodearray (getskinbones node) root:on
							if ctrl_ do sk_bones = filterarray sk_bones filter:isbipednode invert:on
							
							hierarchySort sk_bones dir:1

							owner.bone_transforms = getNodesTransform sk_bones parameter:sk_bones
							init_tms = getskinbonesinittm node sk_bones
							
							setNodesTransform sk_bones init_tms biped:on pos:shift_ quiet:off
							init_bones_bt.state = defined owner.bone_transforms
						)
						else
						(
							init_bones_bt.state = off
						)
					)
					else 
					(
						if ismatrix3tab owner.bone_transforms do setNodesTransform owner.bone_transforms biped:on pos:off quiet:off
						init_bones_bt.state = off
					)
					
					quietRedo()
					completeredraw()
				)
				
				on init_bones_bt rightclick do undo "Transform" (not init_bones_bt.state) --with quiet on	
				(	
					init_bones_bt.changed (not init_bones_bt.state)
				)
					
				on reapply_cloth_bt pressed do undo "Reapply Cloth" on
				(
					if ispolyobject (source = selectednode) and ismodifier (source_px = getnodemodifier source class:PhysX_Clothing) do
					(
						setCommandPanelRedraw off parent:on
						sublevel = getsubobjectlevel()
						setsubobjectlevel sublevel undo:on
						mode = setCommandPanelMode mode:2 level:&sublevel object:&obj

						source_sk = getnodeskin source
						
						all_sk_bones = getskinbones source source_sk
						sk_bones = filterarray all_sk_bones filter:isbipednode invert:on
						hierarchySort sk_bones dir:1
						
						owner.bone_transforms = getNodesTransformData sk_bones
						setSkinBonesToInitTM source bones:sk_bones
				
						source_sk_data = getskindata source	source_sk					
						source_px_data = storePhysX source_px

						deletemodifier source source_px
						deletemodifier source source_sk

						resetscale sk_bones 
						--source_sk = Skin()
						addmodifier source source_sk
						if source_sk.AlwaysDeform do source_sk.AlwaysDeform = off
						source_sk.AlwaysDeform = on
		
						addskinbone source source_sk all_sk_bones
						setskindata source source_sk_data
						
						addmodifier source source_px
						restorePhysX source_px source_px_data
						owner.setDefaultClothParams px

						if ismatrix3tab owner.bone_transforms do setNodesTransformData owner.bone_transforms rescale:on
					
						setCommandPanelMode mode:mode level:&sublevel object:&obj						
						setCommandPanelRedraw on parent:on	
							
						completeredraw()
					)
				)

				fn redoLastCloth = try
				(
					setCommandPanelRedraw off parent:on	 
					sublevel = getsubobjectlevel()
					setsubobjectlevel sublevel undo:on
					mode = setCommandPanelMode mode:2 level:&sublevel object:&obj
					
					replacemodifier owner.last_cloth_action[1] owner.last_cloth_action[2] owner.last_cloth_action[2]
					owner.last_cloth_action[2].boneRootTranslation = owner.last_cloth_action[4]
					undo off restorePhysX owner.last_cloth_action[2] owner.last_cloth_action[3]
					
					setCommandPanelMode mode:mode level:&sublevel object:&obj						
					setCommandPanelRedraw on parent:on
				)
				catch()
				
				on redo_cloth_bt pressed do undo "Redo Cloth" on
				(
					resetModifier owner.last_cloth_action[1] owner.last_cloth_action[2]
					restorePhysX owner.last_cloth_action[2] owner.last_cloth_action[3]
				)
				--on redo_cloth_bt pressed do undo "Redo Cloth" on redoLastCloth()
				on redo_cloth_bt rightclick do undo "Redo Cloth" on redoLastCloth()
				
				fn updateClothTargets data: = 
				(
					if data == unsupplied then data = owner.cloth_xchange_data else owner.cloth_xchange_data = data
					if isset data do
					(
						selected = cloth_targets_bx.selected
						cloth_targets_bx.items = for d in data collect (if d.px_data != undefined then "X" else "S") + "      " + d.name
						if (k = finditem cloth_targets_bx.items selected) != 0 do cloth_targets_bx.selection = k
					)
				)

				on wrap_source_type_rb rightclick do if istruenode (source = selectednode) and hasskinmodifier source do
				(
					verts = if owner.wrap_source_type == 1 then numskinvertices source else getskinselection source
					verts = makebits verts
					process_ed.text = tostring (numbits verts)	
				)
				
				local wrap_channels_cc = #(wrap_maxdistance_ch, wrap_backstopoffset_ch, wrap_backstopradius_ch, wrap_latchnearest_ch, wrap_latchgroup_ch)
				
				on store_cloth_bt pressed do undo "Store Cloth" off
				(
					local channels = if ctrl_ then #all else (inttobits owner.wrap_channels)
					for node in selectednodes where ispolyobject node and ismodifier (px = getnodemodifier node class:PhysX_Clothing) do
					(
						storeclothdata px id:10 channels:channels undo:on
					)
				)
				on restore_cloth_bt pressed do undo "Restore Cloth" on
				(
					local channels = if ctrl_ then #all else (inttobits owner.wrap_channels)
					for node in selectednodes where ispolyobject node and ismodifier (px = getnodemodifier node class:PhysX_Clothing) do
					(
						--verts = makebits (numpolyverts node)
						
							
						if ctrl_ then
						(
							owner.getProtectedVerts node
							verts = -owner.cloth_hidden_verts
							resetclothdata px id:10 channels:channels filter:verts undo:on
						)
						else if alt_ then
						(
							owner.getProtectedVerts node
							verts = owner.cloth_hidden_verts
							resetclothdata px id:10 channels:channels filter:verts undo:on
						)
						else
						(
							restoreclothdata px id:10 channels:channels undo:on --update:off
						)
					)
				)
				
				on wrap_source_type_rb changed state do owner.wrap_source_type = state
				on wrap_select_missing_sp changed val do owner.wrap_select_missing = val
				on wrap_distance_sp changed val do owner.wrap_distance = val
				on wrap_power_sp changed val do owner.wrap_power = val
				on wrap_count_sp changed val do owner.wrap_count = val
				on wrap_exact_sp changed state do owner.wrap_exact = state
				on wrap_skin_sp changed state do owner.wrap_skin = state
				on wrap_cloth_sp changed state do 
				(
					owner.wrap_cloth = state
					wrap_channels_cc.enabled = state
				)
				
				fn setWrapChannels index state = 
				(
					if ctrl_ then 
					(
						owner.wrap_channels = setibits owner.wrap_channels #{1..5} on
					)
					else if shift_ then 
					(
						owner.wrap_channels = setibits owner.wrap_channels #{1..5} off
						owner.wrap_channels = setibit owner.wrap_channels index on
					)
					else owner.wrap_channels = setibit owner.wrap_channels index state

					if index == 4 do owner.wrap_channels = setibit owner.wrap_channels 5 (getibit owner.wrap_channels index)
					if index == 5 do owner.wrap_channels = setibit owner.wrap_channels 4 (getibit owner.wrap_channels index)					
					
					for k=1 to wrap_channels_cc.count do setrolloutcontrolvalue wrap_channels_cc[k] value:(getibit owner.wrap_channels k) triState:off exact:off	
				)
				
				
				on wrap_maxdistance_ch changed state do (setWrapChannels 1 state)
				on wrap_backstopoffset_ch changed state do (setWrapChannels 2 state)
				on wrap_backstopradius_ch changed state do (setWrapChannels 3 state)
				on wrap_latchnearest_ch changed state do (setWrapChannels 4 state)
				on wrap_latchgroup_ch changed state do (setWrapChannels 5 state)
				
				on wrap_initial_mesh_ch changed state do owner.wrap_initial_mesh = state
				
				on mirror_use_target_sp changed state do owner.mirror_use_target = state
				on mirror_use_normal_sp changed state do owner.mirror_use_normal = state
				on mirror_hat_mode_sp changed state do owner.mirror_hat_mode = state
				on mirror_plane_rb changed state do owner.mirror_plane = state
					
				on copy_cloth_bt pressed do
				(
					nodes = if ctrl_ then geometry else selectednodes
						
					data = for node in nodes where ispolyobject node and hasskinmodifier node collect 
					(
						sk = getnodeskin node
						sk_verts = getskinselection node sk
						sk_data = getpolyskindata node
						px = findnodemodifier node class:PhysX_Clothing
						px_data = if px != undefined do storePhysX px
							
						kd3_cur = kd3tree node

						sk.enabled = off
						kd3_ini = kd3tree node
						sk.enabled = on
							
						--format "% >> %\n" node.name (bbox3 kd3.value)
						owner.XChangeData node:node name:node.name verts:sk_verts sk:sk sk_data:sk_data px:px px_data:px_data kd3:kd3_cur kd3_ini:kd3_ini
					)
					if isset data do
					(
						nsort data
						paste_cloth_bt.enabled = on
						owner.cloth_xchange_data = data
						updateClothTargets()
					)
				)
				on copy_cloth_bt rightclick do undo "Select Source" on
				(
					if (k = cloth_targets_bx.selection) != 0 do 
					(
						source = findnodesbyname name:owner.cloth_xchange_data[k].name first:on
						if istruenode source then select source else clearselection()
					)
				)

				on paste_cloth_bt pressed do undo "Cloth Wrap" on
				(
					if ispolyobject (source = selectednode) and (source_sk = getnodeskin source) != undefined do
					(
						k = cloth_targets_bx.selection
						if k <= owner.cloth_xchange_data.count do
						(
							local d = owner.cloth_xchange_data[k]
							
							setCommandPanelRedraw off parent:on
							sublevel = getsubobjectlevel()
							setsubobjectlevel sublevel undo:on
							mode = setCommandPanelMode mode:2 level:&sublevel object:&obj
														
							target_kd3 = if owner.wrap_initial_mesh then d.kd3_ini else d.kd3
							target_sk_data = d.sk_data
							target_px_data = d.px_data
							
							source_sk_data = getpolyskindata source
							source_px = findnodemodifier source class:PhysX_Clothing
							
							if owner.wrap_cloth and source_px != undefined do
							(
								holdclothdata source_px id:20 
							)
							
							if owner.wrap_initial_mesh then
							(
								source_sk.enabled = off
								source_pp = point3tab source time:0
								source_sk.enabled = on
							)
							else
							(
								source_pp = point3tab source time:0
							)

							source_numv = source_sk_data.count
							working_verts = if owner.wrap_source_type == 1 then makebits source_numv else getskinselection source

							wrap_px_data = getKd3TreeWeightTable target_kd3 source_pp verts:working_verts distance:owner.wrap_distance count:owner.wrap_count exact:owner.wrap_exact value:owner.wrap_power 
							
							process_verts = #{}
							working_verts = wrap_px_data.b
							
							if owner.wrap_skin and source_sk != undefined do
							(
								target_sk_map = target_sk_data.map
								source_sk_map = source_sk_data.map
								
								for v in wrap_px_data where isset (tab = wrap_px_data[v]) do
								(
									append process_verts v
									ww = target_sk_map[tab]
									source_sk_map[v] = normalizeskinweights ww distance:on
								)
								setskindata source source_sk_map undo:on --anim:on
							)
							
							if owner.wrap_cloth and source_px != undefined do
							(
								if countclothdata source_px != source_numv do 
								(
									setcureditobject source_px
									replacemodifier source source_px source_px
									--initclothdata source_px count:source_numv notifyafteraccept:on
								)
									
								source_px_data = storePhysX source_px
								current_px_data = deepcopy source_px_data
								owner.last_cloth_action = #(source, source_px, deepcopy source_px_data, source_px.boneRootTranslation)
								
								for v in wrap_px_data where isset (tab = wrap_px_data[v]) do
								(
									append process_verts v
									
									ww = tab.z	
									ii = tab.w
									
									for n=1 to target_px_data.count do
									(
										vv = ww * target_px_data[n][ii]
										source_px_data[n][v] = vv.length
									)
								)
								--for n=1 to target_px_data.count do reset source_px_data[n] type:#count count:source_numv value:(pblock2.getBlockParamDefaultValue source_px physx_param_names[n]) 
																
								restorePhysX source_px source_px_data comp:current_px_data channels:(inttobits owner.wrap_channels)
								source_px.paitingstyle = 0
								
								acceptclothdata source_px id:20
							)
							
							missing_verts = working_verts - process_verts
							
							process_ed.text = tostring (numbits process_verts)	
							missing_ed.text = tostring (numbits missing_verts)

							if owner.wrap_select_missing do setskinselection source missing_verts
							
							setCommandPanelMode mode:mode level:&sublevel object:&obj						
							setCommandPanelRedraw on parent:on	
						)
					)
				)
				on paste_cloth_bt rightclick do if istruenode (source = selectednode) and hasskinmodifier source do
				(
					name = source.name
					k = for k=1 to owner.cloth_xchange_data.count where owner.cloth_xchange_data[k].name == name do exit with k
					cloth_targets_bx.selection = if isnumber k then k else 0 
				)

				on mirror_x_cloth_bt pressed do undo "Mirror Cloth" on
				(
					if ispolyobject (source = selectednode) and (source_px = getnodemodifier source class:PhysX_Clothing) != undefined do
					(
						target_kd3 = undefined
						if owner.mirror_use_target and false then
						(
							k = cloth_targets_bx.selection
							if k <= owner.cloth_xchange_data.count do
							(
								local d = owner.cloth_xchange_data[k]
								target_kd3 = d.kd3
								target_sk_data = d.sk_data
								target_px_data = d.px_data
							)
						)
						else
						(
							target_kd3 = kd3tree source
							target_sk_data = getpolyskindata source
							target_px_data = storePhysX source_px
						)
						if target_kd3 != undefined do
						(
							--setCommandPanelRedraw off parent:on
							--sublevel = getsubobjectlevel()
							--setsubobjectlevel sublevel undo:on
							--mode = setCommandPanelMode mode:2 level:&sublevel object:&obj
							
							source_sk_data = getpolyskindata source
							source_pp = getPolyVertRay source #all time:0
							
							xtm = makeMirrorMatrix3 axis:(choice (owner.mirror_plane == 1) #x #z)
							reset source_pp type:#apply value:xtm
							
							source_numv = source_sk_data.count
							working_verts = getskinselection source
							exclude_verts = choice (owner.mirror_use_target and false) #{} working_verts
							
							--t0 = xtime()
							wrap_px_data = getKd3TreeWeightTable target_kd3 source_pp verts:working_verts clear:exclude_verts \
								distance:owner.wrap_distance count:owner.wrap_count exact:owner.wrap_exact value:owner.wrap_power dir:owner.mirror_use_normal
							--t1 = xtime()
							process_verts = #{}
							
							/*
							if owner.wrap_skin and source_sk != undefined do
							(
								target_sk_map = target_sk_data.w
								source_sk_map = source_sk_data.w
								
								for v in wrap_px_data where isset (tab = wrap_px_data[v]) do
								(
									append process_verts v
									ww = target_sk_map[tab]
									source_sk_map[v] = normalizeskinweights ww distance:on
								)
								setskindata source source_sk_map undo:on
							)
							*/
							
							if owner.wrap_cloth and source_px != undefined do
							(
								source_px_data = storePhysX source_px
								current_px_data = deepcopy source_px_data
								owner.last_cloth_action = #(source, source_px, deepcopy source_px_data, source_px.boneRootTranslation)
								
								t2 = xtime()
								for v in wrap_px_data where isset (tab = wrap_px_data[v]) do
								(
									append process_verts v
									
									ww = tab.z	
									ii = tab.w
									
									for n=1 to target_px_data.count do
									(
										vv = ww * target_px_data[n][ii]
										source_px_data[n][v] = vv.length
									)
								)
								--t3 = xtime()
								--deletemodifier source source_px
								--addmodifier source source_px
								
								restorePhysX source_px source_px_data comp:current_px_data --index:working_verts 
								source_px.paitingstyle = 0
								--source_px.Rebuild()
								--notifydependents source_px -- partid:#disp
								
								--format "% >>> % % % = %\n" source_px_data[1].count (t1-t0) (t2-t1) (t3-t2) (t3-t0)
							)
							
							missing_verts = working_verts - process_verts
							
							process_ed.text = tostring (numbits working_verts)	
							missing_ed.text = tostring (numbits missing_verts)

							if owner.wrap_select_missing do setskinselection source missing_verts
							
							--setCommandPanelMode mode:mode level:&sublevel object:&obj						
							--setCommandPanelRedraw on parent:on	
						)
					)
				)
				
				on mirror_x_cloth_bt rightclick do undo "Mirror Select" on
				(
					if ispolyobject (source = selectednode) and (source_sk = getnodeskin source) != undefined do
					(
						target_kd3 = kd3tree source
				
						source_sk_data = getpolyskindata source
						source_pp = point3tab source time:0
						xtm = makeMirrorMatrix3 axis:(choice (owner.mirror_plane == 1) #x #z)
						reset source_pp type:#apply value:xtm
						
						working_verts = getskinselection source
						exclude_verts = #{}
						
						wrap_px_data = getKd3TreeWeightTable target_kd3 source_pp verts:working_verts clear:exclude_verts \
							distance:owner.wrap_distance count:owner.wrap_count exact:owner.wrap_exact value:owner.wrap_power 
						
						process_verts = #{}
						xmirror_verts = #{}
						
						for v in wrap_px_data where isset (tab = wrap_px_data[v]) do
						(
							append process_verts v
							join xmirror_verts tab.b
						)
						
						missing_verts = working_verts - process_verts
						
						process_ed.text = tostring (numbits process_verts)	
						missing_ed.text = tostring (numbits missing_verts)

						setskinselection source xmirror_verts
					)
				)
				
				on rebuild_cloth_bt pressed do undo "Rebuild Cloth" on
				(
					if ispolyobject (source = selectednode) and (source_px = getnodemodifier source class:PhysX_Clothing) != undefined do
					(
						setCommandPanelRedraw off parent:on
						sublevel = getsubobjectlevel()
						setsubobjectlevel sublevel undo:on
						mode = setCommandPanelMode mode:2 level:&sublevel object:&obj
													
						source_px_data = storePhysX source_px
						--deletemodifier source source_px
						--addmodifier source source_px
						bone_root_px = source_px.boneRootTranslation
						replacemodifier source source_px source_px
						source_px.boneRootTranslation = bone_root_px
						restorePhysX source_px source_px_data
						--pblock2.callBlockSets source_px 1
						--source_px.Rebuild()
						
						setCommandPanelMode mode:mode level:&sublevel object:&obj						
						setCommandPanelRedraw on parent:on	
					)
				)
				on rebuild_cloth_bt rightclick do undo "Rebuild Cloth" on
				(
					if ispolyobject (source = selectednode) and (source_px = getnodemodifier source class:PhysX_Clothing) != undefined do
					(
						--source_px_data = storePhysX source_px
						--reapplymodifier source source_px 
						replacemodifier source source_px source_px
						--restorePhysX source_px source_px_data
						pblock2.callBlockSets source_px 1
						--source_px.Rebuild()
					)
				)				


				local snap_mesh
				local snap_verts
				local snap_data
				
				fn mouseClothTracking msg ir obj faceNum shift ctrl alt =
				(
					--format "% >> % (%) <%> (%,%,%)\n" msg ir (getMouseButtonStates()) _flags_ shift ctrl alt
					
					if not track_cloth_data_bt.state then
					(
						return (commandMode.clearPickMode())
					)
					if ispolyobject (node = selectednode) and hasmodifier node class:PhysX_Clothing do 
					(
						case of
						(
							(msg == #mouseAbort): ()
							(msg == #mouseMove or msg == #mouseDown): 
							(
								--wray = mapScreenToWorldRay mouse.pos
								--face_hit = intersectMeshRayEx snap_mesh wray dataArray:on
								--format ">> %\n" face_hit
								
								snap_verts = getpolyhidden node level:#verts invert:on
								--snap_verts = #all
								
								v = closestMeshVert snap_mesh mouse.pos verts:snap_verts snap:#2D --value:#3d
								--format ">> %\n" v
								if (v > 0) do
								(
									for k=1 to snap_data.count do
									(
										c = channel_val_controls[k]
										d = snap_data[k][v]
										if d >= FLT_MAX then
										(
											c.indeterminate = on
										)
										else
										(											
											c.indeterminate = off
											if k == 5 do d = inttobits d first:on
											setRolloutControlValue c value:d exact:off
										)
										--format "% > %\n" k d
									)
								)
								
							)
							(msg == #mousePoint): ()
							(msg == #freeMove): ()
						)
					)
					
					if msg == #mouseAbort then #abort else #continue 
				)
				on track_cloth_data_bt changed state do
				(
					if state and ispolyobject (node = selectednode) and ismodifier (px = getnodemodifier node class:PhysX_Clothing) then 
					(
						snap_mesh = snapshotasmesh node
						--hidden_verts = meshop.getHiddenVerts snap_mesh
						--meshop.deleteverts snap_mesh hidden_verts
						
						snap_verts = getpolyhidden node level:#verts invert:on
						snap_data = storePhysX px
						
						act = mouseTracker mode:-1 trackCallback:mouseClothTracking snap:#3D
						track_cloth_data_bt.state = off
					)
					else state = off
					
					if not state do
					(
						commandMode.clearPickMode()
						track_cloth_data_bt.state = off
					)
				)
				
				local tool_controls = #(ez_physx_bt, cloth_wrap_bt)
				local tool_rollouts = #(#{1..5}, #{7..10})
				
				fn setCurrentTool id: =
				(
					if id == unsupplied then id = owner.current_tool else owner.current_tool = id
					owner.current_tool = id = if isnumber id then (clamp id min:0 max:1) else 0 

					--(rolloutOps.getGroup dialog 10).visible = off
										
					for k=1 to tool_controls.count do
					(
						act = ((k-1) == id)
						ICustButton.setCheck tool_controls[k] act exact:off

						for i in tool_rollouts[k] do
						(
							cc = rolloutOps.getGroup owner.dialog i
							cc.visible = act
							mapfunction winapi.showwindow cc act
						)
					)
					if (id == 1) do setspinnerreadonly channel_val_controls on showReset:on
					setfocus emp_10	

					--(rolloutOps.getGroup dialog 10).visible = off
				)
				on ez_physx_bt changed state do setCurrentTool id:0
				on cloth_wrap_bt changed state do setCurrentTool id:1
				
				fn isDockable = winapi.isdockabledialog this_dialog
				fn toggleDockable =
				(
					local dockable = isDockable()
					local hwnd = owner.dialog
					
					if not dockable then
					(
						hwnd = icui.registerdialog owner.dialog style:dialog.cui_tool
						winapi.hookWindowSize hwnd fixed:on
					)
					else
					(
						icui.unregisterdialog owner.dialog
						hwnd = owner.dialog
					)
					hwnd 
				)
				
				fn pickSysMenu sender id = 
				(
					--format ">>>>>>> dialog: >> % == %\n" hwnd id (id == (wcrc32 "Dockable"))
						
					if (id == wcrc32 "Dockable") do
					(
						local hwnd = toggleDockable()
						if (winapi.hasSystemMenu hwnd) do
						(
							if not (winapi.hasSystemMenuItem hwnd id) do winapi.insertSystemMenuItem hwnd "Dockable" pos:0 separator:1 id:&id
							winapi.checkSystemMenuItem hwnd id state:(isDockable())
						)
						winapi.hookWindowSysMenu hwnd action:owner.dialog.pickSysMenu
					)
				)

				on dialog close do
				(
					winapi.hidewindow owner.dialog
					icui.unregisterdialog owner.dialog
					owner.parent_hwnd = unsupplied
					--removeCallbacks()

					owner.deletecallbacks()
					owner.protect_mode = off
								
					owner.dialog_pos = getdialogpos owner.dialog
					iniops.set owner.ini_file #PhysXOps #pos (owner.dialog_pos as string)
					owner.dialog_size = getdialogsize owner.dialog
					iniops.set owner.ini_file #PhysXOps #size (owner.dialog_size as string)
					owner.dialog_rect = rolloutops.getdialogrect owner.dialog
					iniops.set owner.ini_file #PhysXOps #rect (owner.dialog_rect as string)
					owner.saveINISettings()

					checkmaxmessages()
					owner.opened = off
					validateMacroButtons()
				)
				
				local framed_bts = #(mesh_smooth_bt, protect_mode_bt, redo_cloth_bt, init_bones_bt, fix_skewed_bones_bt, rescale_bones_bt)
				
				on dialog open do
				(
					dialog.title = owner.title
					owner.opened = on
					
					setCurrentTool()
					
					if owner.protect_auto_startup do
					(
						owner.deleteCallbacks()
						protect_mode_bt.state = owner.protect_mode = on
						restore_current_channel_bt.enabled = off
						owner.createCallbacks()
						
						confirmProtectMode()
					)

					frs = this_controlset[framecontrol]
					bts = fmap_ getuicontrolkeyparam frs #target setreturn:on
					
					setcontrolround bts radius:rd_ size:sz_ scale:on -- framed_bts
					
					updateClothTargets()
					setspinnerresetvalue wrap_power_sp 1
					--setspinnerreadonly channel_val_controls on showReset:on
					
					validateMacroButtons()				
				)
			)
		),
		fn isOpened = 
		(
			opened and (choice dialog (bool (winapi.iswindowopen dialog)) off)
		),
		fn create = 
		(
			destroy()

			local hwnd = dialog
			local dockable = shift_

			loadINISettings()
			dialog.owner = this
							
			createdialog dialog pos:(choice (esc_ or ctrl_) unsupplied dialog_pos) parent:parent_hwnd
			winapi.setwindowicon dialog icon:#dts
			winapi.insertSystemMenuItem dialog "Dockable" pos:0 separator:1 id:&id checked:off
				
			if dockable do
			(
				hwnd = icui.registerdialog dialog style:dialog.cui_tool
				winapi.hookWindowSize hwnd fixed:on
				winapi.insertSystemMenuItem hwnd "Dockable" pos:0 separator:1 id:&id checked:on
			)
			winapi.hookWindowSysMenu hwnd action:dialog.pickSysMenu

			ok
		),	
		
		dialog_action = ok,
		
		on create do
		(
			destroy()
			--createCallbacks this:this
			--validateMacroButtons()
		)
	)
	global _px = SEASUN_PhysXOps = SEASUN_PhysXOps_struct()
	--SEASUN_PhysXOps.createCallbacks()
	SEASUN_PhysXOps.last_cloth_action = last_cloth_action
	SEASUN_PhysXOps.cloth_xchange_data = cloth_xchange_data
	
	SEASUN_PhysXOps_exec_d = globalvars.getvalue #SEASUN_PhysXOps
	if SEASUN_PhysXOps_exec_d != undefined do
	(
		if not SEASUN_PhysXOps_exec_d.isopened() then
		(
			SEASUN_PhysXOps_exec_d.parent_hwnd = windows.getMaxHWND()
			SEASUN_PhysXOps_exec_d.create()
		)
		else
			SEASUN_PhysXOps_exec_d.destroy()
	)
	ok
)
--setCommandPanelRedraw on parent:on
