d = try (globalvars.getvalue #SEASUN_SceneCleanup) catch()
if isstruct d do
(
    if shift_ then
    (
        d.create()
    )
    else
    (
        if d.opened then
            d.destroy()
        else
        (
            undo "SEASUN Scene Cleanup" on
            (
                setwaitcursor()
                SuspendEditing()
                with_suspend_except #(#undo)                 (
                    result = asbool (d.cleanupScene event:#macro)
                )
                ResumeEditing()
                setarrowcursor()

                completeredraw()
                validateMacroButtons()

                result
            )
        )
    )
)
