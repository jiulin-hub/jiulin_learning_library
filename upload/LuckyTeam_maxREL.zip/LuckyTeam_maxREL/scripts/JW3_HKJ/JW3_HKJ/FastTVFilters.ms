d = globalvars.get #DTS_FastTVFilters
if isstruct d do
(
    d.updateDialog()
    if d.dialog.opened then
        d.closeDialog()
    else
        d.openDialog()
)
