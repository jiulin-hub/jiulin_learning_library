d = globalvars.get "ShowGCStatusDisplay"
if isstruct d do
(
    if keyboard.escpressed then
        gc light:on
    else
    (
        if keyboard.shiftpressed then
            d.toggleLabel()
        else
            d.toggle updateUI:off
    )
)
