d = globalvars.getvalue #SEASUN_QuickBips
if istruestruct d do
(
    undo off
    (
        if not istrueobject d.QPoseCA do
        (
            d.QPoseCA = d.createQuickPoseEdit()
        )

        if not d.isposeeditopened() then
            d.createPoseEdit()
        else
            d.destroyPoseEdit()

        validateMacroButtons()
    )
)
