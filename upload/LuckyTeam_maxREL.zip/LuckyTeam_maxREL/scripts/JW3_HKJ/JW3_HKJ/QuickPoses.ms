d = globalvars.getvalue #SEASUN_QuickBips
if istruestruct d do
(
    if not d.islibsopened() then
        d.createLibrary()
    else
        d.destroyLibrary()

    validateMacroButtons()
)
