if getnodes selectedNodes class:editable_poly any:on do
(
    undo "Select Under Mouse" on
    (
        wray = mapScreenToWorldRay mouse.pos
        nodes = getnodes selectednodes class:editable_poly
        meshes = for node in nodes collect node.baseobject.mesh
        inode = intersectMeshesRay meshes wray first:on

        if inode != undefined do
        (
            node = inode[1]
            face = inode[4]
            elems = getMeshElements node faces:face
            vv = getmeshvertsusing node elems[1]
            ff = getusingpolyverts node vv 3

            ff0 = getpolyselection node 3

            if shift_ then
                ff += ff0
            else if alt_ do
                ff = ff0 - ff

            vv0 = getpolyvertsusing node ff level:3 select:on
            hidePolyVerts node verts:vv0 type:#invert
            setpolyselection node 3 ff

            update node
        )
    )
)
