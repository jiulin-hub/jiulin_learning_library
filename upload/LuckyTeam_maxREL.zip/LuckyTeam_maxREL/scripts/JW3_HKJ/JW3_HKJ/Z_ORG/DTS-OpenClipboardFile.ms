d = try (globalvars.getvalue #DTS_OpenRecent) catch ()
if isstruct d do
(
    if checkForSave() do
    (
        file = if istruefile (f = clipboardtext) then f else clipboardfile
        if istruemaxfile file do
        (
            quiet_on = shift_
            with quiet quiet_on
            (
                loadmaxfile file quiet:quiet_on usefileunits:d.use_file_units
            )
            inotifycallbacks.broadcastcallback code:d.NOTIFY_FILE_POST_OPEN parameter:0
        )
        updateToolbarButtons()
    )
)
