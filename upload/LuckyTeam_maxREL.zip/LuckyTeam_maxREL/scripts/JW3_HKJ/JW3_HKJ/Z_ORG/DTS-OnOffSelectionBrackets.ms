sett = nitrous_settings_
if isinterface sett do undo "Toggle Brackets" on
(
    if shift_ then
    (
        enableSelectionBrackets (not nitrous_settings_.ShowSelectionBracketsEnabled)
    )
    else
    (
        toggle_ &nitrous_settings_.ShowSelectionBracketsEnabled
        completeRedraw()
    )
)
