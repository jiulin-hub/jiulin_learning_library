d = globalvars.getvalue #SEASUN_BatchControl
if d != undefined do
(
    if not d.isopened() then
    (
        d.parent_hwnd = windows.getMaxHWND()
        d.create()
    )
    else
        d.destroy()

    validateMacroButtons()
)
