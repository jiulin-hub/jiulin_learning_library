sett = nitrous_settings_
if isinterface sett do
(
    if shift_ then
    (
        enableProgressiveRendering (not nitrous_settings_.ProgressiveRenderingEnabled)
    )
    else
    (
        setProgressiveRenderingEnabled #invert
        completeRedraw()
    )
)
