owner = undefined
d = undefined
_sett = nitrous_settings_

				NitrousStyleRolloutOps =
				(
					struct NitrousStyleRolloutOps
					(
					private
						modes = "#Realistic|#Shaded|#Facets|#ConsistentColors|#HiddenLine|#Wireframe|#BoundingBox|#Ink|#ColorInk|#Acrylic|#Tech|#Graphite|#ColorPencil|#Pastel|#Clay",
						presets = "#Quality|#Standard|#Performance|#DXMode|#Customize",
					public
						fn saveNitrousStyle rol style: filename: =
						(
							result = undefined

							if notdefined filename do filename = getsavefilename caption:"Save Nitrous Style Preset" types:"Nitrous Style File(*.nst)|*.nst"
							if notdefined style do style = rol.styles_dd.selected
							if isstringvalue filename do
							(
								for c in rol.controls do
								(
									name = splitname c.name
									if name[2] == #cb or name[2] == #sp do
									(
										val = getrolloutcontrolvalue c
										iniops.set filename style name[1] (tostring val)
									)
								)
								result = filename
							)
							result
						),

						fn loadNitrousStyle rol style: filename: =
						(
							result = false

							if notdefined filename do filename = getopenfilename caption:"Load Nitrous Style Preset" types:"Nitrous Style File(*.nst)|*.nst"
							if notdefined style do style = rol.styles_dd.selected
							if isstringvalue filename do with redraw off
							(
								sett = nitrous_settings_
								params = for k=1 to sett.GetNPRParameterCount() collect (sett.GetNPRParameterName k)

								if iniops.has filename style do for c in rol.controls do
								(
									name = splitname c.name
									if (cb = (name[2] == #cb)) or name[2] == #sp do
									(
										if defined (val = iniops.get filename style name[1]) do
										(
											v = executestring val
											setrolloutcontrolvalue c value:v
											if isset (sfind params name[1]) do
											(
												if cb then sett.SetNPRBool name[1] (bool v) else sett.SetNPRFloat name[1] v
											)
											result = true
										)
									)
								)
							)
							redrawviews()

							result
						),

						fn enableParameters rol style: =
						(
							sett = nitrous_settings_
							if notdefined style do style = nitrous_style_
							if (nitrous_style_ != style) do nitrous_style_ = style

							rol.styles_dd.selection = sfind rol.names style
							bits = #{}
							for k=1 to sett.GetNPRParameterCount() do
							(
								prop = sett.GetNPRParameterName k
								_prop = prop + "*"
								join bits (sfind rol.controls _prop first:off)
							)
							for k=1 to rol.controls.count where iskindof (c = rol.controls[k]) EmptyControl or iskindof c SpinnerControl or iskindof c CheckBoxControl do
							(
								act = c.enabled = hasbits bits k
								if iskindof c EmptyControl do c.label = choice act dimorange litegray
								if act do
								(
									if iskindof c SpinnerControl do c.value = sett.GetNPRFloat (splitstring c.name #_)[1]
									if iskindof c CheckBoxControl do c.state = sett.GetNPRBool (splitstring c.name #_)[1]
								)
							)
							redrawviews()
							winapi.redrawwindow rol
						),

						on create do
						(
							destroydialog_ #DTS_NitrousStyleSetup
						)
					)
				)

				top_menu =
				(
					rcmenu top_menu
					(
						ops = if ops != undefined do ops
						d = if defined d do d
						sett = nitrous_settings_
						ngm = NitrousGraphicsManager
						fn _enabled = defined ngm and ngm.IsEnabled() and isrollout d
						enabled = _enabled()

						viewID
						veiwIndex
						fn getViewIndex =
						(
							viewID = getActiveViewport()
							viewIndex = viewID + 1
						)

						antialias_quality = antialias_quality
						fn getAntialiasQuality =
						(
							antialias_quality = ngm.AntialiasingQuality
							case antialias_quality of
							(
								#none: "None"
								  #2X: "Low"
								  #4X: "Good"
								  #8X: "High"
							)
						)

						darker_edge_option = darker_edge_option
						fn getDarkerEdgeOption =
						(
							darker_edge_option = ngm.DarkerEdgeOption
							case darker_edge_option of
							(
								 #Off: "Off"
						#SubLevelOnly: "Sub Level Only"
							  #Always: "Always"
							)
						)

						shadow_quality = shadow_quality
						fn getShadowQuality =
						(
							shadow_quality = sett.LightingAndShadowQualityMode
							case of
							(
								(shadow_quality == #SoftEdgedShadows)	: "Soft"
								(shadow_quality == #HardShadows) 		: "Hard"
								(shadow_quality == #1x) 				: "Normal"
								default: "Custom"
							)
						)
						shadow_intensity = shadow_intensity
						fn getShadowIntensity =
						(
							shadow_intensity = sett.ShadowIntensity
							case of
							(
								(shadow_intensity <= 0.25): "Lite"
								(shadow_intensity < 0.75) : "Half"
								default: "Full"
							)
						)

						occlusion_intensity = occlusion_intensity
						fn getAmbientOcclusionIntensity =
						(
							occlusion_intensity = sett.AmbientOcclusionIntensity
							case of
							(
								(occlusion_intensity <= 0.25): "Lite"
								(occlusion_intensity < 0.75) : "Half"
								default: "Full"
							)
						)

						fn toggleProperty prop =
						(
							setproperty sett prop (not (getproperty sett prop))
						)

						fn sureProperty prop =
						(
							setproperty sett prop off
							completeredraw()
							setproperty sett prop on
							completeredraw()
						)
						fn onProperty prop =
						(
							setproperty sett prop on
							--completeredraw()
						)
						fn offProperty prop =
						(
							setproperty sett prop off
							completeredraw()
						)

						fn updateItems = --if enabled do
						(
							sett = nitrous_settings_
							ngm = NitrousGraphicsManager

							if defined (m = rolloutOps.findRCMenuItem top_menu "Antialias Quality*") do
							(
								text = stringformat "Antialias Quality \t%" (getAntialiasQuality())
								rolloutOps.setMenuItemCaption m caption:text
								--rolloutOps.setMenuItemEnabled m enabled:(ngm.AntialiasingQuality == #none)
							)
							if defined (m = rolloutOps.findRCMenuItem top_menu "Darker Back Edges*") do
							(
								text = stringformat "Darker Back Edges \t%" (getDarkerEdgeOption())
								rolloutOps.setMenuItemCaption m caption:text
								--rolloutOps.setMenuItemEnabled m enabled:(ngm.AntialiasingQuality == #none)
							)
							if defined (m = rolloutOps.findRCMenuItem top_menu "Light Mode*") do
							(
								text = stringformat "Light Mode \t%" (convertCamelCase sett.DefaultLightMode)
								rolloutOps.setMenuItemCaption m caption:text
								rolloutOps.setMenuItemEnabled m enabled:(sett.LightOption != #DefaultLight)
							)
							if defined (m = rolloutOps.findRCMenuItem top_menu "Shadow Quality*") do
							(
								text = stringformat "Shadow Quality \t%" (getShadowQuality())
								rolloutOps.setMenuItemCaption m caption:text
								rolloutOps.setMenuItemEnabled m enabled:(not sett.ShadowsEnabled)
							)
							if defined (m = rolloutOps.findRCMenuItem top_menu "Shadow Intensity*") do
							(
								text = stringformat "Shadow Intensity \t%" (getShadowIntensity())
								rolloutOps.setMenuItemCaption m caption:text
								rolloutOps.setMenuItemEnabled m enabled:(not sett.ShadowsEnabled)
							)
							if defined (m = rolloutOps.findRCMenuItem top_menu "Occlusion Intensity*") do
							(
								text = stringformat "Occlusion Intensity \t%" (getAmbientOcclusionIntensity())
								rolloutOps.setMenuItemCaption m caption:text
								rolloutOps.setMenuItemEnabled m enabled:(not sett.AmbientOcclusionEnabled)
							)
							if defined (m = rolloutOps.findRCMenuItem top_menu "*View Graph:*") do
							(
								text = stringformat "\tView Graph: %" (getViewIndex())
								rolloutOps.setMenuItemCaption m caption:text
							)
							false
						)

						submenu "File"
						(
							menuitem load_styles "Load Visual Style..." enabled:(_enabled())
							menuitem save_styles "Save Visual Style..." enabled:(_enabled())
							separator sp_00
							menuitem cancel "Exit"
						)

						submenu "Config"
						(
							menuitem enable_progress "Progressive Quality" enabled:(_enabled()) checked:(enabled and getProgressiveRenderingEnabled())
							separator sp_0
							menuitem enable_brackets "Show Selection Brackets" enabled:(_enabled()) checked:(enabled and sett.ShowSelectionBracketsEnabled)
							menuitem enable_seledges "Show Selected Edged Faces" enabled:(_enabled()) checked:(enabled and sett.SelectedEdgedFacesEnabled)
							menuitem enable_shadefaces "Shade Selected Faces" enabled:(_enabled()) checked:(enabled and sett.ShadeSelectedFacesEnabled)
							menuitem enable_shadeobjs "Shade Selected Objects" enabled:(_enabled()) checked:(enabled and sett.ShadeSelectedObjectsEnabled)
							separator sp_1
							menuitem enable_edged_faces "Show Edged Faces" enabled:(_enabled()) checked:(enabled and sett.ShowEdgedFacesEnabled)
							menuitem enable_textures "Use Textures" enabled:(_enabled()) checked:(enabled and sett.UseTextureEnabled)
							menuitem enable_transparency "Transparency" enabled:(_enabled()) checked:(enabled and sett.TransparencyEnabled)
							separator sp_2
							menuitem toggle_quality "Antialiasing" enabled:enabled checked:(ngm.AntialiasingQuality != #none)
							submenu "Antialias Quality" enabled:on --enabled
							(
								menuitem x0_quality "None" enabled:enabled checked:(ngm.AntialiasingQuality == #none)
								menuitem x2_quality "Low" enabled:enabled checked:(ngm.AntialiasingQuality == #2X)
								menuitem x4_quality "Good" enabled:enabled checked:(ngm.AntialiasingQuality == #4X)
								menuitem x8_quality "High" enabled:enabled checked:(ngm.AntialiasingQuality == #8X)
							)
							separator sp_3
							submenu "Darker Back Edges" enabled:on checked:on--enabled
							(
								menuitem darker_edges_0 "Off" enabled:enabled checked:(ngm.DarkerEdgeOption == #Off)
								menuitem darker_edges_1 "Sub Level Only" enabled:enabled checked:(ngm.DarkerEdgeOption == #SubLevelOnly)
								menuitem darker_edges_2 "Always" enabled:enabled checked:(ngm.DarkerEdgeOption == #Always)
							)
							separator sp_30
							menuitem enable_highlight "Show Highlight" enabled:(_enabled()) checked:(enabled and sett.ShowHighlightEnabled)
							menuitem default_light "Use Default Light" enabled:(_enabled()) checked:(enabled and sett.LightOption == #DefaultLight)
							submenu "Light Mode" enabled:(enabled and sett.LightOption == #DefaultLight)
							(
								menuitem one_light "One Light" checked:(sett.DefaultLightMode == #OneLight)
								menuitem two_light "Two Lights" checked:(sett.DefaultLightMode == #TwoLights)
							)
							menuitem enable_skylights "Use Simplified SkyLight" enabled:(_enabled()) checked:(enabled and sett.UseSimplifiedSkyLight)
							separator sp_4
							menuitem enable_shadow "Shadow" enabled:(_enabled()) checked:(enabled and sett.ShadowsEnabled)
							submenu "Shadow Quality" enabled:enabled
							(
								menuitem soft_quality "Soft Edged" enabled:enabled checked:(sett.LightingAndShadowQualityMode == #SoftEdgedShadows)
								menuitem hard_quality "Hard Edged" enabled:enabled checked:(sett.LightingAndShadowQualityMode == #HardShadows)
								--menuitem norm_quality "Normal" enabled:enabled checked:(sett.LightingAndShadowQualityMode == #1X)
							)
							submenu "Shadow Intensity" enabled:enabled
							(
								menuitem s0_intensity "Lite" enabled:enabled checked:(sett.ShadowIntensity <= 0.25)
								menuitem s1_intensity "Half" enabled:enabled checked:(sett.ShadowIntensity > 0.25 and sett.ShadowIntensity < 0.75)
								menuitem s2_intensity "Full" enabled:enabled checked:(sett.ShadowIntensity >= 0.75)
							)
							separator sp_5
							menuitem enable_occlusion "Ambient Occlusion" enabled:(_enabled()) checked:(enabled and sett.AmbientOcclusionEnabled)
							submenu "Occlusion Intensity" enabled:enabled
							(
								menuitem a0_intensity "Lite" enabled:enabled checked:(sett.AmbientOcclusionIntensity <= 0.25)
								menuitem a1_intensity "Half" enabled:enabled checked:(sett.AmbientOcclusionIntensity > 0.25 and sett.AmbientOcclusionIntensity < 0.75)
								menuitem a2_intensity "Full" enabled:enabled checked:(sett.AmbientOcclusionIntensity >= 0.75)
							)
							separator sp_6
							menuitem enable_reflection "Reflect Environment" enabled:(_enabled()) checked:(enabled and sett.ReflectionEnabled)
						)
						submenu "Presets"
						(
							menuitem quality_preset "Quality" enabled:(_enabled()) checked:(enabled and (sett.ViewportPreset == #Quality))
							menuitem standard_preset "Standard" enabled:(_enabled()) checked:(enabled and (sett.ViewportPreset == #Standard))
							menuitem performance_preset "Performance" enabled:(_enabled()) checked:(enabled and (sett.ViewportPreset == #Performance))
							menuitem dxmode_preset "DX Mode" enabled:(_enabled()) checked:(enabled and (sett.ViewportPreset == #DXMode))
							menuitem customize_preset "Customize" enabled:off checked:(enabled and (sett.ViewportPreset == #Customize))
						)
						on quality_preset picked do sett.ViewportPreset = #Quality
						on standard_preset picked do sett.ViewportPreset = #Standard
						on performance_preset picked do sett.ViewportPreset = #Performance
						on dxmode_preset picked do sett.ViewportPreset = #DXMode
						on customize_preset picked do sett.ViewportPreset = #Customize


						submenu "Tools"
						(
							menuitem toggle_statistics "Statistics" enabled:(_enabled()) --checked:(enabled and getProgressiveRenderingEnabled())
							menuitem toggle_stats_config "Statistics Config" enabled:(_enabled()) --checked:(enabled and getProgressiveRenderingEnabled())
							separator sp_03
							menuitem current_view "\tView Graph: 0" enabled:(updateItems())
							menuitem save_view_graph "Save" enabled:enabled
							menuitem load_view_graph "Load" enabled:enabled
							menuitem unload_view_graph "Unload" enabled:enabled
						)

						on toggle_statistics picked do
						(
							--actionMan.executeAction 0 #40829
							max show statistics toggle
						)
						on toggle_stats_config picked do
						(
							displayViewportConfig 5
						)
						on load_sty
						les picked do d.ops.loadNitrousStyle d
						on save_styles picked do d.ops.saveNitrousStyle d

						on toggle_quality picked do
						(
							mode = NitrousGraphicsManager.AntialiasingQuality
							NitrousGraphicsManager.AntialiasingQuality = choice (mode != #none) #none #8X

							completeredraw()
						)
						on x0_quality picked do (NitrousGraphicsManager.AntialiasingQuality = 0; completeredraw())
						on x2_quality picked do (NitrousGraphicsManager.AntialiasingQuality = 1; completeredraw())
						on x4_quality picked do (NitrousGraphicsManager.AntialiasingQuality = 2; completeredraw())
						on x8_quality picked do (NitrousGraphicsManager.AntialiasingQuality = 3; completeredraw())

						on darker_edges_0 picked do (NitrousGraphicsManager.DarkerEdgeOption = #Off; completeredraw())
						on darker_edges_1 picked do (NitrousGraphicsManager.DarkerEdgeOption = #SubLevelOnly; completeredraw())
						on darker_edges_2 picked do (NitrousGraphicsManager.DarkerEdgeOption = #Always; completeredraw())


						on soft_quality picked do undo "Shadow Quality" on sett.LightingAndShadowQualityMode = #SoftEdgedShadows
						on hard_quality picked do undo "Shadow Quality" on sett.LightingAndShadowQualityMode = #HardShadows
						--on norm_quality picked do undo "Shadow Quality" on sett.LightingAndShadowQualityMode = #'0.5x'

						fn setShadowIntensity val =
						(
							setproperty sett #ShadowIntensity val
							setproperty sett #ShadowsEnabled off
							completeredraw()
							setproperty sett #ShadowsEnabled on
						)
						on s0_intensity picked do setShadowIntensity 0.25
						on s1_intensity picked do setShadowIntensity 0.50
						on s2_intensity picked do setShadowIntensity 1.00

						fn setAmbientOcclusionIntensity val =
						(
							setproperty sett #AmbientOcclusionEnabled off
							setproperty sett #AmbientOcclusionIntensity val
							completeredraw()
							setproperty sett #AmbientOcclusionEnabled on
						)
						on a0_intensity picked do setAmbientOcclusionIntensity 0.25
						on a1_intensity picked do setAmbientOcclusionIntensity 0.50
						on a2_intensity picked do setAmbientOcclusionIntensity 1.00

						on save_view_graph picked do undo "Save View Graph" on NitrousGraphicsManager.SaveViewGraph (getViewIndex()) #tempViewGraph
						on load_view_graph picked do undo "Load View Graph" on NitrousGraphicsManager.LoadViewGraph (getViewIndex()) #tempViewGraph
						on unload_view_graph picked do undo "Unload View Graph" on NitrousGraphicsManager.UnloadViewGraph (getViewIndex())


						on enable_progress picked do undo "Progressive Quality" on
						(
							setProgressiveRenderingEnabled -1
)
						on enable_brackets picked do undo "Show Selection Brackets" on (toggle_ &nitrous_settings_.ShowSelectionBracketsEnabled)
						on enable_seledges picked do undo "Show Selected Edged Faces" on (toggle_ &nitrous_settings_.SelectedEdgedFacesEnabled)
						on enable_shadefaces picked do undo "Shade Selected Faces" on (toggle_ &nitrous_settings_.ShadeSelectedFacesEnabled)
						on enable_shadeobjs picked do undo "Shade Selected Objects" on (toggle_ &nitrous_settings_.ShadeSelectedObjectsEnabled)
						on enable_edged_faces picked do undo "Show Edged Faces" on (toggle_ &nitrous_settings_.ShowEdgedFacesEnabled)
						on enable_textures picked do undo "Use Textures" on (toggle_ &nitrous_settings_.UseTextureEnabled)
						on enable_transparency picked do undo "Transparency" on (toggle_ &nitrous_settings_.TransparencyEnabled)
						on enable_highlight picked do undo "Show Highlight" on (toggle_ &nitrous_settings_.ShowHighlightEnabled)
						on enable_skylights picked do undo "Skylights Ambient" on (toggle_ &nitrous_settings_.UseSimplifiedSkyLight)
						on enable_shadow picked do undo "Shadow" on (toggle_ &nitrous_settings_.ShadowsEnabled)
						on enable_occlusion picked do undo "Ambient Occlusion" on (toggle_ &nitrous_settings_.AmbientOcclusionEnabled)
						on enable_reflection picked do undo "Reflect Environment" on (toggle_ &nitrous_settings_.ReflectionEnabled)

						on default_light picked do undo "Default Light" on
						(
							sett.LightOption = choice (sett.LightOption == #DefaultLight) #SceneLight #DefaultLight
						)
						on one_light picked do undo "Light Mode" on sett.DefaultLightMode = #OneLight
						on two_light picked do undo "Light Mode" on sett.DefaultLightMode = #TwoLights

						on top_menu open do
						(
							updateItems force:on
						)
					)
				)

				fn makeNitrousGraphicsManagerDialog id:0 = with redraw off
				(
					try_ destroydialog (getglobal #DTS_NitrousStyleSetup #dialog)

					rollout_name = "NitrousStyleSetupRollout" --+ (formatstringid id token:"_")
					rcg = rolloutCreator rollout_name "Nitrous Style Setup" width:191
					rcg.begin()

					rcg.addText "rcm = if defined rcm do rcm"
					rcg.addText "ops = if defined ops do ops"
					rcg.addText "opened = if opened != undefined do opened"
					rcg.addText "dialog_pos = if dialog_pos != undefined then dialog_pos else unsupplied"

					sett = nitrous_settings_
					names = nitrous_styles_

					rcg.addText "sett = nitrous_settings_\n"
					rcg.addText "names = nitrous_styles_\n"

					current = nitrous_style_

					rcg.addControl #dropdownlist #styles_dd "" paramstr:("width:180 align:#left offset:[-7,4] items:names height:(names.count+1)")
					rcg.addHandler #styles_dd #selected paramStr:"k" codeStr:"( nitrous_style_ = this_control.selected; ops.enableParameters this_rollout; )"

					rcg.addControl #label "emp_00" "" paramstr:("height:6 offset:[0,0]")

					params = #()
					_params = valueset()
					if isset names do for name in names do
					(
						nitrous_style_ = name
						for k=1 to sett.GetNPRParameterCount() do
						(
							prop = sett.GetNPRParameterName k
							type = sett.GetNPRParameterType k
							if type == #bool or type == #float do
							(
								if appendifunique params prop do
								(
									if  type != #bool and type != #float do format "OOPS name:% prop:% type:%\n" name prop type
									caption = convertCamelCase prop
									if type == #bool then
									(
										val = sett.GetNPRBool prop
										range = [0,1,ibool val]

										c_name = combinestring #(prop,#_cb)
										rcg.addControl #checkbox c_name "" paramstr:("checked:" + (val as string) + " width:20 align:#left offset:[0,0] across:2")
										rcg.addHandler c_name #changed paramStr:"state" codeStr:"sett.SetNPRBool (splitstring this_control.name #_)[1] state"

										l_name = combinestring #(prop,#_lb)
										rcg.addControl #emptycontrol l_name "" paramstr:("static:off text:\"" + caption + "\" pivot:#left width:140 align:#left offset:[-60,0] highlightcolor:white label:#default across:2")
									)
									else
									(
										val = sett.GetNPRFloat prop
										vmin = sett.GetNPRMinFloat prop
										vmax = sett.GetNPRMaxFloat prop
										range = [vmin, vmax, val]

										l_name = combinestring #(prop,#_lb)
										rcg.addControl #emptycontrol l_name "" paramstr:("static:off text:\"" + caption + "\" pivot:#left width:120 offset:[-4,0] highlightcolor:white label:#default across:2")
										--rcg.addHandler lb_name #pressed codeStr:"setclipboardText this_control.text"

										c_name = combinestring #(prop,#_sp)
										rcg.addControl #spinner c_name "" paramstr:("type:#float scale:0.001 fieldwidth:46 range:" + (range as string) + " align:#right offset:[8,-1] offsets:#([0,0],[20,0])")
										rcg.addHandler c_name #changed paramStr:"val" codeStr:"sett.SetNPRFloat (splitstring this_control.name #_)[1] val; invalidateView()"
									)
									append _params (qpair prop caption type:type parameter:name)
								)
							)
						)
					)

					rcg.addControl #label "emp_01" "" paramstr:("height:4 offset:[0,0]")

					rcg.addText @"
					fn updateSettings =
					(
						if defined (style = nitrous_style_) do
						(
							--rcm.updateItems()
							if not (smatch styles_dd.selected style) do	ops.enableParameters this_rollout
						)
					)"


					rcg.addHandler rollout_name #close codeStr:@"
					(
						--xformat_ #closing
						RedrawViewsCB.UnRegisterCallback id:#nitrous_style_settings
						dialog_pos = uiscalevalue (getdialogpos this_rollout)
						opened = off
)"


					rcg.addHandler rollout_name #open codeStr:@"
					(
						opened = on
RedrawViewsCB.RegisterCallback this_rollout.updateSettings id:#nitrous_style_settings redraw:off
						ops.enableParameters this_rollout
					)"


					rcg.end()

					nitrous_style_ = current

					rcg.def
				)

				style = #(#style_titlebar, #style_border, #style_sysmenu, #style_minimizebox)

				if isstruct (owner = getglobal #DTS_NitrousStyleSetup) do
				(
					owner.dialog =
					(
						if iskindof (_d = getglobal #DTS_NitrousStyleSetup #dialog) RolloutClass do try_ destroydialog _d
						makeNitrousGraphicsManagerDialog id:1
					)
				)

				fn destroy =
				(
					destroydialog_ d
				)
				fn create =
				(
					debug_load = (esc_ or ctrl_)
					owner = getglobal #DTS_NitrousStyleSetup

					d = owner.dialog
					dialog_pos = if isrollout d do d.dialog_pos

					if debug_load or not isrollout d or isnotset d.names do
					(
						owner.dialog = d =
						(
							if isrollout d do destroydialog d
							makeNitrousGraphicsManagerDialog id:1
						)
					)

					d.ops = NitrousStyleRolloutOps
					d.rcm = top_menu

					top_menu.d = d

					pos = choice debug_load unsupplied [0,-3000]
					createdialog d pos:pos	menu:top_menu
					winapi.setwindowicon d icon:#dts

					if not debug_load and defined dialog_pos then rolloutops.setdialogpos d dialog_pos
					else rolloutops.centerdialogpos d parent:#max

					if not isWindowInWorkArea d type:#exact do winapi.centerwindow d
				)

				fn enabled =
				(
					isstruct (owner = getglobal #DTS_NitrousStyleSetup) and
						NitrousGraphicsManager.IsEnabled() and iskindof (d = getglobal #DTS_NitrousStyleSetup #dialog) RolloutClass
				)

                if enabled() do
                (
                    if (d.opened != true) then create() else destroy()
                )
