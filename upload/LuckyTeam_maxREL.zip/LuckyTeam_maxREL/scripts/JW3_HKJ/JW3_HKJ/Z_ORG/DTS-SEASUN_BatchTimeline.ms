tool_name = #SEASUN_BatchControl
d = undefined
s = undefined
sz = undefined
def_bkcolor = titan
def_toolTip = @"<b><font color='darkorange'>Quick Timeline</font></b>
        <pre> <b>+SHIFT</b> Reset"
SEASUN_BatchTimeline_Open = if SEASUN_BatchTimeline_Open == undefined then false else SEASUN_BatchTimeline_Open

rollout ez_animrange "EZ ANIMRANGE" width:82 height:18
(
    ez_id = #ez_animrange
    owner = owner
    def_bkcolor = darkcolor dimorange

    bgn_ed = undefined
    end_ed = undefined

    spinner bgn_sp type:#integer range:[-1e4,1e4,animationstart] width:50 pos:[2,2]
    spinner end_sp type:#integer range:[-1e4,1e4,animationend] width:51 pos:[42,2]

    fn update_animrange_ui = if not quiet_mode do
    (
        ensureset &bgn_sp.value animationstart
        ensureset &end_sp.value animationend
    )

    on bgn_sp entered arg can do with redraw on
    (
        if not can do undo "EZ Range" on (setAnimationRange this_control.value animationend time:(incase shift_ #start))
    )

    on end_sp entered arg can do with redraw on
    (
        if not can do undo "EZ Range" on (setAnimationRange animationstart this_control.value time:(incase shift_ #end))
    )

    on bgn_sp setFocus prev_hwnd do
    (
        winapi.seteditcursor bgn_ed exact:on
    )

    on end_sp setFocus prev_hwnd do
    (
        winapi.seteditcursor end_ed exact:on
    )

    fn delete_sp_items hwnd code id: =
    (
        if (winapi.ismenu hwnd) do
        (
            del = winapi.deletemenuitem hwnd "" pos:8 count:-1 id:&id
        )
        ok
    )

    fn icust_wnd hwnd message wparam lparam =
    (
        winapi.hookwindowevent function:delete_sp_items id:#ez_animrange event:#show class:"#32768" once:on
        ok
    )

    fn reset_000 hwnd message wparam lparam =
    (
        undo "EZ Range" on
        (
            setanimationstart 0 time:(incase shift_ #start)
        )
        #cancel
    )

    fn reset_100 hwnd message wparam lparam =
    (
        undo "EZ Range" on
        (
            setanimationend 100 time:(incase shift_ #end)
        )
        #cancel
    )

    on ez_animrange close do
    (
        SEASUN_BatchTimeline_Open = false
        winapi.unhookWindowMessages id:#ez_animrange
        rolloutops.disablecustomhandlers (getspinneredit bgn_sp)
        rolloutops.disablecustomhandlers (getspinneredit end_sp)
        inotifycallbacks.removecallbacks id:#ez_animrange
    )

    on ez_animrange open do
    (
        inotifycallbacks.removecallbacks id:#ez_animrange
        rolloutOps.hideControl bgn_sp id:0
        rolloutOps.hideControl end_sp id:0
        winproc.ontop ez_animrange

        bgn_ed = getspinneredit bgn_sp
        end_ed = getspinneredit end_sp

        winapi.hookWindowMessages bgn_ed function:reset_000 id:#ez_animrange message:#(WM_RBUTTONDOWN_)
        winapi.hookWindowMessages end_ed function:reset_100 id:#ez_animrange message:#(WM_RBUTTONDOWN_)
        inotifycallbacks.registercallback update_animrange_ui id:#ez_animrange code:(NOTIFY_TIMERANGE_CHANGE = 0x00000070)
        rollout_resized_
    )
)

d = try_ globalvars.getvalue tool_name
if isstruct d do
(
    if not SEASUN_BatchTimeline_Open then
    (
        createDialog ez_animrange style:#() bgcolor:def_bkcolor
        ez_animrange.owner = d
        d.ezrange = ez_animrange
        SEASUN_BatchTimeline_Open = true
    )
    else
    (
        try_ destroyDialog ez_animrange
        SEASUN_BatchTimeline_Open = false
    )
)
