d = try (globalvars.getvalue #DTS_OpenRecent) catch ()
if isstruct d do
(
    if checkForSave() do
    (
        with quiet on
        (
            fetchmaxfile quiet:on usefileunits:d.use_file_units
        )
        inotifycallbacks.broadcastcallback code:d.NOTIFY_FILE_POST_OPEN parameter:0
        clearUndoBuffer()
        setSaveRequired off
        updateToolbarButtons()
    )
)
