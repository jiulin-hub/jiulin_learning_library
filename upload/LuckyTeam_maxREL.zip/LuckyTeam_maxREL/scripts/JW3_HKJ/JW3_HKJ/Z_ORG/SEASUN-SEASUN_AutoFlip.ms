d = globalvars.getvalue #SEASUN_PolyOps
if isstruct d and getnodes selectedNodes class:editable_poly any:on do
(
    d.auto_flip_mode = not d.auto_flip_mode
    validateMacroButtons()
)
