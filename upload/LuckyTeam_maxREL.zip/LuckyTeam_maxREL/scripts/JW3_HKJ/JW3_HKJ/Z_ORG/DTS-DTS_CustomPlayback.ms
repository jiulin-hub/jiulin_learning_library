tool_name = #SEASUN_QuickBips
d = undefined
sz = undefined
playing = off
looping = off
def_bkcolor = darkcolor dimtitan
def_toolTip = @"<b><font color='darkorange'>Custom Playback</font></b>
        <pre> <b>+SHIFT</b> Reset"
play_speed = 1.0
SEASUN_CustomPlayback_Open = if SEASUN_CustomPlayback_Open == undefined then false else SEASUN_CustomPlayback_Open

rollout ez_playback "EZ PLAYBACK" width:80 height:16
(
    ez_id = #ez_playback
    owner = owner

    ss_ = uiscale_ 2
    rd_ = uiscale_ 2.6
    sz_ = uiscale_ 1.2

    emptycontrol play_bt text:"PLAY" width:38 height:18 pos:[2,-1] pivot:#middle label:darkwhite static:off
    spinner speed_sp type:#float range:[-10, 10, play_speed] width:51 pos:[42,0]
    emptycontrol emp_bk color:def_bkcolor pos:[0,0] width:80 height:16 enabled:off static:on

    speed_ed = undefined

    fn getSpeedValue = strfloat_ (winapi.getwindowtext speed_ed)

    fn customPlayback speed:1.0 time: start: end: selected: = undo off, animate off
    (
        xformat_ "PLAY:" speed play_speed time

        if notdefined start do start = animationstart
        if notdefined end do end = animationend

        backplay = sign speed < 0
        playing = on

        if selected == false do
        (
            selnodes = selectednodes
            selectednodes = #()
        )

        with_suspend_except #(#redraw) \
        (
            lockCommandPanelUpdate parent:on
            suspendMotionEditing()

            t = choice time currenttime (choice backplay end start)

            while ((backplay and t > start) or (t < end)) and noesc_ and playing do
            (
                x = xtime_
                slidertime = t
                redrawviews()

                delta = frame_msec / (abs speed) - xtime x
                if delta > 0 then
                (
                    xsleep delta
                    t += sign speed
                )
                else
                (
                    t += (-delta * speed / frame_msec)
                )

                if looping do
                (
                    if backplay then
                    (
                        if t <= start do t = end
                    )
                    else
                    (
                        if t >= end do t = start
                    )
                )
                checkmaxmessages()
            )

            lockMaxWindowUpdate()
            checkmaxmessages()
            resumeMotionEditing()
            winapi.UnLockWindowUpdate()
        )

        if selected == false do selectednodes = selnodes
        ok
    )

    fn reset_speed hwnd message wparam lparam =
    (
        play_speed = speed_sp.value = 1.0
        #cancel
    )

    on speed_sp entered arg can do
    (
        if not can do (play_speed = this_control.value)
    )

    on speed_sp setfocus prev_hwnd do
    (
        winapi.seteditcursor speed_ed exact:on
    )

    on play_bt press arg do
    (
        bt = this_control
        if playing then
        (
            bt.text = "PLAY"
            bt.color = getcontrolparam bt #color
            bt.active = undefined
            bt.label = getcontrolparam bt #label
            playing = false
        )
        else
        (
            looping = any_ true ctrl_ shift_ (arg == #right)
            bt.text = choice looping "LOOP" "PLAY"
            bt.active = fadeblue
            bt.color = litecobalt
            bt.label = white

            playing = true
            play_speed = speed_sp.value = getSpeedValue()
            backplay = (sign play_speed < 0)

            if (arg == #right) do slidertime = choice (bsign play_speed) animationstart animationend
        )
    )

    on play_bt clicked arg do
    (
        bt = this_control
        if playing then
        (
            customPlayback speed:play_speed time:(arg != #right)
        )
    )

    on ez_playback close do
    (
        playing = off
        SEASUN_CustomPlayback_Open = false
        winapi.unhookWindowMessages id:#ez_playback
    )

    on ez_playback open do
    (
        setwindowround play_bt radius:rd_ size:2
        rolloutOps.hideControl speed_sp id:0
        speed_ed = getspinneredit speed_sp
        winapi.hookWindowMessages speed_ed function:reset_speed id:#ez_playback message:#(WM_RBUTTONDOWN_)
        rollout_resized_
    )
)

d = try_ globalvars.getvalue tool_name
if isstruct d do
(
    if not SEASUN_CustomPlayback_Open then
    (
        createDialog ez_playback style:#() bgcolor:def_bkcolor
        ez_playback.owner = d
        SEASUN_CustomPlayback_Open = true
    )
    else
    (
        playing = off
        try_ destroyDialog ez_playback
        SEASUN_CustomPlayback_Open = false
    )
)
