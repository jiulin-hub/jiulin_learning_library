d = try (globalvars.getvalue #DTS_OpenRecent) catch ()
if isstruct d do
(
    files = d.getRecentFiles sort:shift_
    xfile = d.getHeldFile()
    file = for f in files where istruefile f[2] and not ipath.trueEqual f[2] xfile do exit with f[2]
    if istruefile file do
    (
        with quiet on
        (
            loadmaxfile file quiet:on usefileunits:d.use_file_units
        )
        inotifycallbacks.broadcastcallback code:d.NOTIFY_FILE_POST_OPEN parameter:0
        clearUndoBuffer()
        setSaveRequired off
    )
    updateToolbarButtons()
)
