d = try (globalvars.getvalue #DTS_EasyJump #stackJump) catch ()
s = d
if isstruct d do
(
    callbacks.removeScripts id:#dts_stack_jump

    if keyboard.shiftpressed then
    (
        d.this_edit = modpanel.getCurrentObject()
        d.obj_class = if d.is_modifier d.this_edit do classof d.this_edit
        d.active = off
    )
    else if keyboard.escpressed then
    (
        d.this_edit = modpanel.getCurrentObject()
        d.obj_class = if d.is_modifier d.this_edit do d.this_edit
        d.active = off
    )

    if (d.active = not d.active) do
    (
        callbacks.addScript #modPanelSelChanged "(getglobal #DTS_EasyJump #stackJump).stack_jump event:#sel" id:#dts_stack_jump

        d.last_node = undefined
        if (getCommandPanelTaskMode() == #modify) then
        (
            d.last_edit = ok
            d.stack_jump event:#actv
        )
        else
        (
            d.last_edit = undefined
        )
    )
)
