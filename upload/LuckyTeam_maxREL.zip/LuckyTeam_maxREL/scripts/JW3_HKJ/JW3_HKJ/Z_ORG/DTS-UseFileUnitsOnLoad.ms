d = try (globalvars.getvalue #DTS_OpenRecent) catch ()
if isstruct d do
(
    d.use_file_units = not d.use_file_units
    d.saveINISettings()
    updateToolbarButtons()
)
