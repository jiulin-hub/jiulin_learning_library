v = globalvars.getvalue #SEASUN_PolyOps
d = if isstruct v then getStructMember v #ShellOps else undefined
if isstruct d do
(
    if not shift_ then
    (
        if not d.opened then
            d.create()
        else
            d.destroy()

        validateMacroButtons()
    )
    else
    (
        undo "Select" on
        (
            result = d.selectShellVerts()

            completeredraw()
            validateMacroButtons()

            result
        )
    )
)
