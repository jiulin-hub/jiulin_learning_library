d = globalvars.getvalue #SEASUN_SkinDataManager
if isstruct d do
(
    if not d.isopened() then
        d.create()
    else
        d.destroy()

    validateMacroButtons()
)
