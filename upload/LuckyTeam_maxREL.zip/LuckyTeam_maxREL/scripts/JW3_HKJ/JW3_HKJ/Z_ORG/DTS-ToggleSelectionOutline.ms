sett = nitrous_settings_
if isinterface sett do undo "Toggle Outline" on
(
    ss = NitrousGraphicsManager.GetSelectionSetting()
    toggle_ &ss.Enabled
    completeRedraw()
)
