val = gridPrefs.perspViewGridExtents
val *= choice shift_ 0.5 2
gridPrefs.perspViewGridExtents = max_ 10 (round val 10)
