d = getglobal #SEASUN_TrashRemover
if isstruct d do
(
    if not d.opened then
        d.create()
    else
        d.destroy()
)
