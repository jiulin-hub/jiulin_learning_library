fn resetObjectMesh objList =
(
    for obj in objList do
    (
        mesh = snapshotasmesh obj
        obj.pivot = [0,0,0]
        resetXForm obj
        convertToMesh obj
        obj.mesh = mesh
        convertToPoly obj
    )
)

resetObjectMesh selection
