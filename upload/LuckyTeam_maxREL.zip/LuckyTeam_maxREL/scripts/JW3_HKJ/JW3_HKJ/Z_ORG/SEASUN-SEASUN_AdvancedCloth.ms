d = globalvars.getvalue #SEASUN_AdvancedCloth
if d != undefined do
(
    if not d.opened then
        d.create()
    else
        d.destroy()
)
