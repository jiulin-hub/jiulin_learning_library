d = globalvars.getvalue #AppTitleExtension
if isStruct d do
(
    d.toggle()
)
