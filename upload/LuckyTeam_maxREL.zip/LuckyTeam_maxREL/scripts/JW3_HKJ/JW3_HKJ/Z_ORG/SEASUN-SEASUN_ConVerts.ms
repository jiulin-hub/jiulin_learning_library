if getnodes selectedNodes class:editable_poly any:on do
(
    undo "Convert To Poly Verts" on
    (
        for node in getnodes selectedNodes class:editable_poly do
        (
            getpolyvertsusing node #selected select:on
        )
    )
)
