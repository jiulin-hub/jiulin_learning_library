d = try (globalvars.getvalue #DTS_OpenRecent) catch ()
if isstruct d do
(
    if shift_ then
    (
        xfile = this_maxfile
        if istruefile xfile do iniops.set d.ini_file #DTS_OpenRecent #held_file xfile
    )
    else if esc_ then
    (
        xfile = ""
        iniops.set d.ini_file #DTS_OpenRecent #held_file xfile
    )
    else
    (
        xfile = d.getHeldFile()
        if istruefile xfile do
        (
            with quiet on
            (
                loadmaxfile xfile quiet:on usefileunits:d.use_file_units
            )
            inotifycallbacks.broadcastcallback code:d.NOTIFY_FILE_POST_OPEN parameter:0
            clearUndoBuffer()
            setSaveRequired off
        )
    )
    updateToolbarButtons()
)
