d = try (globalvars.getvalue #SEASUN_SceneAutoUnits) catch()
if isstruct d do
(
    if shift_ then
    (
        if d.opened then
            d.destroy()
        else
            d.create()
    )
    else
    (
        undo "SEASUN Scene Units" on
        (
            d.dialog.setDefaultSettings()
        )
    )
)
