tool_name = #SEASUN_MoCapMapper
d = globalvars.getvalue tool_name
if isstruct d do
(
    if not d.isopened() then
        d.create()
    else
        d.destroy()

    validateMacroButtons()
)
