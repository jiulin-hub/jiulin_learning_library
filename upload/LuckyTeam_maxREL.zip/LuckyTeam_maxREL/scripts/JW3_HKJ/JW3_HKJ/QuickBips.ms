d = globalvars.getvalue #SEASUN_QuickBips
if d != undefined do
(
    if not d.isopened() then
        d.create()
    else
        d.destroy()

    validateMacroButtons()
)
