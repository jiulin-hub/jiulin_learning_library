undo "Toggle Brackets" on
(
    max file preferences gamma
)
