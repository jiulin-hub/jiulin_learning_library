# =============================================================================
#  lucky_max_menu.py  --  plugin entry point
# -----------------------------------------------------------------------------
#  This file must stay a .py: luckybears.ms runs it through python.ExecuteFile.
#
#  *** DO NOT ADD A "# -*- coding: ... -*-" LINE HERE ***
#  3ds Max 2018's python.ExecuteFile decodes the file into a unicode string and
#  compiles that string. Python 2.7 then fails immediately with
#        SyntaxError: encoding declaration in Unicode string (line 0)
#  This file is therefore kept 7-bit ASCII as well, for the same reason.
#  Non-ASCII text belongs in the imported modules (luckteam2/3, lucky_i18n),
#  which are loaded from bytes and therefore ignore this restriction.
# -----------------------------------------------------------------------------
#  Flow
#    1. put box/ and ../scripts on sys.path
#    2. choose luckteam2 (Py2.7) / luckteam3 (Py3) from sys.version_info
#    3. build the top menu, then open the toolbox
#    4. start the bottom shelf (Max2020_LuckyToolShelf)
#
#  Every step has its own try/except: one failing step (for example the
#  incomplete PySide2 that ships with Max 2018) must not take the toolbox or
#  the shelf down with it.
#
#  The last two lines are the auto-start marker that Max2020_LuckyToolShelf
#  looks for (TARGET_LINES). Do not rename, split or remove them.
# =============================================================================
from __future__ import print_function

import inspect
import os
import sys
import traceback

try:
    _THIS_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # Some 3ds Max builds do not inject __file__ into ExecuteFile'd code.
    _THIS_DIR = os.path.dirname(
        os.path.abspath(inspect.currentframe().f_code.co_filename))

_ROOT_DIR = os.path.dirname(_THIS_DIR)
_SCRIPTS_DIR = os.path.join(_ROOT_DIR, "scripts")

for _p in (_THIS_DIR, _SCRIPTS_DIR):
    if _p not in sys.path:
        sys.path.insert(0, _p)


def _load_toolbox():
    """Pick the implementation that matches this interpreter."""
    if sys.version_info[0] >= 3:
        import luckteam3 as _mod
    else:
        import luckteam2 as _mod
    return _mod


try:
    _toolbox = _load_toolbox()
    print("[LuckyLoader] Python {0}.{1} -> {2}".format(
        sys.version_info[0], sys.version_info[1], _toolbox.__name__))
except Exception:
    _toolbox = None
    traceback.print_exc()
    print("[LuckyLoader] toolbox core failed to load, "
          "send the traceback above to the developer.")

if _toolbox is not None:
    try:
        import lucky_workspace_menu; lucky_workspace_menu.install(_toolbox)
    except Exception:
        traceback.print_exc()

    try:
        _toolbox.open_lucky_toolbox()
    except Exception:
        traceback.print_exc()

# --- auto-start marker: Max2020_LuckyToolShelf looks for exactly these lines ---
# Do not wrap them in try/except or indent them: the shelf finds/deletes them by
# comparing stripped line text. Failures are handled inside main() itself,
# which logs to %TEMP%\LuckyTeam_startup.log instead of raising.

import max_bridge_server

import Max2020_LuckyToolShelf
Max2020_LuckyToolShelf.main()
